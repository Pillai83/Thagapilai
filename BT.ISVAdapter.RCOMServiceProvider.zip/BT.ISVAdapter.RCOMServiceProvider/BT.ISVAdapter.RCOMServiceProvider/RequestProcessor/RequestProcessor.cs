﻿using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using BT.Core.ISVAdapter.ISVService.Entities;
using System.ServiceModel;
using System.Messaging;
using System.Linq;
using System.Xml.Linq;
using System.Security.AccessControl;
using System.Reflection;
using BT.SaaS.Core.Shared.Entities;
using System.ServiceModel.Channels;
using BT.ISVAdapter.RCOMServiceProvider.DnPProxy;
using System.Text;
using System.DirectoryServices;
using saas.bt.com.v5;
using BT.ISVAdapter.RCOMServiceProvider.DAL;
using BT.Core.ISVAdapter.ISVService;
using BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using BT.SaaS.TokenManager;




namespace BT.ISVAdapter.RCOMServiceProvider
{
    public class RequestProcessor : BaseISVServiceProvider
    {
        #region Constants
        private const string ADDRESS_BTCOM = @"http://www.profile.com?SAASPE";
        private const string ACTION_UPDATE = "UPDATE";
        private const string DNP_USER_KEY = "DnPUser";
        private const string DNP_PWD_KEY = "DnPPassword";
        private const string HTTP_HEADER_AUTHORIZATION = "Authorization";
        private const string AUTHORIZATION_TYPE_BASIC = "Basic ";
        private const string SERVICE_ENDPOINT_DNP = @"EndPoint_ServiceProfile_DnP";
        #endregion

        #region PublicMembers
        Dictionary<string, string> m_inputParameterCollection;
        BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order;
        public int transferInState = 1;
        public int pendingState = 0;
        public int intermediateState = 3;
        public int completedState = 2;
        bool IsHEUser = true;
        #endregion

        #region Constructor
        public RequestProcessor(BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order)
        {
            this.order = order;

            m_inputParameterCollection = new Dictionary<string, string>();
            foreach (BT.Core.ISVAdapter.ISVService.Entities.Attribute item in order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes)
            {
                if (item.Name != null)
                {
                    if (item.Value != null)
                        m_inputParameterCollection.Add(item.Name.ToLower(), item.Value);
                    else
                        m_inputParameterCollection.Add(item.Name.ToLower(), string.Empty);
                }
            }
            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateRemoteCertificate);
        }
        public RequestProcessor()
        {
            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateRemoteCertificate);
        }
        #endregion

        #region DMCService
        private DMCWebServiceSoap dmcWebServiceSoap
        {
            get
            {
                ChannelFactory<DMCWebServiceSoap> factory = new ChannelFactory<DMCWebServiceSoap>(@"DMCWebServiceSoap");
                DMCWebServiceSoap svc = factory.CreateChannel();
                return svc;
            }
        }
        #endregion

        #region ModifyAccountForActivateWebsite
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder ModifyAccountForActivateWebsite(BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order)
        {
            order = ModifyAccountForUpdateZoneConfig();
            return order;
        }
        #endregion

        #region Auto Activation
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder AutoActivationForActivateWebsite(BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order)
        {
            foreach (BT.Core.ISVAdapter.ISVService.Entities.ServiceRole role in order.ServiceActionOrderItem.ServiceRoles)
            {
                if (role.RoleType.ToString().ToUpper().Equals("ADMIN"))
                {
                    foreach (BT.Core.ISVAdapter.ISVService.Entities.Attribute roleAttr in role.roleAttributes)
                    {
                        if (!string.IsNullOrEmpty(roleAttr.Name) && string.Compare(roleAttr.Name, "ISACTIVATED", true).Equals(0))
                            roleAttr.Value = "True";
                        if (!string.IsNullOrEmpty(roleAttr.Name) && string.Compare(roleAttr.Name, "LICENSETYPE", true).Equals(0))
                            roleAttr.Value = "external";
                    }
                }

            }
            return order;
        }
        #endregion

        #region CeaseAccountForCease
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder CeaseAccountForCease()
        {
            order = ModifyAccountForChangeFreeStatus();

            // Method to update domain attribute 'Free' value from True to False in DnP
            if (order.ServiceActionOrderItem.Header.ServiceAction == BT.Core.ISVAdapter.ISVService.Entities.ServiceActionEnum.ceaseAccount &&
                order.ServiceActionOrderItem.Header.RequestAction == BT.Core.ISVAdapter.ISVService.Entities.ServiceRequestedActionEnum.cease &&
                order.ServiceActionOrderItem.IsvResponse.ResponseCode)
            {
                // Adding extra checks to make sure, this update should happen only for AccountCease scenario, for other scenario's it is BAU
                if (m_inputParameterCollection.ContainsKey("domainname") && !string.IsNullOrEmpty(m_inputParameterCollection["domainname"].Trim())
                    && m_inputParameterCollection.ContainsKey("adminuser") && m_inputParameterCollection["adminuser"] != null
                    && m_inputParameterCollection.ContainsKey("requesttype") && m_inputParameterCollection["requesttype"] == "UPDATE")
                {
                    List<ClientServiceRoleCharacteristic> clientServiceRoleCharacteristic = new List<ClientServiceRoleCharacteristic>();

                    clientServiceRoleCharacteristic.Add(new ClientServiceRoleCharacteristic() { action = "UPDATE", name = "FREE", value = "False" });
                    if (m_inputParameterCollection.ContainsKey("isactivated"))
                    {
                        clientServiceRoleCharacteristic.Add(new ClientServiceRoleCharacteristic() { action = "UPDATE", name = "ISACTIVATED", value = "False" });
                    }
                    UpdateClientServiceRoleCharacteristic(m_inputParameterCollection["adminuser"], order.ServiceActionOrderItem.Header.ServiceInstanceID.ToString(), clientServiceRoleCharacteristic);
                }
            }

            return order;
        }

        private static bool UpdateClientServiceRoleCharacteristic(string primaryUser, string serviceInstanceId, List<ClientServiceRoleCharacteristic> clientServiceRoleCharacteristic)
        {
            try
            {
                manageClientProfileResponse1 clientProfileResponse = null;
                ManageClientProfileRequest request = new ManageClientProfileRequest();
                request.standardHeader = new StandardHeaderBlock();
                request.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                request.standardHeader.serviceAddressing.from = "http://www.profile.com?SAASPE";
                request.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
                request.manageClientProfileReq = new ManageClientProfileReq();
                request.manageClientProfileReq.clientProfile = new ClientProfile();
                request.manageClientProfileReq.clientProfile.client = new Client();
                request.manageClientProfileReq.clientProfile.client.action = "UPDATE";
                request.manageClientProfileReq.clientProfile.client.clientIdentity = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity[1];
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0] = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].action = "SEARCH";
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].value = primaryUser;
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain = new ManagedIdentifierDomain();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain.value = "BTCOM";

                request.manageClientProfileReq.clientProfile.clientServiceInstance = new ClientServiceInstance[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0] = new ClientServiceInstance();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].name = serviceInstanceId;
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole = new ClientServiceRole[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0] = new ClientServiceRole();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].id = "ADMIN";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic = clientServiceRoleCharacteristic.ToArray();

                manageClientProfileRequest1 request1 = new manageClientProfileRequest1();
                request1.manageClientProfileRequest = request;

                #region Call DnP
                byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
                httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
                {
                    ClientProfileSyncPortType svc = factory.CreateChannel();
                    using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                    {
                        OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                        System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                        clientProfileResponse = svc.manageClientProfile(request1);
                    }
                }
                if ((clientProfileResponse != null) && (clientProfileResponse.manageClientProfileResponse != null) && (clientProfileResponse.manageClientProfileResponse.standardHeader != null)
                 && (clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState != null))
                {
                    if (clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState.stateCode == "0")
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                {
                    return false;
                }
                #endregion
            }
            catch (Exception)
            {
                // 15/03/2014
                // for now ignore exceptions while calling dnp
            }
            return false;
        }

        private static bool UpdateServiceInstanceStatus(string primaryUser, string serviceInstanceId)
        {
            try
            {
                manageClientProfileRequest1 clientProfileRequest1 = new manageClientProfileRequest1();
                ManageClientProfileRequest clientProfileRequest = new ManageClientProfileRequest();

                clientProfileRequest.standardHeader = new StandardHeaderBlock();
                clientProfileRequest.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                clientProfileRequest.standardHeader.serviceAddressing.from = "BTCOM";
                clientProfileRequest.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();

                clientProfileRequest.manageClientProfileReq = new ManageClientProfileReq();
                clientProfileRequest.manageClientProfileReq.clientProfile = new ClientProfile();
                clientProfileRequest.manageClientProfileReq.clientProfile.client = new Client();
                clientProfileRequest.manageClientProfileReq.clientProfile.client.action = "UPDATE";

                clientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity[1];
                clientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0] = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity();

                clientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].action = "SEARCH";
                clientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].value = primaryUser;
                clientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain = new ManagedIdentifierDomain();
                clientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain.value = "BTCOM";
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance = new ClientServiceInstance[1];
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0] = new ClientServiceInstance();
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "SEARCH";
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].name = serviceInstanceId;
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "UPDATE";
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceInstanceStatus = new ClientServiceInstanceStatus();
                clientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceInstanceStatus.value = "INACTIVE";

                manageClientProfileResponse1 response;
                byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
                httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                clientProfileRequest1.manageClientProfileRequest = clientProfileRequest;

                using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>("ClientProfileSyncPort"))
                {
                    ClientProfileSyncPortType svc = factory.CreateChannel();
                    using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                    {
                        OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                        response = svc.manageClientProfile(clientProfileRequest1);
                    }
                }
                if ((response != null) && (response.manageClientProfileResponse != null) && (response.manageClientProfileResponse.standardHeader != null)
                 && (response.manageClientProfileResponse.standardHeader.serviceState != null))
                {
                    if (response.manageClientProfileResponse.standardHeader.serviceState.stateCode == "0")
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                // to catch the exception
            }
            return false;
        }

        #endregion

        #region ModifyAccountForDowngrade
        public void ModifyAccountForDowngrade()
        {
            ModifyAccountForChangeFreeStatus();
        }
        #endregion

        #region ModifyAccountForSuspend
        public void ModifyAccountForSuspend()
        {
            ModifyAccountForChangeFreeStatus();
        }
        #endregion

        #region ModifyAccountForResume
        public void ModifyAccountForResume()
        {
            ModifyAccountForSetFreeStatus();
        }
        #endregion

        #region CreateAccountForPurchaseDomain
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder CreateAccountForPurchaseDomain()
        {
            if (!m_inputParameterCollection["domainname"].Equals(string.Empty))
            {
                string domainName = m_inputParameterCollection["domainname"].Trim();
                if (!CheckDomainName(domainName, completedState))
                {
                    Person personDetails = new Person();
                    Contact contactDetails = new Contact();
                    Address addressDetails = new Address();
                    AccountInfo accInfo = new AccountInfo();
                    domainInfo domInfo = new domainInfo();
                    purchaseDomainResp purchaseDomainRes = new purchaseDomainResp();
                    purchaseDomainReq purchaseDomainReq = new purchaseDomainReq();
                    string[] domains;
                    purchaseDomainReq.Admin = new contact();
                    purchaseDomainReq.Registrant = new contact();
                    accInfo.BTUsername = m_inputParameterCollection["btusername"];
                    accInfo.BTPassword = m_inputParameterCollection["btpassword"];
                    accInfo.accountNumber = m_inputParameterCollection["accountnumber"];
                    domains = m_inputParameterCollection["domainname"].Trim().Split('.');
                    domInfo.sld = domains[0];
                    if (domains.Length > 2)
                        domInfo.tld = domains[1] + "." + domains[2];
                    else
                        domInfo.tld = domains[1];
                    string adminaddress1 = string.Empty;
                    adminaddress1 = m_inputParameterCollection["adminaddr1"];
                    if (!string.IsNullOrEmpty(adminaddress1))
                    {
                        if (adminaddress1.Length <= 3)
                        {
                            int len = adminaddress1.Length;
                            for (int i = 3; i >= len; i--)
                            {
                                adminaddress1 = adminaddress1 + ".";
                            }
                            purchaseDomainReq.Admin.addr1 = adminaddress1;
                        }
                        else
                        {
                            purchaseDomainReq.Admin.addr1 = m_inputParameterCollection["adminaddr1"];
                        }
                    }
                    else
                    {
                        purchaseDomainReq.Admin.addr1 = m_inputParameterCollection["adminaddr2"] + m_inputParameterCollection["admintown"];
                    }
                    purchaseDomainReq.Admin.addr2 = m_inputParameterCollection["adminaddr2"];
                    if (m_inputParameterCollection["admincountry"] == string.Empty)
                    {
                        purchaseDomainReq.Admin.country = Properties.Settings.Default.Country;
                    }
                    else
                    {
                        purchaseDomainReq.Admin.country = m_inputParameterCollection["admincountry"];
                    }
                    if (m_inputParameterCollection["admincounty"] == string.Empty)
                    {
                        purchaseDomainReq.Admin.county = "Unknown";
                    }
                    else
                    {
                        purchaseDomainReq.Admin.county = m_inputParameterCollection["admincounty"];
                    }
                    purchaseDomainReq.Admin.email = m_inputParameterCollection["adminemail"];
                    purchaseDomainReq.Admin.firstname = m_inputParameterCollection["adminfirstname"];
                    purchaseDomainReq.Admin.lastname = m_inputParameterCollection["adminlastname"];
                    purchaseDomainReq.Admin.orgname = m_inputParameterCollection["adminorgname"];
                    if (!m_inputParameterCollection["adminphone"].Equals(string.Empty))
                    {
                        purchaseDomainReq.Admin.phone = FormatTelephoneNumber(m_inputParameterCollection["adminphone"]);
                    }
                    if (m_inputParameterCollection["adminpostcode"].Equals(string.Empty))
                    {
                        purchaseDomainReq.Admin.postcode = "Unknown";
                    }
                    else
                    {
                        purchaseDomainReq.Admin.postcode = m_inputParameterCollection["adminpostcode"];
                    }
                    purchaseDomainReq.Admin.town = m_inputParameterCollection["admintown"];


                    string registaddress1 = string.Empty;
                    registaddress1 = m_inputParameterCollection["registrantaddr1"];
                    if (!string.IsNullOrEmpty(registaddress1))
                    {
                        if (registaddress1.Length <= 3)
                        {
                            int len = registaddress1.Length;
                            for (int i = 3; i >= len; i--)
                            {
                                registaddress1 = registaddress1 + ".";
                            }
                            purchaseDomainReq.Registrant.addr1 = registaddress1;
                        }
                        else
                        {
                            purchaseDomainReq.Registrant.addr1 = m_inputParameterCollection["registrantaddr1"];
                        }
                    }
                    else
                    {
                        purchaseDomainReq.Registrant.addr1 = m_inputParameterCollection["registrantaddr2"] + m_inputParameterCollection["registranttown"];
                    }
                    purchaseDomainReq.Registrant.addr2 = m_inputParameterCollection["registrantaddr2"];
                    if (m_inputParameterCollection["registrantcountry"] == string.Empty)
                    {
                        purchaseDomainReq.Registrant.country = Properties.Settings.Default.Country;
                    }
                    else
                    {
                        purchaseDomainReq.Registrant.country = m_inputParameterCollection["registrantcountry"];
                    }
                    if (m_inputParameterCollection["registrantcounty"] == string.Empty)
                    {
                        purchaseDomainReq.Registrant.county = "Unknown";
                    }
                    else
                    {
                        purchaseDomainReq.Registrant.county = m_inputParameterCollection["registrantcounty"];
                    }
                    purchaseDomainReq.Registrant.email = m_inputParameterCollection["registrantemail"];
                    purchaseDomainReq.Registrant.firstname = m_inputParameterCollection["registrantfirstname"];
                    purchaseDomainReq.Registrant.lastname = m_inputParameterCollection["registrantlastname"];
                    purchaseDomainReq.Registrant.orgname = m_inputParameterCollection["registrantorgname"];
                    if (!m_inputParameterCollection["registrantphone"].Equals(string.Empty))
                    {
                        purchaseDomainReq.Registrant.phone = FormatTelephoneNumber(m_inputParameterCollection["registrantphone"]);
                    }
                    if (m_inputParameterCollection["registrantpostcode"].Equals(string.Empty))
                    {
                        purchaseDomainReq.Registrant.postcode = "Unknown";
                    }
                    else
                    {
                        purchaseDomainReq.Registrant.postcode = m_inputParameterCollection["registrantpostcode"];
                    }
                    purchaseDomainReq.Registrant.town = m_inputParameterCollection["registranttown"];
                    purchaseDomainReq.confirmEmail = m_inputParameterCollection["confirmemail"];
                    purchaseDomainReq.free = Convert.ToBoolean(m_inputParameterCollection["free"]);
                    purchaseDomainReq.term = Convert.ToInt32(m_inputParameterCollection["term"]);

                    purchaseDomainReq.domain = domInfo;
                    purchaseDomainReq.accountInfo = accInfo;

                    //#region InsertIntoToken
                    //personDetails.FirstName = purchaseDomainReq.Registrant.firstname;
                    //personDetails.LastName = purchaseDomainReq.Registrant.lastname;
                    //personDetails.Title = "";
                    //addressDetails.Address1 = purchaseDomainReq.Registrant.addr1;
                    //addressDetails.Address2 = purchaseDomainReq.Registrant.addr2;
                    //addressDetails.Country = purchaseDomainReq.Registrant.country;
                    //addressDetails.County = purchaseDomainReq.Registrant.county;
                    //addressDetails.PostCode = purchaseDomainReq.Registrant.postcode;
                    //addressDetails.Town = purchaseDomainReq.Registrant.town;
                    //contactDetails.Email = purchaseDomainReq.Registrant.email;
                    //contactDetails.Telephone = purchaseDomainReq.Registrant.phone;
                    //InsertIntoToken(accInfo.accountNumber, purchaseDomainReq.Admin.email, Guid.Empty, personDetails, contactDetails, addressDetails);
                    //#endregion

                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                            ("VAS Adapters - RCOM: Posting Purchase domain to RCOM!!!");

                    string correlationData = order.Header.OrderId + ";" + order.Header.OrderKey + ";" + order.ServiceActionOrderItem.XmlIdKey + ";" + order.ServiceActionOrderItem.Header.CorrelationId + ";" + order.ServiceActionOrderItem.ServiceRoles[0].RoleInstanceXmlRef;
                    InsertDomainRequest(m_inputParameterCollection["domainname"], intermediateState, correlationData, " ", m_inputParameterCollection["accountnumber"]);

                    using (DMCWebServiceSoap service = this.dmcWebServiceSoap)
                    {
                        purchaseDomainRes = service.purchaseDomain(purchaseDomainReq);
                    }
                    if (purchaseDomainRes.domainResp.status == domainStatus.SUCCESS)
                    {
                        UpdateTransactionID(m_inputParameterCollection["domainname"], completedState, purchaseDomainRes.orderID);
                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                        if (m_inputParameterCollection.ContainsKey(Convert.ToString("domainstatus").ToLower()))
                        {
                            order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).Single().Value = "registered";
                        }

                        if (m_inputParameterCollection.ContainsKey(Convert.ToString("transactionId").ToLower()))
                        {
                            order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("transactionid", StringComparison.InvariantCultureIgnoreCase)).Single().Value = purchaseDomainRes.orderID;
                        }

                        //BCP 10 Project Horizon Change
                        //Code Added to Insert the blank values in DNP while Order is Provisioned from OOJ
                        if (m_inputParameterCollection.ContainsKey(Convert.ToString("SKUTYPE").ToLower()) && string.IsNullOrEmpty(m_inputParameterCollection["skutype"].ToString()))
                        {
                            order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("skutype", StringComparison.InvariantCultureIgnoreCase)).Single().Value = " ";
                        }

                        //BCP 10 Project Horizon Change
                        //Code Added to Insert the blank values in DNP while Order is Provisioned from OOJ
                        if (m_inputParameterCollection.ContainsKey(Convert.ToString("DNS_VERIFICATION_CHECK_STATUS").ToLower()) && string.IsNullOrEmpty(m_inputParameterCollection["dns_verification_check_status"].ToString()))
                        {
                            order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("dns_verification_check_status", StringComparison.InvariantCultureIgnoreCase)).Single().Value = " ";
                        }

                    }
                    else if (purchaseDomainRes.domainResp.status == domainStatus.FAILURE)
                    {
                        if (purchaseDomainRes.domainResp.errDescription.Contains("Domain name not available"))
                        {
                            order.ServiceActionOrderItem.IsvResponse.ErrorCode = "111";
                            order.ServiceActionOrderItem.IsvResponse.ErrorDescription = purchaseDomainRes.domainResp.errDescription;
                            order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                        }
                        else
                        {
                            order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                            order.ServiceActionOrderItem.IsvResponse.ErrorDescription = purchaseDomainRes.domainResp.errDescription;
                            order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                        }
                    }
                }
                else
                {
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                    if (m_inputParameterCollection.ContainsKey(Convert.ToString("domainstatus").ToLower()))
                    {
                        order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).Single().Value = "registered";
                    }
                }
            }
            else
            {
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
            }


            return order;
        }
        #endregion

        #region ModifyAccountTransferDomain
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder ModifyAccountTransferDomain()
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                ("VAS Adapters - RCOM: RequestProcessor.ModifyAccountTransferDomain()");
            AccountInfo accInfo = new AccountInfo();
            domainInfo domInfo = new domainInfo();
            transferDomainResponse trnsferDomRes;
            transferDomainRequest trnsferDomReq = new transferDomainRequest();
            accInfo.BTUsername = m_inputParameterCollection["btusername"];
            accInfo.BTPassword = m_inputParameterCollection["btpassword"];
            accInfo.accountNumber = m_inputParameterCollection["accountnumber"];

            if (m_inputParameterCollection.ContainsKey("domainname"))
            {
                string[] domains = new string[3];
                domains = m_inputParameterCollection["domainname"].Trim().Split('.');
                domInfo.sld = domains[0];
                if (domains.Length > 2)
                    domInfo.tld = domains[1] + "." + domains[2];
                else
                    domInfo.tld = domains[1];
            }
            trnsferDomReq.authCode = m_inputParameterCollection["authinfocode"];
            trnsferDomReq.confirmEmail = m_inputParameterCollection["confirmemail"];
            trnsferDomReq.free = Convert.ToBoolean(m_inputParameterCollection["free"]);
            trnsferDomReq.accountInfo = accInfo;
            trnsferDomReq.domain = domInfo;
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Posting transfer domain to RCOM!!!");
            string correlationData = order.Header.OrderId + ";" + order.Header.OrderKey + ";" + order.ServiceActionOrderItem.XmlIdKey + ";" + order.ServiceActionOrderItem.Header.CorrelationId + ";" + order.ServiceActionOrderItem.ServiceRoles[0].RoleInstanceXmlRef;
            InsertDomainRequest(m_inputParameterCollection["domainname"], intermediateState, correlationData, string.Empty, m_inputParameterCollection["accountnumber"]);
            using (DMCWebServiceSoap service = this.dmcWebServiceSoap)
            {
                trnsferDomRes = service.transferDomain(trnsferDomReq);
            }
            if (trnsferDomRes.domainResp.status == domainStatus.SUCCESS)
            {
                UpdateTransactionID(m_inputParameterCollection["domainname"], transferInState, trnsferDomRes.trackingID);
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
            }
            else
            {
                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = trnsferDomRes.domainResp.errDescription;
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
            }
            return order;
        }
        #endregion

        #region ModifyAccountForUpdateZoneConfig
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder ModifyAccountForUpdateZoneConfig()
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                ("VAS Adapters - RCOM: RequestProcessor.ModifyAccountForUpdateZoneConfig()");

            updateZoneConfigResp zoeConfigRes;
            updateZoneConfigReq zoneConfigReq;
            AccountInfo accInfo = new AccountInfo();
            domainInfo domInfo = new domainInfo();
            zoneConfigReq = new updateZoneConfigReq();
            bool updateDomainMxRecord = false;
            accInfo.BTUsername = m_inputParameterCollection["btusername"];
            accInfo.BTPassword = m_inputParameterCollection["btpassword"];
            accInfo.accountNumber = m_inputParameterCollection["accountnumber"];
            string[] domains = new string[3];
            domains = m_inputParameterCollection["domainname"].Trim().Split('.');
            domInfo.sld = domains[0];
            if (domains.Length > 2)
                domInfo.tld = domains[1] + "." + domains[2];
            else
                domInfo.tld = domains[1];

            updateDomainMxRecord = (!string.IsNullOrEmpty(m_inputParameterCollection["recordtype"])) ? m_inputParameterCollection["recordtype"].Equals("MX", StringComparison.OrdinalIgnoreCase) : false;

            zoneConfigReq.recordType = (updateDomainMxRecord) ? RecordTypes.MX : RecordTypes.A;
            zoneConfigReq.recordKey = m_inputParameterCollection["recordkey"];
            zoneConfigReq.recordPriority = (updateDomainMxRecord) ? Convert.ToInt32(ConfigurationManager.AppSettings["RecordPriorityForDomainMxRecord"]) : Convert.ToInt32(m_inputParameterCollection["recordpriority"]);
            zoneConfigReq.recordValue = m_inputParameterCollection["recordvalue"];
            zoneConfigReq.aInfo = accInfo;
            zoneConfigReq.dInfo = domInfo;
            using (DMCWebServiceSoap service = this.dmcWebServiceSoap)
            {
                zoeConfigRes = service.updateZoneConfig(zoneConfigReq);
            }
            if (zoeConfigRes.status == zoneUpdateStatus.SUCCESS)
            {
                string requiresMx = ConfigurationManager.AppSettings["RequiresMxRecord"].ToString();
                if (updateDomainMxRecord && !string.IsNullOrEmpty(requiresMx) && Convert.ToBoolean(requiresMx))
                {
                    order = UpdateZoneConfigForMxRecord(order);
                }
                else
                {
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                }
            }
            else
            {
                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = zoeConfigRes.errDescription;
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
            }
            return order;
        }

        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder UpdateZoneConfigForMxRecord(BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order)
        {
            updateZoneConfigResp zoeConfigRes;
            updateZoneConfigReq zoneConfigReq;
            AccountInfo accInfo = new AccountInfo();
            domainInfo domInfo = new domainInfo();
            zoneConfigReq = new updateZoneConfigReq();
            accInfo.BTUsername = m_inputParameterCollection["btusername"];
            accInfo.BTPassword = m_inputParameterCollection["btpassword"];
            accInfo.accountNumber = m_inputParameterCollection["accountnumber"];
            string[] domains = new string[3];
            domains = m_inputParameterCollection["domainname"].Trim().Split('.');
            domInfo.sld = domains[0];
            if (domains.Length > 2)
                domInfo.tld = domains[1] + "." + domains[2];
            else
                domInfo.tld = domains[1];

            string mxInfo = domInfo.sld + "-" + domInfo.tld.Replace('.', '-') + "." + ConfigurationManager.AppSettings["MXRecordValue"].ToString();
            zoneConfigReq.recordType = RecordTypes.MX;
            zoneConfigReq.recordKey = "@";
            zoneConfigReq.recordPriority = Convert.ToInt32(m_inputParameterCollection["recordpriority"]);
            zoneConfigReq.recordValue = mxInfo;
            zoneConfigReq.aInfo = accInfo;
            zoneConfigReq.dInfo = domInfo;
            using (DMCWebServiceSoap service = this.dmcWebServiceSoap)
            {
                zoeConfigRes = service.updateZoneConfig(zoneConfigReq);
            }
            if (zoeConfigRes.status == zoneUpdateStatus.SUCCESS)
            {
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
            }
            else
            {
                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = zoeConfigRes.errDescription;
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
            }
            return order;
        }

        #endregion

        #region ModifyAccountForChangeFreeStatus
        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder ModifyAccountForChangeFreeStatus()
        {
            if (!m_inputParameterCollection["domainname"].Trim().Equals(string.Empty))
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                    ("VAS Adapters - RCOM: RequestProcessor.ModifyAccountForChangeFreeStatus()");
                string IsC2BcallRequired = ConfigurationManager.AppSettings["IsC2BcallRequired"].ToString();
                changeFreeStatusResp freeStatusRes;
                changeFreeStatusReq freeStatusReq;
                bool response = false;
                AccountInfo accInfo = new AccountInfo();
                domainInfo domInfo = new domainInfo();
                freeStatusReq = new changeFreeStatusReq();
                accInfo.BTUsername = m_inputParameterCollection.ContainsKey("btusername") ? m_inputParameterCollection["btusername"] : ConfigurationManager.AppSettings["btusername"];
                accInfo.BTPassword = m_inputParameterCollection.ContainsKey("btpassword") ? m_inputParameterCollection["btpassword"] : ConfigurationManager.AppSettings["btpassword"];
                accInfo.accountNumber = m_inputParameterCollection.ContainsKey("accountnumber") ? m_inputParameterCollection["accountnumber"] : m_inputParameterCollection["organizationid"];

                string[] domains;
                domains = m_inputParameterCollection["domainname"].Trim().Split('.');
                freeStatusReq.SLD = new string[1];
                freeStatusReq.TLD = new string[1];
                freeStatusReq.SLD[0] = domains[0];
                if (domains.Length > 2)
                {
                    freeStatusReq.TLD[0] = domains[1] + "." + domains[2];
                }
                else
                    freeStatusReq.TLD[0] = domains[1];

                freeStatusReq.aInfo = accInfo;
                using (DMCWebServiceSoap service = this.dmcWebServiceSoap)
                {
                    freeStatusRes = service.changeFreeStatus(freeStatusReq);
                }
                if (freeStatusRes != null && freeStatusRes.DomainResp != null && freeStatusRes.DomainResp.Length > 0)
                {
                    if (freeStatusRes.DomainResp[0].status == domainStatus.SUCCESS)
                    {
                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                    }
                    else
                    {
                        if (freeStatusRes.DomainResp[0].errDescription !=null && freeStatusRes.DomainResp[0].errDescription.ToLower().Contains("domains are not present within the bt account"))
                        {
                            if (!string.IsNullOrEmpty(IsC2BcallRequired) && Convert.ToBoolean(IsC2BcallRequired))
                            {
                                string orgid = m_inputParameterCollection["organizationid"].ToString();
                                string domainname = m_inputParameterCollection["domainname"].ToString();
                                string c2bresponse = C2BHelper.CheckIsExternalDomainInC2B(orgid, domainname);
                                if (c2bresponse == "External")
                                {
                                    List<ClientServiceRoleCharacteristic> clientServiceRoleCharacteristic = new List<ClientServiceRoleCharacteristic>();
                                    clientServiceRoleCharacteristic.Add(new ClientServiceRoleCharacteristic() { action = "UPDATE", name = "LICENSETYPE", value = "EXTERNAL" });
                                    response = UpdateClientServiceRoleCharacteristic(m_inputParameterCollection["adminuser"], order.ServiceActionOrderItem.Header.ServiceInstanceID.ToString(), clientServiceRoleCharacteristic);
                                    //check response from dnp
                                    if (response)
                                    {
                                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                                    }
                                    else
                                    {
                                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                                        order.ServiceActionOrderItem.IsvResponse.ErrorDescription = "DnP Error: Error while updating LicneseType in DnP";
                                        order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                                    }
                                }
                                else if (c2bresponse == "Notfound")
                                {
                                    response = UpdateServiceInstanceStatus(m_inputParameterCollection["adminuser"], order.ServiceActionOrderItem.Header.ServiceInstanceID.ToString());
                                    //check dnp response
                                    if (response)
                                    {
                                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                                    }
                                    else
                                    {
                                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                                        order.ServiceActionOrderItem.IsvResponse.ErrorDescription = "DnP Error: Error while updating service instance status to INACTIVE in DnP";
                                        order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                                    }
                                }
                                else
                                {
                                    // domin is internal so do nothing
                                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                                    order.ServiceActionOrderItem.IsvResponse.ErrorDescription = "Domains are not present within the BT account";
                                    order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                                }
                            }
                            else
                            {
                                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = freeStatusRes.DomainResp[0].errDescription;
                                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                            }
                        }
                        else
                        {
                            order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                            order.ServiceActionOrderItem.IsvResponse.ErrorDescription = freeStatusRes.DomainResp[0].errDescription;
                            order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                        }
                    }
                }
                else if (freeStatusRes.OverallResponse == overallStatus.SUCCESS)
                {
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                }
                else
                {
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                    order.ServiceActionOrderItem.IsvResponse.ErrorDescription = "No error message from RCOM";
                    order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                }
            }
            else
            {
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
            }
            return order;
        }
        #endregion

        #region ModifyAccountForSetFreeStatus
        public void ModifyAccountForSetFreeStatus()
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                ("VAS Adapters - RCOM: RequestProcessor.ModifyAccountForSetFreeStatus()");

            changeFreeStatusResp freeStatusRes;
            changeFreeStatusReq freeStatusReq;
            AccountInfo accInfo = new AccountInfo();
            domainInfo domInfo = new domainInfo();
            freeStatusReq = new changeFreeStatusReq();
            accInfo.BTUsername = m_inputParameterCollection["btusername"];
            accInfo.BTPassword = m_inputParameterCollection["btpassword"];
            accInfo.accountNumber = m_inputParameterCollection["accountnumber"];

            string[] domains = new string[3];
            domains = m_inputParameterCollection["domainname"].Trim().Split('.');
            freeStatusReq.SLD[0] = domains[0];
            if (domains.Length > 2)
                freeStatusReq.TLD[0] = domains[1] + "." + domains[2];
            else
                freeStatusReq.TLD[0] = domains[1];

            freeStatusReq.aInfo = accInfo;
            using (DMCWebServiceSoap service = this.dmcWebServiceSoap)
            {
                freeStatusRes = service.setFreeStatus(freeStatusReq);
            }
        }
        #endregion

        #region InsertIntoToken
        public void InsertIntoToken(string organizationId, string primaryUsername, Guid guid, Person personDetails, Contact contactDetails, Address addressDetails)
        {
            TokenResponse response = null;
            TokenObject cacheObject = new TokenObject();
            cacheObject.organizationId = organizationId;
            cacheObject.person = personDetails;
            cacheObject.address = addressDetails;
            cacheObject.contact = contactDetails;
            cacheObject.primaryUserId = primaryUsername;
            TokenRequest request = new TokenRequest();
            request.data = cacheObject.ToString();
            request.expiryDateTime = DateTime.Now.AddMinutes(5);
            request.IsExpired = false;
            request.tokenId = guid.ToString();
            using (ChannelFactory<ISaaSTokenManager> factory = new ChannelFactory<ISaaSTokenManager>("BasicHttpBinding_ISaaSTokenManager"))
            {
                ISaaSTokenManager svc = factory.CreateChannel();
                response = svc.AddToken(request);
            }
            if (response.responseCode == false)
            {
                throw new Exception("Insert into cache failed" + response.errorDescription);
            }
        }
        #endregion

        #region GetTokenData
        public TokenResponse GetTokenData(string organizationId, string guid)
        {
            TokenResponse response = null;
            TokenRequest request = new TokenRequest();
            request.tokenId = guid;
            using (ChannelFactory<ISaaSTokenManager> factory = new ChannelFactory<ISaaSTokenManager>("BasicHttpBinding_ISaaSTokenManager"))
            {
                ISaaSTokenManager svc = factory.CreateChannel();
                response = svc.GetTokenData(request);
            }
            if (response.responseCode == false)
            {
                throw new Exception("Get token data failed !!" + response.errorDescription);
            }
            else
            {
                return response;
            }
        }
        #endregion

        #region ExpireToken
        public void ExpireToken(string organizationId, string guid)
        {
            TokenResponse response = null;
            TokenRequest request = new TokenRequest();
            request.tokenId = guid;
            using (ChannelFactory<ISaaSTokenManager> factory = new ChannelFactory<ISaaSTokenManager>("BasicHttpBinding_ISaaSTokenManager"))
            {
                ISaaSTokenManager svc = factory.CreateChannel();
                response = svc.ExpireToken(request);
            }
        }
        #endregion

        #region InsertIntoBlackListedDomain
        public QueryOrderResponse InsertIntoBlackListedDomain(BT.Core.ISVAdapter.ISVService.Entities.QueryOrder order)
        {
            QueryOrderResponse response = null;
            try
            {
                string blackListedDomain = order.Attributes.Where(gs => gs.Name.Equals("domainname", StringComparison.InvariantCultureIgnoreCase)).Single().Value;
                InsertBlackListedDomain(blackListedDomain);
                response = new QueryOrderResponse();
                response.BlackListedDomain = blackListedDomain;
                response.IsvResponse = new BT.Core.ISVAdapter.ISVService.Entities.ISVResponse();
                response.IsvResponse.ResponseCode = true;
            }
            catch (Exception ex)
            {
                response = new QueryOrderResponse();
                response.IsvResponse = new BT.Core.ISVAdapter.ISVService.Entities.ISVResponse();
                response.IsvResponse.ResponseCode = false;
                response.IsvResponse.ErrorCode = "777";
                response.IsvResponse.ErrorDescription = "Failed to insert blacklisted domain" + ex.Message;
            }
            return response;
        }
        #endregion

        #region Database Calls

        public void InsertDomainRequest(string domainName, int statusId, string correlationData, string transactionId, string organizationId)
        {
            RCOMDBCommandsDAL RCOMDAL = new RCOMDBCommandsDAL();
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM:Inserting Purchase domain in RCOM Adapter!!!" + domainName + statusId + correlationData + transactionId + organizationId);
            if (!domainName.Equals(string.Empty))
            {
                RCOMDAL.InsertDomainName(domainName, statusId, correlationData, transactionId, organizationId);
            }
        }

        public bool CheckDomainName(string domainName)
        {
            BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset.RCOM.Check_DomainNamesDataTable data = null;
            RCOMDBCommandsDAL RCOMDal = new RCOMDBCommandsDAL();
            bool isPresent = false;
            if (!domainName.Equals(string.Empty))
            {
                data = RCOMDal.GetDataForDomains(domainName);
            }
            if (data.Rows.Count > 0)
            {
                isPresent = true;
            }
            else
            {
                RCOM.Check_ExternalDomainDataTable dtable = RCOMDal.GetDataForExternalDomain(domainName);
                if (dtable.Rows.Count > 0)
                {
                    isPresent = true;
                }
            }

            return isPresent;
        }

        public bool CheckDomainName(string domainName, int domainStatus)
        {
            BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset.RCOM.Check_DomainNamesDataTable data = null;
            RCOMDBCommandsDAL RCOMDal = new RCOMDBCommandsDAL();
            bool isPresent = false;
            if (!domainName.Equals(string.Empty))
            {
                data = RCOMDal.GetDataForDomains(domainName);
            }
            //returns olny 1 row value
            if (data.Rows.Count > 0 && data[0].StatusID == domainStatus)
            {
                isPresent = true;
            }
            else
            {
                RCOM.Check_ExternalDomainDataTable dtable = RCOMDal.GetDataForExternalDomain(domainName);
                if (dtable.Rows.Count > 0)
                {
                    isPresent = true;
                }
            }

            return isPresent;
        }

        public void InsertBlackListedDomain(string blackListedDomain)
        {
            RCOMDBCommandsDAL RCOMDAL = new RCOMDBCommandsDAL();

            if (!blackListedDomain.Equals(string.Empty))
            {
                RCOMDAL.InsertBlacklistedDomainName(blackListedDomain);
            }
        }

        public bool CheckBlacklistedDomainName(string blacklistedDomainName)
        {
            RCOMDBCommandsDAL RCOMDal = new RCOMDBCommandsDAL();
            int rowCount = 0;
            bool isPresent = false;
            if (!blacklistedDomainName.Equals(string.Empty))
            {
                rowCount = RCOMDal.GetDataForBlacklistedDomains(blacklistedDomainName);
            }
            if (rowCount > 0)
            {
                isPresent = true;
            }

            return isPresent;
        }

        public bool GetDataFromDomains(string domainName, out int stateId, out DateTime datetime, out string correlationData)
        {
            stateId = -1;
            bool isPresent = false;
            datetime = DateTime.MinValue;
            BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset.RCOM.Check_DomainNamesDataTable data = null;
            correlationData = string.Empty;
            RCOMDBCommandsDAL RCOMDal = new RCOMDBCommandsDAL();
            data = RCOMDal.GetDataForDomains(domainName);
            if (data.Rows.Count > 0)
            {
                isPresent = true;
                datetime = Convert.ToDateTime(data.Rows[0]["createddatetime"]);
                stateId = Convert.ToInt16(data.Rows[0]["StatusID"]);
                correlationData = data.Rows[0]["correlationData"].ToString();
            }
            return isPresent;

        }

        public bool GetDataFromExternalDomains(string domainName)
        {

            bool isExternalDomainPresent = false;

            BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset.RCOM.Check_ExternalDomainDataTable data = null;

            RCOMDBCommandsDAL RCOMDal = new RCOMDBCommandsDAL();
            data = RCOMDal.GetDataForExternalDomain(domainName);
            if (data.Rows.Count > 0)
            {
                isExternalDomainPresent = true;

            }
            return isExternalDomainPresent;

        }

        public void DeleteFromDomain(string domainName)
        {
            RCOMDBCommandsDAL rcomDal = new RCOMDBCommandsDAL();
            rcomDal.DeleteDomain(domainName);
        }

        public void UpdateStateId(string domainName, int stateId, string correlationData)
        {
            RCOMDBCommandsDAL rcomDal = new RCOMDBCommandsDAL();
            rcomDal.UpdateStatusForDomain(domainName, stateId, correlationData);
        }

        public int CheckTransactionId(string transactionId)
        {
            RCOMDBCommandsDAL rcomDal = new RCOMDBCommandsDAL();
            int count = rcomDal.CheckTransactionId(transactionId);
            return count;
        }

        public void UpdateTransactionID(string domainName, int stateId, string transactionID)
        {
            RCOMDBCommandsDAL rcomDal = new RCOMDBCommandsDAL();
            rcomDal.UpdateTransactionId(domainName, stateId, transactionID);
        }

        internal bool CheckOrganizationId(string orgId, string tld)
        {
            bool defaultResponse = false;
            RCOMDBCommandsDAL rcomDal = new RCOMDBCommandsDAL();
            RCOM.Check_DomainNamesDataTable result = rcomDal.GetByOrganizationID(orgId);
            foreach (DataRow row in result.Rows)
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("current row Statusid :" + row["statusID"]);
                if (row["statusID"].Equals(intermediateState))
                {
                    string[] domain = row["domainname"].ToString().Split('.');
                    if (tld.Equals("com", StringComparison.InvariantCultureIgnoreCase) && domain.Length == 2)
                    {
                        defaultResponse = true;
                    }
                    else if (tld.Equals("cc", StringComparison.InvariantCultureIgnoreCase) && domain.Length > 2)
                    {
                        defaultResponse = true;
                    }
                }
            }
            return defaultResponse;
        }
        #endregion

        #region IsHeaderValid

        public SSOStatus IsHeaderValid(SSOHeader ssoHeader, string orgId)
        {
            SSOStatus ssoStatus;
            if (string.IsNullOrEmpty(ssoHeader.OrgId) && string.IsNullOrEmpty(ssoHeader.GUID))
            {
                ssoStatus = SSOStatus.Missing;
            }
            else
            {
                if (string.IsNullOrEmpty(ssoHeader.OrgId))
                    ssoStatus = SSOStatus.OrgIdMissing;
                else if (string.IsNullOrEmpty(ssoHeader.GUID))
                    ssoStatus = SSOStatus.GUIDMissing;
                else
                {
                    TokenResponse tokenResponse = GetTokenData(orgId, ssoHeader.GUID);
                    if (tokenResponse != null)
                    {
                        if (tokenResponse.tokenResults[0].tokenId.Equals(ssoHeader.GUID))
                        {
                            ssoStatus = SSOStatus.Passed;
                        }
                        else
                        {
                            ssoStatus = SSOStatus.GUIDExpired;
                        }
                    }
                    else
                    {
                        ssoStatus = SSOStatus.GUIDExpired;
                    }
                }
            }
            return ssoStatus;
        }

        #endregion

        #region PostToPE
        internal OrderResponse PostToPE(string orgId, bool isPresentInDB, bool isFree, string domainName, string txId)
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("PostToPE");
            Order request = new Order();
            OrderResponse response = null;
            try
            {
                StandardHeader header = new StandardHeader();
                header.serviceAddressing = new BT.SaaS.Core.Shared.Entities.ServiceAddressing();
                header.serviceAddressing.from = "RCOMCallback";
                string customerId = GetCustomerIdByCustomerKey(orgId, 1);
                Random rand = new Random();

                request.Header.CeaseReason = null;

                request.Header.OrderKey = "RCOM-ADAP-" + orgId + "-" + rand.Next(99999999);
                request.Header.ServiceProviderID = 1;
                request.Header.EffectiveDateTime = System.DateTime.Now;
                request.Header.OrderDateTime = System.DateTime.Now;
                request.Header.Status = OrderStatusEnum.@new;
                request.Header.Customer = new Customer();
                request.Header.Customer.Status = BT.SaaS.Core.Shared.Entities.DataStatusEnum.done;
                request.Header.Customer.CustomerId = customerId;
                request.Header.Customer.CustomerKey = orgId;


                request.Header.Customer.Contacts = new List<BT.SaaS.Core.Shared.Entities.Contact>();
                BT.SaaS.Core.Shared.Entities.Contact contact = new BT.SaaS.Core.Shared.Entities.Contact();
                contact.Address = new BT.SaaS.Core.Shared.Entities.Address();
                contact.Address.UkAddress = new UKAddress();
                request.Header.Customer.Contacts.Add(contact);
                request.Header.Users = new List<User>();

                User user = new BT.SaaS.Core.Shared.Entities.User();
                user.Status = BT.SaaS.Core.Shared.Entities.DataStatusEnum.done;
                user.Type = "ADMIN";
                user.XmlIdKey = "US-1";
                user.IdentityCredential = new List<IdentityCredential>();
                IdentityCredential credential = new IdentityCredential();
                credential.Identity = new BT.SaaS.Core.Shared.Entities.ClientIdentity();
                credential.XmlIdKey = "USI-1";
                credential.Identity.identifier = GetPrimaryUserFromDnP(orgId);
                credential.Identity.identiferNamepace = "BTCOM";
                credential.Identity.IdentityAlias = IdentifierAliasEnum.no;
                credential.Credential = new BT.SaaS.Core.Shared.Entities.ClientCredential();
                credential.NewCredential = new BT.SaaS.Core.Shared.Entities.ClientCredential();
                user.IdentityCredential.Add(credential);
                request.Header.Users.Add(user);

                request.ProductOrderItems = new List<ProductOrderItem>();

                ProductOrderItem productOrderItem = new BT.SaaS.Core.Shared.Entities.ProductOrderItem();
                productOrderItem.Header.Status = BT.SaaS.Core.Shared.Entities.DataStatusEnum.notDone;
                productOrderItem.Header.Quantity = "1";
                productOrderItem.XmlIdKey = "PO-1";
                productOrderItem.Header.OrderItemKey = "1";
                if (isFree)
                {
                    productOrderItem.Header.ProductCode = "S0001331-PR0000000004008-";
                    productOrderItem.Header.ProductName = "New Domain_Free";
                }
                else
                {
                    string[] domains = domainName.Split('.');
                    if (domains.Length < 3)
                    {
                        productOrderItem.Header.ProductCode = "S0001331-PR0000000004008-TA0000000004010";
                        productOrderItem.Header.ProductName = "New Domain_Paid_gTLD";
                    }
                    else
                    {
                        productOrderItem.Header.ProductCode = "S0001331-PR0000000004008-TA0000000004009";
                        productOrderItem.Header.ProductName = "New Domain_Paid_ccTLD";
                    }
                }
                if (isPresentInDB || isFree)
                {
                    request.Header.Action = OrderActionEnum.registerDomain;
                }
                else
                {
                    request.Header.Action = OrderActionEnum.provide;
                }
                productOrderItem.RoleInstances = new List<RoleInstance>();
                RoleInstance roleInstance = new RoleInstance();
                roleInstance.Action = BT.SaaS.Core.Shared.Entities.RoleInstanceActionEnum.add;
                roleInstance.RoleType = "ADMIN";
                roleInstance.XmlIdKey = "RI-1";
                roleInstance.UserXmlRef = "US-1";
                roleInstance.UserIdentityCredentialXmlRef = "USI-1";
                roleInstance.Attributes = new List<BT.SaaS.Core.Shared.Entities.Attribute>();
                roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "organizationId", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = orgId });
                roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "isFree", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = isFree.ToString() });
                roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "domainName", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = domainName });
                if (request.Header.Action == OrderActionEnum.provide)
                {
                    roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "PRICEFREQUENCY", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = "MONTHLY" });
                    roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "PRICETYPE", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = "oneoff" });
                }
                string[] domain = domainName.Split('.');
                if (domain.Length < 3)
                {
                    roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "licenseType", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = "GTLD" });
                }
                else
                {
                    roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "licenseType", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = "CCTLD" });
                }

                productOrderItem.ServiceInstances = new System.Collections.Generic.List<BT.SaaS.Core.Shared.Entities.ServiceInstance>();
                ServiceInstance serviceInstance = new BT.SaaS.Core.Shared.Entities.ServiceInstance();
                if (isPresentInDB || isFree)
                {
                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Into service instance");
                    serviceInstance.ServiceCode = Properties.Settings.Default.RCOMServiceCode;
                    serviceInstance.ServiceInstanceId = GetServiceInstanceId(domainName, credential.Identity.identifier, isFree, txId);
                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                      ("VAS Adapters - RCOM: Into service instance" + serviceInstance.ServiceInstanceId);
                }
                serviceInstance.ServiceRoles = new System.Collections.Generic.List<BT.SaaS.Core.Shared.Entities.ServiceRole>();
                BT.SaaS.Core.Shared.Entities.ServiceRole serviceRole = new BT.SaaS.Core.Shared.Entities.ServiceRole();
                serviceRole.roleAttributes = new System.Collections.Generic.List<BT.SaaS.Core.Shared.Entities.Attribute>();
                serviceInstance.ServiceRoles.Add(serviceRole);
                productOrderItem.ServiceInstances.Add(serviceInstance);
                productOrderItem.RoleInstances.Add(roleInstance);
                request.ProductOrderItems.Add(productOrderItem);
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Posting to PE...fingers crossed...Order:  " + request.ToString());
                using (OrderReceiver.OrderClient client = new BT.ISVAdapter.RCOMServiceProvider.OrderReceiver.OrderClient())
                {
                    response = client.SubmitOrder(header, request);
                }
                return response;
            }
            catch (Exception ex)
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("MSEOAdapter Mapping Exception : " + ex.ToString());
                throw ex;
            }
        }
        #endregion

        #region GetServiceInstanceId
        private Guid GetServiceInstanceId(string domainName, string primaryUserId, bool isFree, string txid)
        {
            string licenseType = string.Empty;
            Guid serviceInstanceId = Guid.Empty;
            bool isLicenseTypevalid = false, isDomainStatusValid = false;
            GetClientProfileResponse profileResponse = GetClientProfile(primaryUserId);
            if (profileResponse != null && profileResponse.standardHeader != null && profileResponse.standardHeader.serviceState != null && profileResponse.standardHeader.serviceState.stateCode == "0")
            {
                foreach (ClientServiceInstance instance in profileResponse.getClientProfileRes.clientProfile.clientServiceInstance)
                {
                    if (instance.clientServiceInstanceIdentifier.value.Equals(Properties.Settings.Default.RCOMServiceCode, StringComparison.InvariantCultureIgnoreCase))
                    {
                        foreach (ClientServiceRole clientServiceRole in instance.clientServiceRole)
                        {
                            if (clientServiceRole.id.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase))
                            {
                                foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic in clientServiceRole.clientServiceRoleCharacteristic)
                                {
                                    if (isFree)
                                    {
                                        if (clientServiceRoleCharacteristic.name.Equals("TRANSACTIONID", StringComparison.InvariantCultureIgnoreCase)
                                            && clientServiceRoleCharacteristic.value.Equals(txid, StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            isLicenseTypevalid = true;
                                            isDomainStatusValid = true;
                                        }
                                    }
                                    else
                                    {
                                        if (clientServiceRoleCharacteristic.name.Equals("domainname", StringComparison.InvariantCultureIgnoreCase)
                                            && clientServiceRoleCharacteristic.value.Equals(domainName, StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            isLicenseTypevalid = true;
                                            isDomainStatusValid = true;
                                        }
                                    }
                                    if (isLicenseTypevalid && isDomainStatusValid)
                                    {
                                        serviceInstanceId = new Guid(instance.name);
                                        break;
                                    }
                                }
                            }
                            if (serviceInstanceId != Guid.Empty)
                            {
                                break;
                            }
                        }
                    }
                    if (serviceInstanceId != Guid.Empty)
                    {
                        break;
                    }
                }
            }
            else
            {
                throw new Exception("DnP Get client porfile call failed" + profileResponse.getClientProfileRes.messages[0].description);
            }
            if (serviceInstanceId == Guid.Empty)
            {
                throw new Exception("No matching service instance id found from DnP response!!");
            }
            return serviceInstanceId;
        }
        #endregion


        #region GetPrimaryUserFromDnP
        public string GetPrimaryUserFromDnP(string orgId)
        {
            DPUserList users = null;
            string filterString = string.Empty;
            string[] propertiesToLoad = new string[] 
                                        { 
                                            DP_LDAP_Properties.CRM_CUSTOMER_KEY,                                             
                                            DP_LDAP_Properties.ROLE_TYPE, 
                                            DP_LDAP_Properties.USER_NAME                                          
                                        };
            if (orgId != string.Empty)
            {
                filterString = string.Format("(&((CRM_CUSTOMER_KEY={0})(ROLE_TYPE=ADMIN)))", orgId);
            }
            else
            {
                throw new Exception("Org id is empty...not calling DnP to get primary user!!");
            }


            using (DirectoryEntry directoryEntry = new DirectoryEntry(Properties.Settings.Default.DnPLdapPath + Properties.Settings.Default.DnPLdap_SaaS,
                           Properties.Settings.Default.DnPLdapUsername, Properties.Settings.Default.DnPLdapPassword, (AuthenticationTypes)(Enum.Parse(typeof(AuthenticationTypes), Properties.Settings.Default.DPLDAPAuthenticationType))))
            {

                using (DirectorySearcher directorySearcher = new DirectorySearcher(
                        directoryEntry, filterString, propertiesToLoad, SearchScope.OneLevel))
                {
                    directorySearcher.SizeLimit = 0;

                    using (SearchResultCollection results = directorySearcher.FindAll())
                    {
                        if (results != null && results.Count > 0)
                        {
                            users = new DPUserList();

                            DPUser user = null;
                            foreach (SearchResult result in results)
                            {
                                user = new DPUser();

                                if (result.Properties[DP_LDAP_Properties.CRM_CUSTOMER_KEY] != null && result.Properties[DP_LDAP_Properties.CRM_CUSTOMER_KEY].Count > 0)
                                    user.CustomerKey = Encoding.ASCII.GetString((byte[])result.Properties[DP_LDAP_Properties.CRM_CUSTOMER_KEY][0]);

                                if (result.Properties[DP_LDAP_Properties.ROLE_TYPE] != null && result.Properties[DP_LDAP_Properties.ROLE_TYPE].Count > 0)
                                    user.RoleType = Encoding.ASCII.GetString((byte[])result.Properties[DP_LDAP_Properties.ROLE_TYPE][0]);

                                if (result.Properties[DP_LDAP_Properties.USER_NAME] != null && result.Properties[DP_LDAP_Properties.USER_NAME].Count > 0)
                                    user.UserName = result.Properties[DP_LDAP_Properties.USER_NAME][0].ToString();

                                if (user.CustomerKey != null || user.UserName != null)
                                {
                                    users.DPUsers.Add(user);
                                }
                            }
                        }
                    }
                }
            }
            if (users.DPUsers.Count > 1)
            {
                throw new Exception("OrganizationId:" + orgId + " has more than one primary user!!");
            }
            return users.DPUsers[0].UserName;
        }
        #endregion

        #region GetCustomerIdByCustomerKey
        private string GetCustomerIdByCustomerKey(string orgId, int serviceProviderId)
        {
            int customerId;
            using (ChannelFactory<ICustomerService> factory = new ChannelFactory<ICustomerService>(@"httpCustomerService"))
            {
                ICustomerService svc = factory.CreateChannel();
                customerId = svc.GetCustomerIdByCustomerKey(orgId, serviceProviderId);
            }
            return customerId.ToString();
        }
        #endregion

        #region SendResponseToPE
        internal void SendResponseToPE(BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order)
        {
            base.SendCreateAccountResponse(order);
        }
        #endregion

        #region GetOrgLicenseInfo
        internal OrgInfo GetOrgLicenseInfo(string organizationId)
        {
            int ccCount = 0, comCount = 0;
            OrgInfo orgInfo = new OrgInfo();
            orgInfo.OrgId = organizationId;
            orgInfo.ResponseHeader = new responseHeader();
            string primaryUser = GetPrimaryUserFromDnP(organizationId);
            GetClientProfileResponse profileResponse = GetClientProfile(primaryUser);
            if (profileResponse != null && profileResponse.standardHeader != null && profileResponse.standardHeader.serviceState != null && profileResponse.standardHeader.serviceState.stateCode == "0")
            {
                foreach (ClientServiceInstance instance in profileResponse.getClientProfileRes.clientProfile.clientServiceInstance)
                {
                    if (instance.clientServiceInstanceIdentifier.value.Equals(Properties.Settings.Default.RCOMServiceCode, StringComparison.InvariantCultureIgnoreCase)
                        && instance.clientServiceInstanceStatus.value.Equals("ACTIVE", StringComparison.InvariantCultureIgnoreCase))
                    {
                        foreach (ClientServiceRole clientServiceRole in instance.clientServiceRole)
                        {
                            if (clientServiceRole.id.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase))
                            {
                                foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic in clientServiceRole.clientServiceRoleCharacteristic)
                                {
                                    if (clientServiceRoleCharacteristic.name.Equals("DOMAINSTATUS", StringComparison.InvariantCultureIgnoreCase)
                                                && clientServiceRoleCharacteristic.value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic1 in clientServiceRole.clientServiceRoleCharacteristic)
                                        {
                                            if (clientServiceRoleCharacteristic1.name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)
                                                && clientServiceRoleCharacteristic1.value.Equals("CCTLD", StringComparison.InvariantCultureIgnoreCase))
                                            {
                                                ccCount = ccCount + 1;
                                            }
                                            else if (clientServiceRoleCharacteristic1.name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)
                                                && clientServiceRoleCharacteristic1.value.Equals("GTLD", StringComparison.InvariantCultureIgnoreCase))
                                            {
                                                comCount = comCount + 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                orgInfo.Entitlements = new Entitlement[2];
                orgInfo.Entitlements[0] = new Entitlement();
                orgInfo.Entitlements[0].TLD = TLD.CC;
                orgInfo.Entitlements[0].Count = ccCount;
                orgInfo.Entitlements[1] = new Entitlement();
                orgInfo.Entitlements[1].TLD = TLD.COM;
                orgInfo.Entitlements[1].Count = comCount;
                orgInfo.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                orgInfo.ResponseHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
            }
            else
            {
                throw new Exception("DnP Get client porfile call failed" + profileResponse.getClientProfileRes.messages[0].description);
            }
            return orgInfo;
        }
        #endregion

        #region CheckMXRecord
        internal QueryOrderResponse CheckMXRecord(BT.Core.ISVAdapter.ISVService.Entities.QueryOrder order)
        {
            QueryOrderResponse response = new QueryOrderResponse();
            response.IsvResponse = new BT.Core.ISVAdapter.ISVService.Entities.ISVResponse();
            string domainName = order.Attributes.Where(gs => gs.Name.Equals("domainname", StringComparison.InvariantCultureIgnoreCase)).Single().Value;
            string[] mxRecord = DnsMx.GetMXRecords(domainName);
            for (int i = 0; i < mxRecord.Length; i++)
            {
                if (mxRecord[i].Equals("ibmr.btconnect.com", StringComparison.InvariantCultureIgnoreCase))
                {
                    response.IsMXRecordPresent = true;
                    response.IsvResponse.ResponseCode = true;
                    RCOMDBCommandsDAL rcomDB = new RCOMDBCommandsDAL();
                    RCOM.Check_ExternalDomainDataTable dtable = rcomDB.GetDataForExternalDomain(domainName);
                    if (dtable.Rows.Count > 0)
                    {
                        response.ExternalDomainOrderKey = "RD-RCOM-" + dtable.Rows[0]["OrderKey"].ToString();
                    }
                    break;
                }
                else
                {
                    response.IsMXRecordPresent = false;
                    response.IsvResponse.ResponseCode = true;
                    response.IsvResponse.ErrorDescription = "MX record does not contain ibmr.btconnect.com";
                    response.IsvResponse.ErrorCode = "777";
                }
            }
            return response;
        }
        #endregion

        #region GetClientProfile
        private GetClientProfileResponse GetClientProfile(string userId)
        {
            const string HTTP_HEADER_AUTHORIZATION = "Authorization";
            const string AUTHORIZATION_TYPE_BASIC = "Basic ";
            getClientProfileResponse1 profileResponse;
            getClientProfileRequest1 request1 = new getClientProfileRequest1();
            GetClientProfileRequest request = new GetClientProfileRequest();
            request.standardHeader = new StandardHeaderBlock();
            request.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
            request.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
            GetClientProfileReq clntProfileReq = new GetClientProfileReq();
            request.standardHeader.serviceAddressing.from = "BTCOM";

            ClientSearchCriteria criteria = new ClientSearchCriteria();
            criteria.identifierValue = userId;
            criteria.identifierDomainCode = "BTCOM";

            ResponseParameters resParams = new ResponseParameters();
            resParams.isClientServiceRolesRequired = "YES";
            resParams.isClientServiceInstanceRequired = "YES";
            resParams.isClientIdentitiesRequired = "YES";
            resParams.isLinkedProfilesRequired = "YES";

            clntProfileReq.clientSearchCriteria = criteria;
            clntProfileReq.responseParameter = resParams;
            request.getClientProfileReq = clntProfileReq;
            request1.getClientProfileRequest = request;


            #region Call DnP
            byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
            HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
            httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
            using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
            {
                ClientProfileSyncPortType svc = factory.CreateChannel();
                using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                {
                    OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                    profileResponse = svc.getClientProfile(request1);
                }
            }
            return profileResponse.getClientProfileResponse;


            #endregion
        }
        #endregion

        #region GetAndPostToPE
        internal OrderResponse GetAndPostToPE(string organizationId, string domainName, string correlationData)
        {
            string[] correlationValues = correlationData.Split(';');
            QueryOrdersRequest queryRequest = new QueryOrdersRequest();
            QueryOrdersResponse response;
            OrderResponse orderResponse = null;
            queryRequest.ServiceProviderId = 1;
            queryRequest.IsOrderXmlRequired = true;
            queryRequest.StatusFilter = OrderStatusFilterEnum.@new;
            queryRequest.ActionFilter = OrderActionFilterEnum.registerDomain;
            queryRequest.CustomerKeyFilter = organizationId;
            List<BT.SaaS.Core.Shared.Entities.QueryOrder> queryOrderList = new List<BT.SaaS.Core.Shared.Entities.QueryOrder>();
            BT.SaaS.Core.Shared.Entities.QueryOrder queryOrder = new BT.SaaS.Core.Shared.Entities.QueryOrder();
            queryOrder.externalOrderQuery.externalOrderId = "RD-RCOM-" + correlationValues[1];
            queryOrder.externalOrderQuery.serviceProviderId = "1";
            queryOrder.IsOrderXmlRequired = true;
            queryOrderList.Add(queryOrder);
            queryRequest.QueryOrderList = queryOrderList.ToArray();

            using (OrderReceiver.OrderClient client = new BT.ISVAdapter.RCOMServiceProvider.OrderReceiver.OrderClient())
            {
                response = client.Query(queryRequest);
            }
            if (response.result.errorCode == "000000" && response.queryOrderResponseList != null && response.queryOrderResponseList[0] != null)
            {
                Order order = response.queryOrderResponseList[0].orderResponse.order;

                StandardHeader header = new StandardHeader();
                header.serviceAddressing = new BT.SaaS.Core.Shared.Entities.ServiceAddressing();
                header.serviceAddressing.from = "RCOMCallback";
                order.Header.OrderDateTime = DateTime.Now;
                order.Header.EffectiveDateTime = DateTime.Now;
                order.ProductOrderItems[0].RoleInstances.Where(gs => gs.RoleType.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Attributes.Where(gs => gs.Name.Equals("licensetype", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value = string.Empty;
                using (OrderReceiver.OrderClient client = new BT.ISVAdapter.RCOMServiceProvider.OrderReceiver.OrderClient())
                {
                    orderResponse = client.SubmitOrder(header, order);
                }
            }
            else
            {
                throw new Exception("posting to PE failed!!!");
            }
            return orderResponse;

        }
        #endregion

        #region GetSSOFailedResponse

        internal responseHeader GetSSOFailedResponse(SSOStatus ssoValidationResult)
        {
            responseHeader res;
            try
            {
                res = new responseHeader();

                switch (ssoValidationResult)
                {
                    case SSOStatus.GUIDMissing:
                        res.ErrorMessage = "SSO Failed:" + SSOStatus.GUIDMissing.ToString();
                        res.ResultCode = (Convert.ToInt32(SSOStatus.GUIDMissing)).ToString();
                        break;
                    case SSOStatus.OrgIdMissing:
                        res.ErrorMessage = "SSO Failed:" + SSOStatus.OrgIdMissing.ToString();
                        res.ResultCode = (Convert.ToInt32(SSOStatus.OrgIdMissing)).ToString();
                        break;
                    case SSOStatus.GUIDandOrgIdMissing:
                        res.ErrorMessage = "SSO Failed:" + SSOStatus.GUIDandOrgIdMissing.ToString();
                        res.ResultCode = (Convert.ToInt32(SSOStatus.GUIDandOrgIdMissing)).ToString();
                        break;
                    case SSOStatus.GUIDExpired:
                        res.ErrorMessage = "SSO Failed:" + SSOStatus.GUIDExpired.ToString();
                        res.ResultCode = (Convert.ToInt32(SSOStatus.GUIDExpired)).ToString();
                        break;
                    case SSOStatus.Failed:
                        res.ErrorMessage = "SSO Failed";
                        res.ResultCode = (Convert.ToInt32(SSOStatus.Failed)).ToString();
                        break;
                }
            }
            catch (Exception ex)
            {
                res = new responseHeader();
                res.ErrorMessage = "SSO Failed";
                res.ResultCode = (Convert.ToInt32(SSOStatus.Failed)).ToString();

            }
            return res;

        }
        #endregion

        #region FormatTelephoneNumber

        private string FormatTelephoneNumber(string telePhoneNumber)
        {
            string newTelePhoneNumber;
            string sendTelePhoneNumber = String.Empty; ;

            //To remove spaces from the phone number if any
            string[] phoneNumberWithSpaces = telePhoneNumber.Trim().Split(' ');
            string phoneNumberWithOutSpaces = string.Empty;
            for (int i = 0; i < phoneNumberWithSpaces.Length; i++)
            {
                phoneNumberWithOutSpaces += phoneNumberWithSpaces[i] != " " ? phoneNumberWithSpaces[i] : "";
            }

            telePhoneNumber = phoneNumberWithOutSpaces;

            //To Check if telePhoneNumber length is less than 10 digit.
            if (telePhoneNumber.Length <= 10)
            {
                sendTelePhoneNumber = Properties.Settings.Default.PhoneCountryCode + telePhoneNumber;
            }

                //Check if telephoneNumber length is greater than 10 and starts with "0".
            else if (telePhoneNumber.Length >= 10 && telePhoneNumber.StartsWith("0") == true)
            {

                newTelePhoneNumber = telePhoneNumber.Substring(1);
                sendTelePhoneNumber = Properties.Settings.Default.PhoneCountryCode + newTelePhoneNumber;

            }

                //Check if telephoneNumber length is less than 10 and starts with "0044".
            else if (telePhoneNumber.Length <= 10 && telePhoneNumber.StartsWith("0044") == true)
            {
                newTelePhoneNumber = telePhoneNumber.Substring(4);
                sendTelePhoneNumber = Properties.Settings.Default.PhoneCountryCode + newTelePhoneNumber;
            }

                //Check if telephoneNumber length is greater than 10 and starts with "0044".
            else if (telePhoneNumber.Length > 10 && telePhoneNumber.StartsWith("0044") == true)
            {
                newTelePhoneNumber = telePhoneNumber.Substring(4);
                sendTelePhoneNumber = Properties.Settings.Default.PhoneCountryCode + newTelePhoneNumber;
            }

                //Check if telephoneNumber length is greater than 10 and starts with "44".
            else if (telePhoneNumber.Length > 10 && telePhoneNumber.StartsWith("44") == true)
            {
                newTelePhoneNumber = telePhoneNumber.Substring(2);
                sendTelePhoneNumber = Properties.Settings.Default.PhoneCountryCode + telePhoneNumber;
            }

                //Check if telephoneNumber length is greater than 10.
            else if (telePhoneNumber.Length >= 10)
            {
                sendTelePhoneNumber = Properties.Settings.Default.PhoneCountryCode + telePhoneNumber;

            }

            else
            {
                sendTelePhoneNumber = telePhoneNumber;
            }

            //return the Checked telepnoneNumber
            return sendTelePhoneNumber;

        }

        #endregion

        #region MapOrganizationDetails
        internal OrgDetails MapOrganizationDetails(TokenObject cacheObject, OrgDetails orgDetails)
        {
            orgDetails.OrganizationId = cacheObject.organizationId;
            orgDetails.RegistrantDetails = new PersonDetails();
            orgDetails.RegistrantDetails.Address = cacheObject.address;
            orgDetails.RegistrantDetails.Contact = cacheObject.contact;
            orgDetails.RegistrantDetails.Person = cacheObject.person;
            return orgDetails;
        }
        #endregion

        #region UpdateTxIdinDnP
        internal int UpdateTxIdinDnP(string orgId, string txId, string tld)
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                           ("VAS Adapters - RCOM: inside Update txId");
            const string HTTP_HEADER_AUTHORIZATION = "Authorization";
            const string AUTHORIZATION_TYPE_BASIC = "Basic ";
            Guid serviceInstanceId = Guid.Empty;
            string primaryUser = GetPrimaryUserFromDnP(orgId);
            GetClientProfileResponse profileResponse = GetClientProfile(primaryUser);
            if (profileResponse != null && profileResponse.standardHeader != null && profileResponse.standardHeader.serviceState != null && profileResponse.standardHeader.serviceState.stateCode == "0")
            {
                foreach (ClientServiceInstance instance in profileResponse.getClientProfileRes.clientProfile.clientServiceInstance)
                {
                    if (instance.clientServiceInstanceIdentifier.value.Equals(Properties.Settings.Default.RCOMServiceCode, StringComparison.InvariantCultureIgnoreCase)
                        && instance.clientServiceInstanceStatus.value.Equals("ACTIVE", StringComparison.InvariantCultureIgnoreCase))
                    {
                        foreach (ClientServiceRole clientServiceRole in instance.clientServiceRole)
                        {
                            if (clientServiceRole.id.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase))
                            {
                                foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic in clientServiceRole.clientServiceRoleCharacteristic)
                                {
                                    if (tld.Equals("CC", StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        if (clientServiceRoleCharacteristic.name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)
                                                            && clientServiceRoleCharacteristic.value.Equals("CCTLD", StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic1 in clientServiceRole.clientServiceRoleCharacteristic)
                                            {
                                                if (clientServiceRoleCharacteristic1.name.Equals("DOMAINSTATUS", StringComparison.InvariantCultureIgnoreCase)
                                                                && clientServiceRoleCharacteristic1.value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))
                                                {
                                                    serviceInstanceId = new Guid(instance.name);
                                                    break;
                                                }
                                            }
                                            break;
                                        }
                                    }
                                    else if (tld.Equals("COM", StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        if (clientServiceRoleCharacteristic.name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)
                                                        && clientServiceRoleCharacteristic.value.Equals("GTLD", StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic1 in clientServiceRole.clientServiceRoleCharacteristic)
                                            {
                                                if (clientServiceRoleCharacteristic1.name.Equals("DOMAINSTATUS", StringComparison.InvariantCultureIgnoreCase)
                                                            && clientServiceRoleCharacteristic1.value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))
                                                {
                                                    serviceInstanceId = new Guid(instance.name);
                                                    break;
                                                }
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                throw new Exception("DnP Get client profile call failed" + profileResponse.getClientProfileRes.messages[0].description);
            }

            if (serviceInstanceId != Guid.Empty)
            {
                manageClientProfileResponse1 clientProfileResponse = null;
                ManageClientProfileRequest request = new ManageClientProfileRequest();
                request.standardHeader = new StandardHeaderBlock();
                request.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                request.standardHeader.serviceAddressing.from = "http://www.profile.com?SAASPE";
                request.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
                request.manageClientProfileReq = new ManageClientProfileReq();
                request.manageClientProfileReq.clientProfile = new ClientProfile();
                request.manageClientProfileReq.clientProfile.client = new Client();
                request.manageClientProfileReq.clientProfile.client.action = "UPDATE";
                request.manageClientProfileReq.clientProfile.client.clientIdentity = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity[1];
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0] = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].action = "SEARCH";
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].value = primaryUser;
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain = new ManagedIdentifierDomain();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain.value = "BTCOM";

                request.manageClientProfileReq.clientProfile.clientServiceInstance = new ClientServiceInstance[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0] = new ClientServiceInstance();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].name = serviceInstanceId.ToString();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole = new ClientServiceRole[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0] = new ClientServiceRole();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].id = "ADMIN";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic = new ClientServiceRoleCharacteristic[2];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0] = new ClientServiceRoleCharacteristic();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].name = "TRANSACTIONID";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].value = txId;
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1] = new ClientServiceRoleCharacteristic();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1].name = "DOMAINSTATUS";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1].value = "INPROCESS";
                manageClientProfileRequest1 request1 = new manageClientProfileRequest1();
                request1.manageClientProfileRequest = request;

                #region Call DnP
                byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
                httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
                {
                    ClientProfileSyncPortType svc = factory.CreateChannel();
                    using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                    {
                        OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                        clientProfileResponse = svc.manageClientProfile(request1);
                    }
                }
                #endregion

                if (clientProfileResponse != null
                    && clientProfileResponse.manageClientProfileResponse != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState.stateCode == "0")
                {
                    return 0;
                }
                else
                {
                    throw new Exception("RCOM :DnP Updatiion call failed org:" + orgId + " and tld:" + tld);
                }

            }
            else
            {
                throw new Exception("RCOM :No serviceInstanceId found for thn org:" + orgId + " and tld:" + tld);
            }
        }
        #endregion

        #region GetServiceInstanceIdFromTxnIdAndDomain
        public Guid GetServiceInstanceIdFromTxnIdAndDomain(string domainName, string primaryUserId, bool isFree, string txid)
        {
            string licenseType = string.Empty;
            Guid serviceInstanceId = Guid.Empty;
            bool isLicenseTypevalid = false, isDomainStatusValid = false;
            GetClientProfileResponse profileResponse = GetClientProfile(primaryUserId);
            if (profileResponse != null && profileResponse.standardHeader != null && profileResponse.standardHeader.serviceState != null && profileResponse.standardHeader.serviceState.stateCode == "0")
            {
                foreach (ClientServiceInstance instance in profileResponse.getClientProfileRes.clientProfile.clientServiceInstance)
                {
                    if (instance.clientServiceInstanceIdentifier.value.Equals(Properties.Settings.Default.RCOMServiceCode, StringComparison.InvariantCultureIgnoreCase))
                    {
                        foreach (ClientServiceRole clientServiceRole in instance.clientServiceRole)
                        {
                            if (clientServiceRole.id.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase))
                            {
                                foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic in clientServiceRole.clientServiceRoleCharacteristic)
                                {
                                    if (isFree)
                                    {
                                        if (clientServiceRoleCharacteristic.name.Equals("TRANSACTIONID", StringComparison.InvariantCultureIgnoreCase)
                                            && clientServiceRoleCharacteristic.value.Equals(txid, StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            isLicenseTypevalid = true;
                                            isDomainStatusValid = true;
                                        }
                                    }
                                    else
                                    {
                                        if (clientServiceRoleCharacteristic.name.Equals("domainname", StringComparison.InvariantCultureIgnoreCase)
                                            && clientServiceRoleCharacteristic.value.Equals(domainName, StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            isLicenseTypevalid = true;
                                            isDomainStatusValid = true;
                                        }
                                    }
                                    if (isLicenseTypevalid && isDomainStatusValid)
                                    {
                                        serviceInstanceId = new Guid(instance.name);
                                        break;
                                    }
                                }
                            }
                            if (serviceInstanceId != Guid.Empty)
                            {
                                break;
                            }
                        }
                    }
                    if (serviceInstanceId != Guid.Empty)
                    {
                        break;
                    }
                }
            }
            else
            {
                throw new Exception("DnP Get client porfile call failed" + profileResponse.getClientProfileRes.messages[0].description);
            }
            if (serviceInstanceId == Guid.Empty)
            {
                throw new Exception("No matching service instance id found from DnP response!!");
            }
            return serviceInstanceId;
        }
        #endregion

        #region UpdateTxIdAndDomainInDnP
        internal int UpdateTxIdAndDomainInDnP(Guid serviceInstanceId, string orgId, string domainName, string primaryUser, bool isTxnServiceId)
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                           ("VAS Adapters - RCOM: inside Update txId");
            const string HTTP_HEADER_AUTHORIZATION = "Authorization";
            const string AUTHORIZATION_TYPE_BASIC = "Basic ";
            //string primaryUser = GetPrimaryUserFromDnP(orgId);
            if (serviceInstanceId != Guid.Empty)
            {
                manageClientProfileResponse1 clientProfileResponse = null;
                ManageClientProfileRequest request = new ManageClientProfileRequest();
                request.standardHeader = new StandardHeaderBlock();
                request.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                request.standardHeader.serviceAddressing.from = "http://www.profile.com?SAASPE";
                request.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
                request.manageClientProfileReq = new ManageClientProfileReq();
                request.manageClientProfileReq.clientProfile = new ClientProfile();
                request.manageClientProfileReq.clientProfile.client = new Client();
                request.manageClientProfileReq.clientProfile.client.action = "UPDATE";
                request.manageClientProfileReq.clientProfile.client.clientIdentity = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity[1];
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0] = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].action = "SEARCH";
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].value = primaryUser;
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain = new ManagedIdentifierDomain();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain.value = "BTCOM";

                request.manageClientProfileReq.clientProfile.clientServiceInstance = new ClientServiceInstance[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0] = new ClientServiceInstance();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].name = serviceInstanceId.ToString();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole = new ClientServiceRole[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0] = new ClientServiceRole();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].id = "ADMIN";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic = new ClientServiceRoleCharacteristic[2];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0] = new ClientServiceRoleCharacteristic();

                //if (isTxnServiceId)
                //{
                //request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].name = "TRANSACTIONID";
                //request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].action = "UPDATE";
                //request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].value = txId;
                //}
                //else
                //{
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].name = "DOMAINNAME";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].value = domainName;

                //}
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1] = new ClientServiceRoleCharacteristic();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1].name = "DOMAINSTATUS";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[1].value = "REGISTERED";
                manageClientProfileRequest1 request1 = new manageClientProfileRequest1();
                request1.manageClientProfileRequest = request;

                #region Call DnP
                byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
                httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
                {
                    ClientProfileSyncPortType svc = factory.CreateChannel();
                    using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                    {
                        OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                        clientProfileResponse = svc.manageClientProfile(request1);
                    }
                }
                #endregion

                if (clientProfileResponse != null
                    && clientProfileResponse.manageClientProfileResponse != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState.stateCode == "0")
                {
                    return 0;
                }
                else
                {
                    throw new Exception("RCOM :DnP Updatiion call failed org:" + orgId + " and domain:" + domainName);
                }

            }
            else
            {
                throw new Exception("RCOM :No serviceInstanceId found for thn org:" + orgId + " and txn:" + domainName);
            }
        }
        #endregion

        #region UpdateTxIdinDnPNotFree
        internal int UpdateTxIdinDnPNotFree(string orgId, string domainName, Guid serviceInstanceId, string primaryUser)
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                           ("VAS Adapters - RCOM: inside Update txId");
            const string HTTP_HEADER_AUTHORIZATION = "Authorization";
            const string AUTHORIZATION_TYPE_BASIC = "Basic ";
            //Guid serviceInstanceId = Guid.Empty;
            domainInfo domInfo = new domainInfo();
            string[] domains;
            domains = domainName.Trim().Split('.');
            domInfo.sld = domains[0];
            if (domains.Length > 2)
                domInfo.tld = domains[1] + "." + domains[2];
            else
                domInfo.tld = domains[1];

            #region commented code
            //string primaryUser = GetPrimaryUserFromDnP(orgId);
            //GetClientProfileResponse profileResponse = GetClientProfile(primaryUser);
            //if (profileResponse != null && profileResponse.standardHeader != null && profileResponse.standardHeader.serviceState != null && profileResponse.standardHeader.serviceState.stateCode == "0")
            //{
            //    foreach (ClientServiceInstance instance in profileResponse.getClientProfileRes.clientProfile.clientServiceInstance)
            //    {
            //        if (instance.clientServiceInstanceIdentifier.value.Equals(Properties.Settings.Default.RCOMServiceCode, StringComparison.InvariantCultureIgnoreCase))
            //        {
            //            foreach (ClientServiceRole clientServiceRole in instance.clientServiceRole)
            //            {
            //                if (clientServiceRole.id.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase))
            //                {
            //                    foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic in clientServiceRole.clientServiceRoleCharacteristic)
            //                    {
            //                        if (domInfo.tld.Equals("CC", StringComparison.InvariantCultureIgnoreCase))
            //                        {
            //                            if (clientServiceRoleCharacteristic.name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)
            //                                                && clientServiceRoleCharacteristic.value.Equals("CCTLD", StringComparison.InvariantCultureIgnoreCase))
            //                            {
            //                                foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic1 in clientServiceRole.clientServiceRoleCharacteristic)
            //                                {
            //                                    if (clientServiceRoleCharacteristic1.name.Equals("DOMAINSTATUS", StringComparison.InvariantCultureIgnoreCase)
            //                                                    && clientServiceRoleCharacteristic1.value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))
            //                                    {
            //                                        serviceInstanceId = new Guid(instance.name);
            //                                        break;
            //                                    }
            //                                }
            //                                break;
            //                            }
            //                        }
            //                        else if (domInfo.tld.Equals("COM", StringComparison.InvariantCultureIgnoreCase))
            //                        {
            //                            if (clientServiceRoleCharacteristic.name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)
            //                                            && clientServiceRoleCharacteristic.value.Equals("GTLD", StringComparison.InvariantCultureIgnoreCase))
            //                            {
            //                                foreach (ClientServiceRoleCharacteristic clientServiceRoleCharacteristic1 in clientServiceRole.clientServiceRoleCharacteristic)
            //                                {
            //                                    if (clientServiceRoleCharacteristic1.name.Equals("DOMAINSTATUS", StringComparison.InvariantCultureIgnoreCase)
            //                                                && clientServiceRoleCharacteristic1.value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))
            //                                    {
            //                                        serviceInstanceId = new Guid(instance.name);
            //                                        break;
            //                                    }
            //                                }
            //                                break;
            //                            }
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    throw new Exception("DnP Get client profile call failed" + profileResponse.getClientProfileRes.messages[0].description);
            //}
            #endregion

            if (serviceInstanceId != Guid.Empty)
            {
                manageClientProfileResponse1 clientProfileResponse = null;
                ManageClientProfileRequest request = new ManageClientProfileRequest();
                request.standardHeader = new StandardHeaderBlock();
                request.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                request.standardHeader.serviceAddressing.from = "http://www.profile.com?SAASPE";
                request.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
                request.manageClientProfileReq = new ManageClientProfileReq();
                request.manageClientProfileReq.clientProfile = new ClientProfile();
                request.manageClientProfileReq.clientProfile.client = new Client();
                request.manageClientProfileReq.clientProfile.client.action = "UPDATE";
                request.manageClientProfileReq.clientProfile.client.clientIdentity = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity[1];
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0] = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].action = "SEARCH";
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].value = primaryUser;
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain = new ManagedIdentifierDomain();
                request.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain.value = "BTCOM";

                request.manageClientProfileReq.clientProfile.clientServiceInstance = new ClientServiceInstance[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0] = new ClientServiceInstance();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].name = serviceInstanceId.ToString();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole = new ClientServiceRole[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0] = new ClientServiceRole();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].id = "ADMIN";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].action = "UPDATE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic = new ClientServiceRoleCharacteristic[1];
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0] = new ClientServiceRoleCharacteristic();
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].name = "LICENSETYPE";
                request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].action = "UPDATE";
                if (domInfo.tld == "CC")
                {
                    request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].value = "CCTLD";
                }
                else
                {
                    request.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic[0].value = "GTLD";

                }

                manageClientProfileRequest1 request1 = new manageClientProfileRequest1();
                request1.manageClientProfileRequest = request;

                #region Call DnP
                byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
                httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
                {
                    ClientProfileSyncPortType svc = factory.CreateChannel();
                    using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                    {
                        OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                        clientProfileResponse = svc.manageClientProfile(request1);
                    }
                }
                #endregion

                if (clientProfileResponse != null
                    && clientProfileResponse.manageClientProfileResponse != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState != null
                    && clientProfileResponse.manageClientProfileResponse.standardHeader.serviceState.stateCode == "0")
                {
                    return 0;
                }
                else
                {
                    throw new Exception("RCOM :DnP Updatiion call failed org:" + orgId + " and tld:" + domInfo.tld);
                }

            }
            else
            {
                throw new Exception("RCOM :No serviceInstanceId found for thn org:" + orgId + " and tld:" + domInfo.tld);
            }
        }
        #endregion

        #region Activate Service Instance
        /// <summary>
        /// Method to activate / deactivate service instance in DnP
        /// </summary>
        /// <param name="srvcInstanceId">service instance id</param>
        /// <param name="serviceCode">order item id</param>
        /// <param name="activate">flag to check whether the service instance is to activate or deactivate</param>
        public int ActivateDeactivateServiceInstance(string srvcInstanceId)
        {

            BT.SaaS.DnP.manageServiceInstanceRequest1 request;
            BT.SaaS.DnP.manageServiceInstanceResponse1 response;
            BT.SaaS.DnP.StandardHeaderBlock header = new BT.SaaS.DnP.StandardHeaderBlock();

            request = new BT.SaaS.DnP.manageServiceInstanceRequest1();
            request.manageServiceInstanceRequest = new BT.SaaS.DnP.ManageServiceInstanceRequest();

            // Creating standard header
            request.manageServiceInstanceRequest.standardHeader = header;
            request.manageServiceInstanceRequest.standardHeader.serviceState = new BT.SaaS.DnP.ServiceState();
            request.manageServiceInstanceRequest.standardHeader.serviceAddressing = new BT.SaaS.DnP.ServiceAddressing();
            request.manageServiceInstanceRequest.standardHeader.serviceAddressing.from = ADDRESS_BTCOM;

            request.manageServiceInstanceRequest.manageServiceInstanceReq = new BT.SaaS.DnP.ManageServiceInstanceReq();
            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance = new BT.SaaS.DnP.ClientServiceInstance();
            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance.action = ACTION_UPDATE;
            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance.name = srvcInstanceId;

            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance.clientServiceInstanceStatus = new BT.SaaS.DnP.ClientServiceInstanceStatus();
            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance.clientServiceInstanceStatus.value = "INACTIVE";

            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance.clientServiceInstanceIdentifier = new BT.SaaS.DnP.ClientServiceInstanceIdentifier();
            request.manageServiceInstanceRequest.manageServiceInstanceReq.clientServiceInstance.clientServiceInstanceIdentifier.value = "REGISTER_COM";

            byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
            HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
            httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));

            using (ChannelFactory<BT.SaaS.DnP.ServiceProfileSyncPortType> factory = new ChannelFactory<BT.SaaS.DnP.ServiceProfileSyncPortType>(@"ServiceProfileSyncPort"))
            {
                BT.SaaS.DnP.ServiceProfileSyncPortType svc = factory.CreateChannel();

                using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                {
                    OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                    response = svc.manageServiceInstance(request);
                }
            }
            if (response != null && response.manageServiceInstanceResponse != null && response.manageServiceInstanceResponse.standardHeader != null &&
            response.manageServiceInstanceResponse.standardHeader.serviceState != null)
            {
                if (response.manageServiceInstanceResponse.standardHeader.serviceState.stateCode == "0")
                {
                    return 0;
                    // Activation / Deactivation of service instance id done successfully.
                }
                else
                {
                    // Building error message from DnP
                    List<string> ErrorCodes = new List<string>();
                    string errorMsg = string.Empty;

                    // Looping in the error codes & error message from DnP.
                    if ((response.manageServiceInstanceResponse.manageServiceInstanceRes != null)
                    && (response.manageServiceInstanceResponse.manageServiceInstanceRes.messages != null))
                    {
                        StringBuilder sb = new StringBuilder();
                        foreach (BT.SaaS.DnP.Message msg in response.manageServiceInstanceResponse.manageServiceInstanceRes.messages)
                        {
                            ErrorCodes.Add(msg.messageCode);
                            sb.AppendFormat("|{0}|", msg.description);
                        }
                        errorMsg = sb.ToString();
                    }
                    else
                    {
                        // Trace statement
                        //BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace(DiagnosticInfo.ExecutingMethodSignature +
                        //  Environment.NewLine + errorMsg);
                        // throw exception
                        throw new Exception("Error updating serviceInstance in DnP,ErrorMessage : " + errorMsg);
                    }
                    return -1;
                }
            }
            else
            {
                // Building Error Message
                string errorMsg = "Error updating serviceInstance in DnP,ErrorMessage : " +
                    response.manageServiceInstanceResponse.standardHeader.serviceState.errorText;
                // Trace statement
                //BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace(DiagnosticInfo.ExecutingMethodSignature
                //   + Environment.NewLine + errorMsg);
                // throw exception
                throw new Exception("Error updating serviceInstance in DnP");
                return -1;
            }

        }
        #endregion


        #region DeleteDomainToPE
        public OrderResponse DeleteDomaintoPE(string orgId, string domainName)
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("PostToPE");
            Order request = new Order();
            OrderResponse response = null;
            try
            {
                DeleteFromDomain(domainName);
                StandardHeader header = new StandardHeader();
                header.serviceAddressing = new BT.SaaS.Core.Shared.Entities.ServiceAddressing();
                header.serviceAddressing.from = "RCOMCallback";
                string customerId = GetCustomerIdByCustomerKey(orgId, 1);
                Random rand = new Random();

                request.Header.CeaseReason = null;

                request.Header.OrderKey = "DD-ADAP-" + orgId + "-" + rand.Next(99999999);
                request.Header.ServiceProviderID = 1;
                request.Header.EffectiveDateTime = System.DateTime.Now;
                request.Header.OrderDateTime = System.DateTime.Now;
                request.Header.Status = OrderStatusEnum.@new;
                request.Header.Customer = new Customer();
                request.Header.Customer.Status = BT.SaaS.Core.Shared.Entities.DataStatusEnum.done;
                request.Header.Customer.CustomerId = customerId;
                request.Header.Customer.CustomerKey = orgId;
                IsHEUser = CheckIsHEUser(orgId);

                request.Header.Customer.Contacts = new List<BT.SaaS.Core.Shared.Entities.Contact>();
                BT.SaaS.Core.Shared.Entities.Contact contact = new BT.SaaS.Core.Shared.Entities.Contact();
                contact.Address = new BT.SaaS.Core.Shared.Entities.Address();
                contact.Address.UkAddress = new UKAddress();
                request.Header.Customer.Contacts.Add(contact);
                request.Header.Users = new List<User>();

                User user = new BT.SaaS.Core.Shared.Entities.User();
                user.Status = BT.SaaS.Core.Shared.Entities.DataStatusEnum.done;
                user.Type = "ADMIN";
                user.XmlIdKey = "US-1";
                user.IdentityCredential = new List<IdentityCredential>();
                IdentityCredential credential = new IdentityCredential();
                credential.Identity = new BT.SaaS.Core.Shared.Entities.ClientIdentity();
                credential.XmlIdKey = "USI-1";
                credential.Identity.identifier = GetPrimaryUserFromDnP(orgId);
                credential.Identity.identiferNamepace = "BTCOM";
                credential.Identity.IdentityAlias = IdentifierAliasEnum.no;
                credential.Credential = new BT.SaaS.Core.Shared.Entities.ClientCredential();
                credential.NewCredential = new BT.SaaS.Core.Shared.Entities.ClientCredential();
                user.IdentityCredential.Add(credential);
                request.Header.Users.Add(user);

                request.ProductOrderItems = new List<ProductOrderItem>();

                ProductOrderItem productOrderItem = new BT.SaaS.Core.Shared.Entities.ProductOrderItem();
                productOrderItem.Header.Status = BT.SaaS.Core.Shared.Entities.DataStatusEnum.notDone;
                productOrderItem.Header.Quantity = "1";
                productOrderItem.XmlIdKey = "PO-1";
                productOrderItem.Header.OrderItemKey = "1";
                productOrderItem.Header.ProductCode = "S0001331-PR0000000004008-";
                productOrderItem.Header.ProductName = "New Domain_Free";
                request.Header.Action = OrderActionEnum.deleteDomain;
                productOrderItem.RoleInstances = new List<RoleInstance>();
                RoleInstance roleInstance = new RoleInstance();
                roleInstance.Action = BT.SaaS.Core.Shared.Entities.RoleInstanceActionEnum.add;
                roleInstance.RoleType = "ADMIN";
                roleInstance.XmlIdKey = "RI-1";
                roleInstance.UserXmlRef = "US-1";
                roleInstance.UserIdentityCredentialXmlRef = "USI-1";
                roleInstance.Attributes = new List<BT.SaaS.Core.Shared.Entities.Attribute>();
                roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "organizationId", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = orgId });
                roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "domaintoremove", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = domainName });
                if (!IsHEUser)
                {
                    roleInstance.Attributes.Add(new BT.SaaS.Core.Shared.Entities.Attribute { Name = "identity", action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Value = orgId });
                    roleInstance.Attributes.AddRange(GetMailStorageServiceInstanceCharacterstics(credential.Identity.identifier, domainName));
                }
                productOrderItem.ServiceInstances = new System.Collections.Generic.List<BT.SaaS.Core.Shared.Entities.ServiceInstance>();
                ServiceInstance serviceInstance = new BT.SaaS.Core.Shared.Entities.ServiceInstance();

                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                   ("VAS Adapters - RCOM: Into service instance");
                serviceInstance.ServiceCode = Properties.Settings.Default.RCOMServiceCode;
                serviceInstance.ServiceInstanceId = GetServiceInstanceId(domainName, credential.Identity.identifier, false, "");
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                  ("VAS Adapters - RCOM: Into service instance" + serviceInstance.ServiceInstanceId);

                serviceInstance.ServiceRoles = new System.Collections.Generic.List<BT.SaaS.Core.Shared.Entities.ServiceRole>();
                BT.SaaS.Core.Shared.Entities.ServiceRole serviceRole = new BT.SaaS.Core.Shared.Entities.ServiceRole();
                serviceRole.roleAttributes = new System.Collections.Generic.List<BT.SaaS.Core.Shared.Entities.Attribute>();
                serviceInstance.ServiceRoles.Add(serviceRole);
                productOrderItem.ServiceInstances.Add(serviceInstance);
                productOrderItem.RoleInstances.Add(roleInstance);
                request.ProductOrderItems.Add(productOrderItem);
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Posting to PE...fingers crossed...Order:  " + request.ToString());
                using (OrderReceiver.OrderClient client = new BT.ISVAdapter.RCOMServiceProvider.OrderReceiver.OrderClient())
                {
                    response = client.SubmitOrder(header, request);
                }
                return response;
            }
            catch (Exception ex)
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("MSEOAdapter Mapping Exception : " + ex.ToString());
                throw ex;
            }
        }
        #endregion

        /// <summary>
        /// call to get client charactestics from DNP
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>List of Client Charatcerstics</returns>
        public List<ClientCharacteristic> GetClientCharacterstics(string customerKey)
        {
            getClientProfileRequest1 request = null;
            getClientProfileResponse1 response = null;
            List<ClientCharacteristic> clientChar = new List<ClientCharacteristic>();
            const string HTTP_HEADER_AUTHORIZATION = "Authorization";
            const string AUTHORIZATION_TYPE_BASIC = "Basic ";
            request = new getClientProfileRequest1();
            request.getClientProfileRequest = new GetClientProfileRequest();
            request.getClientProfileRequest.standardHeader = new StandardHeaderBlock();
            request.getClientProfileRequest.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
            request.getClientProfileRequest.standardHeader.serviceState.stateCode = "OK";
            request.getClientProfileRequest.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
            request.getClientProfileRequest.standardHeader.serviceAddressing.from = ADDRESS_BTCOM;
            request.getClientProfileRequest.getClientProfileReq = new GetClientProfileReq();
            request.getClientProfileRequest.getClientProfileReq.responseParameter = new ResponseParameters();
            request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientIdentitiesRequired = "YES";
            request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceRolesRequired = "NO";
            request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceRoleCharacteristicRequired = "NO";
            request.getClientProfileRequest.getClientProfileReq.responseParameter.isLinkedProfilesRequired = "YES";
            request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceInstanceRequired = "NO";
            request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceInstanceCharacteristicsrequired = "NO";
            request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria = new ClientSearchCriteria();
            request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria.identifierDomainCode = "CRMCUSTOMERKEY";
            request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria.identifierValue = customerKey;
            request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria.universalid = "";
            byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
            HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
            httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
            using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
            {
                ClientProfileSyncPortType svc = factory.CreateChannel();
                using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                {
                    OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                    response = svc.getClientProfile(request);
                }
            }
            if (response != null && response.getClientProfileResponse != null
                && response.getClientProfileResponse.getClientProfileRes != null
                && response.getClientProfileResponse.getClientProfileRes.clientProfile != null)
            {
                var clientProfile = response.getClientProfileResponse.getClientProfileRes.clientProfile;
                if (clientProfile.client != null && clientProfile.client.clientCharacteristic != null && clientProfile.client.clientCharacteristic.Length > 0)
                {
                    clientChar = clientProfile.client.clientCharacteristic.ToList();
                }
                else
                {
                    throw new Exception(string.Format("Client Characterstics are Empty for the customer {0}", customerKey));
                }
            }
            else
            {
                throw new Exception(string.Format("Response is Null from DNP for the Customer : ", customerKey));
            }
            return clientChar;
        }

        public BT.Core.ISVAdapter.ISVService.Entities.ISVOrder ChangeRolesFromPaidToFreeInDNP(BT.Core.ISVAdapter.ISVService.Entities.ISVOrder order)
        {
            order = ModifyAccountForChangeFreeStatus();
            if (order.ServiceActionOrderItem.IsvResponse.ResponseCode)
            {
                string userName = order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(ra => ra.Name.ToUpper() == "USERPRINCIPALNAME").SingleOrDefault().Value;
                string freeSIK = order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(ra => ra.Name.ToUpper() == "FREESIK").SingleOrDefault().Value;
                string paidSIK = order.ServiceActionOrderItem.Header.ServiceInstanceID.ToString();
                getClientProfileRequest1 request = null;
                getClientProfileResponse1 response = null;
                List<ClientServiceRoleCharacteristic> roleAttrsToBeConverted = null;

                request = new getClientProfileRequest1();
                request.getClientProfileRequest = new GetClientProfileRequest();
                request.getClientProfileRequest.standardHeader = new StandardHeaderBlock();
                request.getClientProfileRequest.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
                request.getClientProfileRequest.standardHeader.serviceState.stateCode = "OK";
                request.getClientProfileRequest.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                request.getClientProfileRequest.standardHeader.serviceAddressing.from = ADDRESS_BTCOM;
                request.getClientProfileRequest.getClientProfileReq = new GetClientProfileReq();
                request.getClientProfileRequest.getClientProfileReq.responseParameter = new ResponseParameters();
                request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientIdentitiesRequired = "NO";
                request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceRolesRequired = "YES";
                request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceRoleCharacteristicRequired = "YES";
                request.getClientProfileRequest.getClientProfileReq.responseParameter.isLinkedProfilesRequired = "NO";
                request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceInstanceRequired = "YES";
                request.getClientProfileRequest.getClientProfileReq.responseParameter.isClientServiceInstanceCharacteristicsrequired = "NO";
                request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria = new ClientSearchCriteria();
                request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria.identifierDomainCode = "BTCOM";
                request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria.identifierValue = userName;
                request.getClientProfileRequest.getClientProfileReq.clientSearchCriteria.universalid = "";
                byte[] credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                HttpRequestMessageProperty httpRequest = new HttpRequestMessageProperty();
                httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
                {
                    ClientProfileSyncPortType svc = factory.CreateChannel();
                    using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                    {
                        OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                        response = svc.getClientProfile(request);
                    }
                }
                if (response != null && response.getClientProfileResponse != null
                    && response.getClientProfileResponse.getClientProfileRes != null
                    && response.getClientProfileResponse.getClientProfileRes.clientProfile != null
                    && response.getClientProfileResponse.getClientProfileRes.clientProfile.clientServiceInstance != null
                    && response.getClientProfileResponse.getClientProfileRes.clientProfile.clientServiceInstance.Length > 0)
                {
                    ClientServiceRole freeSIKRole = response.getClientProfileResponse.getClientProfileRes.clientProfile.clientServiceInstance.Where(csi => csi.name == freeSIK).SingleOrDefault().clientServiceRole.Where(r => r.id.ToUpper() == "ADMIN").SingleOrDefault();
                    ClientServiceRole paidSIKRole = response.getClientProfileResponse.getClientProfileRes.clientProfile.clientServiceInstance.Where(csi => csi.name == paidSIK).SingleOrDefault().clientServiceRole.Where(r => r.id.ToUpper() == "ADMIN").SingleOrDefault();
                    if (paidSIKRole.clientServiceRoleCharacteristic != null && paidSIKRole.clientServiceRoleCharacteristic.Length > 0 && freeSIKRole.clientServiceRoleCharacteristic != null && freeSIKRole.clientServiceRoleCharacteristic.Length > 0)
                    {
                        roleAttrsToBeConverted = new List<ClientServiceRoleCharacteristic>();
                        ClientServiceRoleCharacteristic crc = null;
                        for (int i = 0; i < paidSIKRole.clientServiceRoleCharacteristic.Length; i++)
                        {
                            if (freeSIKRole.clientServiceRoleCharacteristic.Any(csrc => csrc.name.ToUpper() == paidSIKRole.clientServiceRoleCharacteristic[i].name.ToUpper()))
                            {
                                crc = new ClientServiceRoleCharacteristic() { name = paidSIKRole.clientServiceRoleCharacteristic[i].name, value = paidSIKRole.clientServiceRoleCharacteristic[i].value, action = "UPDATE" };
                                crc.value = (crc.name.ToUpper() == "FREE") ? "True" : crc.value;
                                roleAttrsToBeConverted.Add(crc);
                            }
                            else
                            {
                                crc = new ClientServiceRoleCharacteristic() { name = paidSIKRole.clientServiceRoleCharacteristic[i].name, value = paidSIKRole.clientServiceRoleCharacteristic[i].value, action = "INSERT" };
                                crc.value = (crc.name.ToUpper() == "FREE") ? "True" : crc.value;
                                roleAttrsToBeConverted.Add(crc);
                            }
                        }
                    }

                    //Swap the clientservice RoleChars of Free SIK with PAID SIK's chars
                    manageClientProfileRequest1 req = new manageClientProfileRequest1();
                    manageClientProfileResponse1 resp = new manageClientProfileResponse1();

                    req.manageClientProfileRequest = new ManageClientProfileRequest();
                    req.manageClientProfileRequest.standardHeader = new StandardHeaderBlock();
                    req.manageClientProfileRequest.standardHeader.serviceState = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceState();
                    req.manageClientProfileRequest.standardHeader.serviceState.stateCode = "OK";
                    req.manageClientProfileRequest.standardHeader.serviceAddressing = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ServiceAddressing();
                    req.manageClientProfileRequest.standardHeader.serviceAddressing.from = ADDRESS_BTCOM;

                    req.manageClientProfileRequest.manageClientProfileReq = new ManageClientProfileReq();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile = new ClientProfile();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client = new Client();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.action = "UPDATE";

                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity[1];
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0] = new BT.ISVAdapter.RCOMServiceProvider.DnPProxy.ClientIdentity();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].action = "SEARCH";
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].value = userName;
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain = new ManagedIdentifierDomain();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.client.clientIdentity[0].managedIdentifierDomain.value = "BTCOM";

                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance = new ClientServiceInstance[2];
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0] = new ClientServiceInstance();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].action = "SEARCH";
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].name = freeSIK;

                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole = new ClientServiceRole[1];
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0] = new ClientServiceRole();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].action = "UPDATE";
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].id = "ADMIN";
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic = new ClientServiceRoleCharacteristic[roleAttrsToBeConverted.Count];
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[0].clientServiceRole[0].clientServiceRoleCharacteristic = roleAttrsToBeConverted.ToArray();

                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[1] = new ClientServiceInstance();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[1].action = "UPDATE";
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[1].name = paidSIK;

                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[1].clientServiceInstanceStatus = new ClientServiceInstanceStatus();
                    req.manageClientProfileRequest.manageClientProfileReq.clientProfile.clientServiceInstance[1].clientServiceInstanceStatus.value = "INACTIVE";

                    credBuffer = new UTF8Encoding().GetBytes(Properties.Settings.Default.DnPServiceUserName + ":" + Properties.Settings.Default.DnPServicePassword);
                    httpRequest = new HttpRequestMessageProperty();
                    httpRequest.Headers.Add(HTTP_HEADER_AUTHORIZATION, AUTHORIZATION_TYPE_BASIC + Convert.ToBase64String(credBuffer));
                    using (ChannelFactory<ClientProfileSyncPortType> factory = new ChannelFactory<ClientProfileSyncPortType>(@"ClientProfileSyncPort"))
                    {
                        ClientProfileSyncPortType svc = factory.CreateChannel();
                        using (OperationContextScope scope = new OperationContextScope((IContextChannel)svc))
                        {
                            OperationContext.Current.OutgoingMessageProperties.Add(HttpRequestMessageProperty.Name, httpRequest);
                            resp = svc.manageClientProfile(req);
                        }
                    }

                    if (resp != null
                        && resp.manageClientProfileResponse != null
                        && resp.manageClientProfileResponse.standardHeader != null
                        && resp.manageClientProfileResponse.standardHeader.serviceState != null
                        && resp.manageClientProfileResponse.standardHeader.serviceState.stateCode == "0")
                    {
                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                    }
                    else
                    {
                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                        order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                        order.ServiceActionOrderItem.IsvResponse.ErrorDescription = resp.manageClientProfileResponse.manageClientProfileRes.messages[0].description;
                    }
                }
                else
                {
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                    order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
                    order.ServiceActionOrderItem.IsvResponse.ErrorDescription = response.getClientProfileResponse.getClientProfileRes.messages[0].description;
                }
            }
            return order;
        }
        public bool CheckIsHEUser(string customerKey)
        {
            bool result = false;
            List<ClientCharacteristic> clientChar = new List<ClientCharacteristic>();
            clientChar = GetClientCharacterstics(customerKey);
            if (clientChar != null && clientChar.Count > 0)
            {
                result = (clientChar.Exists(attr => attr.name.Equals("IS_HE_COMPATIBLE", StringComparison.OrdinalIgnoreCase))) ? Convert.ToBoolean(clientChar.Find(attr => attr.name.Equals("IS_HE_COMPATIBLE", StringComparison.OrdinalIgnoreCase)).value) : false;
            }
            return result;
        }
        public List<BT.SaaS.Core.Shared.Entities.Attribute> GetMailStorageServiceInstanceCharacterstics(string primaryUserId, string domainName)
        {
            List<BT.SaaS.Core.Shared.Entities.Attribute> srvcInstChar = new List<BT.SaaS.Core.Shared.Entities.Attribute>();
            string licenseType = string.Empty; // to check whether domain used for POP+ or p1
            GetClientProfileResponse profileResponse = GetClientProfile(primaryUserId);
            if (profileResponse != null && profileResponse.standardHeader != null && profileResponse.standardHeader.serviceState != null && profileResponse.standardHeader.serviceState.stateCode == "0")
            {
                foreach (ClientServiceInstance instance in profileResponse.getClientProfileRes.clientProfile.clientServiceInstance)
                {
                    if (instance.clientServiceInstanceIdentifier.value.Equals(Properties.Settings.Default.RCOMServiceCode, StringComparison.InvariantCultureIgnoreCase))
                    {
                        foreach (ClientServiceRole clientServiceRole in instance.clientServiceRole)
                        {
                            if (clientServiceRole.id.Equals("ADMIN", StringComparison.InvariantCultureIgnoreCase) && clientServiceRole.clientServiceRoleCharacteristic.ToList().Find(c => c.name.ToUpper() == "DOMAINNAME").value.ToUpper() == domainName.ToUpper())
                            {
                                licenseType = clientServiceRole.clientServiceRoleCharacteristic.ToList().Find(c => c.name.ToUpper() == "SKUTYPE").value;
                            }
                        }
                    }
                    else if (instance.clientServiceInstanceIdentifier.value.Equals("MAIL_STORAGE", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (!string.IsNullOrEmpty(licenseType) && licenseType.ToUpper().Contains("LITE"))
                        {
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "adminusername", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "POPPLUS_ADMINUSERNAME").value });
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "adminpassword", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "POPPLUS_ADMINPASSWORD").value });
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "mosi_customerid", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "POPPLUS_CUST_GUID").value });
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "mosi_subscriptionid", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "POPPLUS_SUBSCRIPTION_GUID").value });
                        }
                        else
                        {
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "adminusername", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "P1_ADMIN_USER_NAME").value });
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "adminpassword", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "P1_ADMIN_PASSWORD").value });
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "mosi_customerid", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "P1_CUST_GUID").value });
                            srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "mosi_subscriptionid", Value = instance.clientServiceInstanceCharacteristic.First(ch => ch.name.ToUpper() == "P1_SUBSCRIPTION_GUID").value });
                        }
                        srvcInstChar.Add(new BT.SaaS.Core.Shared.Entities.Attribute() { action = BT.SaaS.Core.Shared.Entities.DataActionEnum.add, Name = "mailstorageserviceinstancekey", Value = instance.name });
                    }
                }
            }
            return srvcInstChar;
        }
        private static bool ValidateRemoteCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors policyErrors)
        {
            return true;
        }
    }
}


