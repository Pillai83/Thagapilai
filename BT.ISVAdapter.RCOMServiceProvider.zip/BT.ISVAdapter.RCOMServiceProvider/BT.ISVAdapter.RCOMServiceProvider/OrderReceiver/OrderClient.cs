﻿namespace OrderReceiver
{
    internal class OrderClient
    {
    }
}