﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using BT.ISVAdapter.RCOMServiceProvider.DAL;
using BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset.RCOMTableAdapters;
using BT.ISVAdapter.RCOMServiceProvider.DAL.Dataset;

namespace BT.ISVAdapter.RCOMServiceProvider.DAL
{
    public class RCOMDBCommandsDAL
    {
        RCOMDBCommands rComCommands;
        ExternalDomainDBCommands externalDBCommands;

        public RCOMDBCommandsDAL()
        {
            rComCommands = new RCOMDBCommands();
            externalDBCommands = new ExternalDomainDBCommands();
        }

        public void InsertDomainName(string domainName, int statusID, string correlationData, string transactionId, string organizationId)
        {
            rComCommands.Insert_DomainNames(domainName, statusID, correlationData, transactionId, organizationId);
        }

        public void InsertBlacklistedDomainName(string domainName)
        {
            rComCommands.InsertBlacklistedDomainNames(domainName);
        }

        public RCOM.Check_DomainNamesDataTable GetDataForDomains(string domainName)
        {
            RCOM.Check_DomainNamesDataTable dtbl = new RCOM.Check_DomainNamesDataTable();
            dtbl = rComCommands.GetDataForDomain(domainName);

            return dtbl;
        }

        public int GetDataForBlacklistedDomains(string domainName)
        {
            int rowCount = 0;
            rowCount = int.Parse(rComCommands.Check_BlacklistedDomainNames(domainName).ToString());

            return rowCount;
        }

        public void UpdateStatusForDomain(string domainName, int statusID, string correlationData)
        {
            rComCommands.Update_DomainStatus(domainName, statusID, correlationData);
        }

        public void DeleteDomain(string domainName)
        {
            rComCommands.DeleteDomain(domainName);
        }

        public RCOM.Check_ExternalDomainDataTable GetDataForExternalDomain(string externalDomain)
        {
            RCOM.Check_ExternalDomainDataTable dTable;
            dTable = externalDBCommands.GetDataForExternalDomain(externalDomain);
            return dTable;
        }

        public void InsertExternalDomain(string domainName, string orderKey)
        {
            externalDBCommands.Insert_ExternalDomain(domainName, orderKey);
        }

        public int CheckTransactionId(string transactionId)
        {
            int rowCount = 0;
            rowCount = int.Parse(rComCommands.Check_TransactionId(transactionId).ToString());
            return rowCount;
        }

        public void UpdateTransactionId(string domainName, int statusId, string transactionId)
        {
            rComCommands.Update_TransactionID(domainName, statusId, transactionId);
        }

        public RCOM.Check_DomainNamesDataTable GetByOrganizationID(string organizationId)
        {
            RCOM.Check_DomainNamesDataTable result = rComCommands.GetByOrganizationID(organizationId);
            return result;
        }
    }
}
