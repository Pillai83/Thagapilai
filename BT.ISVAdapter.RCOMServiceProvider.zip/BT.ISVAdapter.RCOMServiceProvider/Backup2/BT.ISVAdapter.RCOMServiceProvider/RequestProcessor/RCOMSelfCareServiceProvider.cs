﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using BT.Core.ISVAdapter.ISVService.Entities;

namespace BT.ISVAdapter.RCOMServiceProvider
{
    public class RCOMSelfCareServiceProvider : ISVQueryServiceProvider 
    {
        #region ISVQueryServiceProvider Members

        public QueryOrderResponse Query(BT.Core.ISVAdapter.ISVService.Entities.QueryOrder order)
        {
            QueryOrderResponse response = new QueryOrderResponse();
            try
            {
                RequestProcessor reqProcess = new RequestProcessor();
                if (order.Header.RequestAction == ServiceRequestedActionEnum.checkMXRecord)
                {
                    response = reqProcess.CheckMXRecord(order);
                }
                else if (order.Header.RequestAction == ServiceRequestedActionEnum.addBlacklistedDomain)
                {
                    response = reqProcess.InsertIntoBlackListedDomain(order);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("No records found"))
                {
                    response.IsvResponse = new ISVResponse();
                    response.IsMXRecordPresent = false;
                    response.IsvResponse.ResponseCode = true;
                    response.IsvResponse.ErrorDescription = "MX record does not contain ibmr.btconnect.com";
                    response.IsvResponse.ErrorCode = "777";
                }
                else
                {
                    response.IsvResponse = new ISVResponse();
                    response.IsvResponse.ResponseCode = false;
                    response.IsvResponse.ErrorCode = "777";
                    response.IsvResponse.ErrorDescription = ex.Message;
                }
            }
            return response;
        }

        

        #endregion
    }
}
