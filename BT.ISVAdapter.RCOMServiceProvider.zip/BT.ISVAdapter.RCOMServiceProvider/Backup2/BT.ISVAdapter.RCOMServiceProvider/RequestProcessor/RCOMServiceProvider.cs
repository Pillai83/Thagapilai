﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using BT.SaaS.Core.Shared.Exceptions;
using BT.Core.ISVAdapter.ISVService.Entities;
using System.ServiceModel;
using BT.Core.ISVAdapter.ISVService;
using BT.SaaS.Core.Shared.ErrorManagement;
using System.Linq;
using BT.ISVAdapter.RCOMServiceProvider.DAL;
using System.Net;


namespace BT.ISVAdapter.RCOMServiceProvider
{
    [SaaSGlobalErrorHandler]
    public class RCOMServiceProvider :BaseISVServiceProvider
    {
        #region members
        private const string CONSUMER_CONFIG_BINDING = @"basicHttpBinding_Consumer";
        RCOMDBCommandsDAL rcomDal = new RCOMDBCommandsDAL();
        #endregion

        #region Constructor

        public RCOMServiceProvider()
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("VAS Adapters - RCOM: RCOMServiceProvider.Ctor()");            
            base.ConsumerBinding = new BasicHttpBinding(CONSUMER_CONFIG_BINDING);
            base.ConsumerEndPointAddress = new EndpointAddress(Properties.Settings.Default.ISVConsumerProxyEndPoint);
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
        }

        #endregion

        #region BaseISVServiceProvider overriden Members

        public override void CreateAccount(ISVOrder order)
        {
            try
            {
                if (order.Header.OrderKey.Contains("RCOM-ADAP") || order.Header.OrderKey.Contains("UI-EXTD-") || order.Header.OrderKey.Contains("RD-RCOM") || order.Header.OrderKey.Contains("RD-MOSI-"))
                {
                    if (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)))
                    {
                        order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value = "REGISTERED";
                    }
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                }
                else
                {
                    RequestProcessor requestProcessor = new RequestProcessor(order);
                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM: RCOMServiceProvider.CreateAccount(order)");
                    string licenseType = order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("licensetype", StringComparison.InvariantCultureIgnoreCase)).Single().Value;
                    if (licenseType.Equals("transfer-in", StringComparison.InvariantCultureIgnoreCase))
                    {
                        BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM: I got a transfer - in call!!!");
                        order = requestProcessor.ModifyAccountTransferDomain();                        
                    }
                    else if (licenseType.Equals("external", StringComparison.InvariantCultureIgnoreCase))
                    {
                        BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM: I got a external domain call!!!");
                        string domainName = order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainname", StringComparison.InvariantCultureIgnoreCase)).Single().Value;
                        rcomDal.InsertExternalDomain(domainName, order.Header.OrderKey);
                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                    }
                    else if (licenseType.Equals("autoactivation", StringComparison.InvariantCultureIgnoreCase))
                    {
                        //update license type external incase of autoactivation
                        order = requestProcessor.AutoActivationForActivateWebsite(order);
                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                    }
                    else
                    {
                        order = requestProcessor.CreateAccountForPurchaseDomain();
                    }
                }               
            }
            catch (Exception ex)
            {
                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = ex.Message;
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";                
            }
            finally 
            {
                base.SendCreateAccountResponse(order);
            }
        }

        public override void ModifyAccount(ISVOrder order)
        {
            try
            {
                //Check added for 1575 - Make Paid Domain Free (FD - Free Domain)
                if (order.Header.OrderKey.StartsWith("SOOJ-FD-"))
                {
                    RequestProcessor rp = new RequestProcessor(order);
                    order = rp.ChangeRolesFromPaidToFreeInDNP(order);
                }
                //as part of Modify Customer issue(BH359627)
                  //added OR conditions in if loop for domainstatus - "INITIALIZED"--Nov-17
                //2nd OR condition for DOMAINTYPE-"override"--Dec20
                //3rd OR condition for domainstatus- "REGISTERED"--Jan27--end
                //4th OR cndition for domainstatus-"INPROCESS"--Mar01
                else if (((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("licenseType", StringComparison.InvariantCultureIgnoreCase)))
                        && (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("licenseType", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("external", StringComparison.InvariantCultureIgnoreCase)))||((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase))) &&
                    (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))) || ((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("DOMAINTYPE", StringComparison.InvariantCultureIgnoreCase))) &&
                    (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("DOMAINTYPE", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("Override", StringComparison.InvariantCultureIgnoreCase))) || ((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase))) &&
                    (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("REGISTERED", StringComparison.InvariantCultureIgnoreCase)))
                        || ((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase))) &&
                    (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("INPROCESS", StringComparison.InvariantCultureIgnoreCase))))
                    {

                        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                    }
                
                else
                {
                    RequestProcessor requestProcessor = new RequestProcessor(order);
                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM: RCOMServiceProvider.CreateAccount(order)" + DateTime.Now);
                    order = requestProcessor.ModifyAccountForActivateWebsite(order);
                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM: RCOMServiceProvider.CreateAccount(order)" + DateTime.Now);
                }                
            }
            catch (Exception ex)
            {
                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = ex.Message;
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
            }
            finally
            {
                base.SendModifyAccountResponse(order);
            }
        }

        public override void CeaseAccount(ISVOrder order)
        {
            try
            {  //added as part of Modify Customer issue(BH359627)-- Nov-17---start
                if (((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase))) &&
                    (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("domainstatus", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("INITIALIZED", StringComparison.InvariantCultureIgnoreCase))) ||
                    ((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase))) &&
                    (order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("LICENSETYPE", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value.Equals("EXTERNAL", StringComparison.InvariantCultureIgnoreCase))) ||
                    ((order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Exists(gs => gs.Name.Equals("DOMAINNAME", StringComparison.InvariantCultureIgnoreCase))) &&
                    (string.IsNullOrEmpty(order.ServiceActionOrderItem.ServiceRoles[0].roleAttributes.Where(gs => gs.Name.Equals("DOMAINNAME", StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault().Value))))
                {
                    order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
                }
                //added as part of Modify Customer issue(BH359627)--Nov-17---end

                else
                {
                    RequestProcessor requestProcessor = new RequestProcessor(order);
                    order = requestProcessor.CeaseAccountForCease();
                }
                
            }
            catch (Exception ex)
            {
                order.ServiceActionOrderItem.IsvResponse.ErrorDescription = ex.Message;
                order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
                order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
            }
            finally
            {
                base.SendCeaseAccountResponse(order);
            }
        }

        //public override void ModifyClient(ISVOrder order)
        //{
        //    try
        //    {
        //        order.ServiceActionOrderItem.IsvResponse.ResponseCode = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        order.ServiceActionOrderItem.IsvResponse.ErrorDescription = ex.Message;
        //        order.ServiceActionOrderItem.IsvResponse.ResponseCode = false;
        //        order.ServiceActionOrderItem.IsvResponse.ErrorCode = "777";
        //    }
        //    finally
        //    {
        //        base.SendModifyClientResponse(order);
        //    }
        //}
        #endregion
    }
}
