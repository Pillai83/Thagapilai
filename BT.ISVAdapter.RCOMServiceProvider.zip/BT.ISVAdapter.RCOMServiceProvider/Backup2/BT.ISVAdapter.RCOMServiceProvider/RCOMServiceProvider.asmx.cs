﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Web.Services.Description;

namespace BT.ISVAdapter.RCOMServiceProvider
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [WebServiceBindingAttribute(Name = "WSBinding", Namespace = "http://business-services-sync-api/v2.1.0.1/DomainCheck")]
    public class DomainValidation : System.Web.Services.WebService
    {
        [WebMethod]
        [SoapDocumentMethodAttribute("http://business-services-sync-api/v2.1.0.1/DomainCheck", OneWay = false, Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Bare, Binding = "WSBinding")]
        public SDPDomainCheckResponse ValidateDomainName(SDPDomainCheck sdpDomainCheck)
        {
            SDPDomainCheckResponse sdpDomainCheckResponse = new SDPDomainCheckResponse();
            string result = string.Empty;
            try
            {
                sdpDomainCheckResponse.Header.Pck = sdpDomainCheck.Header.Pck;
                sdpDomainCheckResponse.Header.CallerId = sdpDomainCheck.Header.CallerId;
                sdpDomainCheckResponse.IsBlacklisted = "FALSE";
                sdpDomainCheckResponse.IsExisting = "FALSE";
                RequestProcessor reqProcessor = new RequestProcessor();
                if (sdpDomainCheck != null && !string.IsNullOrEmpty(sdpDomainCheck.DomainName))
                {
                    bool isBlackListed = reqProcessor.CheckBlacklistedDomainName(sdpDomainCheck.DomainName);
                    if (isBlackListed)
                    {
                        sdpDomainCheckResponse.IsBlacklisted = "TRUE";
                        sdpDomainCheckResponse.Header.GenReturnCode = genReturnCode.BlacklistedDomain;
                    }
                    else
                    {
                        sdpDomainCheckResponse.IsBlacklisted = "FALSE";
                        bool isPresent = reqProcessor.CheckDomainName(sdpDomainCheck.DomainName);
                        if (isPresent)
                        {
                            sdpDomainCheckResponse.IsExisting = "TRUE";
                            sdpDomainCheckResponse.Header.GenReturnCode = genReturnCode.DuplicateDomain;
                        }
                        else
                        {
                            sdpDomainCheckResponse.IsExisting = "false";
                            sdpDomainCheckResponse.Header.GenReturnCode = genReturnCode.Success;
                        }
                    }
                }
                else
                {
                    sdpDomainCheckResponse.Header.GenReturnCode = genReturnCode.InvalidDomainExtension;
                    sdpDomainCheckResponse.Header.GenReturnText = "Domain Name cannot be empty!!!";
                }
            }
            catch (Exception ex)
            {
                sdpDomainCheckResponse.Header.GenReturnCode = genReturnCode.InvalidDomainExtension;
                sdpDomainCheckResponse.Header.GenReturnText = ex.Message;
            }
            return sdpDomainCheckResponse;
        }
    }
}
