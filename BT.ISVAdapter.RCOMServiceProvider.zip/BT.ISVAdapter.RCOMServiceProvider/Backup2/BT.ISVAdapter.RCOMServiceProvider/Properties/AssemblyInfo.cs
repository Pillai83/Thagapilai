﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyProduct("BT.ISVAdapter.RCOMServiceProvider")]


// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("533cd6e6-2f41-4bef-9248-f8083644ce81")]

// SaaS Core specific information
[assembly: AssemblyCompany(BT.Core.ISVAdapter.Versioning.AssemblyInfo.Company)]
[assembly: AssemblyCopyright(BT.Core.ISVAdapter.Versioning.AssemblyInfo.Copyright)]
[assembly: AssemblyTrademark(BT.Core.ISVAdapter.Versioning.AssemblyInfo.Trademark)]
[assembly: AssemblyVersion(BT.Core.ISVAdapter.Versioning.AssemblyInfo.ProductVersion)]
[assembly: AssemblyFileVersion(BT.Core.ISVAdapter.Versioning.AssemblyInfo.FileVersion)]
