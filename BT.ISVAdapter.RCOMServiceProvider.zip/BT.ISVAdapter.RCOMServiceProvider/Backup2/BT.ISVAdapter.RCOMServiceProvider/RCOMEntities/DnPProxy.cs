﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Serialization;
using System.Net;
using System.Text;
using System.IO;
using System.Globalization;


namespace BT.ISVAdapter.RCOMServiceProvider.DnPProxy
{
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(Namespace = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18", ConfigurationName = "BT.ISVAdapter.DnPServiceProvider.ClientProfileSyncPortType")]
    public interface ClientProfileSyncPortType
    {

        // CODEGEN: Generating message contract since the operation manageClientProfile is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#manageClientProfile", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        manageClientProfileResponse1 manageClientProfile(manageClientProfileRequest1 request);

        // CODEGEN: Generating message contract since the operation getClientProfile is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#getClientProfile", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        getClientProfileResponse1 getClientProfile(getClientProfileRequest1 request);

        // CODEGEN: Generating message contract since the operation getClientIdentifiers is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#getClientIdentifiers" +
            "", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        getClientIdentifiersResponse1 getClientIdentifiers(getClientIdentifiersRequest1 request);

        // CODEGEN: Generating message contract since the operation manageClientIdentity is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#manageClientIdentity" +
            "", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        manageClientIdentityResponse1 manageClientIdentity(manageClientIdentityRequest1 request);

        // CODEGEN: Generating message contract since the operation getOrganisationDetails is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#getOrganisationDetai" +
            "ls", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        getOrganisationDetailsResponse1 getOrganisationDetails(getOrganisationDetailsRequest1 request);

        // CODEGEN: Generating message contract since the operation linkClientProfiles is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#linkClientProfiles", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        linkClientProfilesResponse1 linkClientProfiles(linkClientProfilesRequest1 request);
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageClientProfileRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageClientProfileReq manageClientProfileReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageClientProfileReq manageClientProfileReq
        {
            get
            {
                return this.manageClientProfileReqField;
            }
            set
            {
                this.manageClientProfileReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class StandardHeaderBlock
    {

        private E2E e2eField;

        private ServiceState serviceStateField;

        private ServiceAddressing serviceAddressingField;

        private ServiceProperties servicePropertiesField;

        private ServiceSpecification serviceSpecificationField;

        private ServiceSecurity serviceSecurityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public E2E e2e
        {
            get
            {
                return this.e2eField;
            }
            set
            {
                this.e2eField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public ServiceState serviceState
        {
            get
            {
                return this.serviceStateField;
            }
            set
            {
                this.serviceStateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public ServiceAddressing serviceAddressing
        {
            get
            {
                return this.serviceAddressingField;
            }
            set
            {
                this.serviceAddressingField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public ServiceProperties serviceProperties
        {
            get
            {
                return this.servicePropertiesField;
            }
            set
            {
                this.servicePropertiesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public ServiceSpecification serviceSpecification
        {
            get
            {
                return this.serviceSpecificationField;
            }
            set
            {
                this.serviceSpecificationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public ServiceSecurity serviceSecurity
        {
            get
            {
                return this.serviceSecurityField;
            }
            set
            {
                this.serviceSecurityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class E2E
    {

        private string e2EDATAField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string E2EDATA
        {
            get
            {
                return this.e2EDATAField;
            }
            set
            {
                this.e2EDATAField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetServiceInstanceResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private GetServiceInstanceRes getServiceInstanceResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetServiceInstanceRes getServiceInstanceRes
        {
            get
            {
                return this.getServiceInstanceResField;
            }
            set
            {
                this.getServiceInstanceResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetServiceInstanc" +
        "e")]
    public partial class GetServiceInstanceRes : BaseResult
    {

        private ClientServiceInstance[] clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceInstance", IsNullable = true, Order = 0)]
        public ClientServiceInstance[] clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceInstance : TransactionDetails
    {

        private ClientServiceInstanceStatus clientServiceInstanceStatusField;

        private ClientServiceInstanceCharacteristic[] clientServiceInstanceCharacteristicField;

        private ClientServiceInstanceRoleOwnerShip[] clientServiceInstanceRoleOwnerShipField;

        private ClientServiceRole[] clientServiceRoleField;

        private string nameField;

        private ClientServiceInstanceIdentifier clientServiceInstanceIdentifierField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstanceStatus clientServiceInstanceStatus
        {
            get
            {
                return this.clientServiceInstanceStatusField;
            }
            set
            {
                this.clientServiceInstanceStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceInstanceCharacteristic", IsNullable = true, Order = 1)]
        public ClientServiceInstanceCharacteristic[] clientServiceInstanceCharacteristic
        {
            get
            {
                return this.clientServiceInstanceCharacteristicField;
            }
            set
            {
                this.clientServiceInstanceCharacteristicField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceInstanceRoleOwnerShip", IsNullable = true, Order = 2)]
        public ClientServiceInstanceRoleOwnerShip[] clientServiceInstanceRoleOwnerShip
        {
            get
            {
                return this.clientServiceInstanceRoleOwnerShipField;
            }
            set
            {
                this.clientServiceInstanceRoleOwnerShipField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceRole", IsNullable = true, Order = 3)]
        public ClientServiceRole[] clientServiceRole
        {
            get
            {
                return this.clientServiceRoleField;
            }
            set
            {
                this.clientServiceRoleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 5)]
        public ClientServiceInstanceIdentifier clientServiceInstanceIdentifier
        {
            get
            {
                return this.clientServiceInstanceIdentifierField;
            }
            set
            {
                this.clientServiceInstanceIdentifierField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceInstanceStatus
    {

        private string nameField;

        private string valueField;

        private System.Nullable<System.DateTime> dateTimeEffectiveField;

        private bool dateTimeEffectiveFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public System.Nullable<System.DateTime> dateTimeEffective
        {
            get
            {
                return this.dateTimeEffectiveField;
            }
            set
            {
                this.dateTimeEffectiveField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateTimeEffectiveSpecified
        {
            get
            {
                return this.dateTimeEffectiveFieldSpecified;
            }
            set
            {
                this.dateTimeEffectiveFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceInstanceCharacteristic : TransactionDetails
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Client))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientCharacteristic))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientServiceInstanceRoleOwnerShip))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientServiceInstance))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientServiceRoleCharacteristic))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientServiceRole))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientServiceInstanceCharacteristic))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ContactDetails))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientIdentityValidation))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientCredentialValidation))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientCredential))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientIdentity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkClientProfilesRequest))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM")]
    public partial class TransactionDetails
    {

        private string updateKeyField;

        private string actionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string updateKey
        {
            get
            {
                return this.updateKeyField;
            }
            set
            {
                this.updateKeyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string action
        {
            get
            {
                return this.actionField;
            }
            set
            {
                this.actionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class Client : TransactionDetails
    {

        private ClientIdentity[] clientIdentityField;

        private ClientIdentifier clientIdentifierField;

        private ClientStatus clientStatusField;

        private string typeField;

        private CustomerContact customerContactField;

        private ClientCharacteristic[] clientCharacteristicField;

        private ClientOrganisation clientOrganisationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientIdentity", IsNullable = true, Order = 0)]
        public ClientIdentity[] clientIdentity
        {
            get
            {
                return this.clientIdentityField;
            }
            set
            {
                this.clientIdentityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ClientIdentifier clientIdentifier
        {
            get
            {
                return this.clientIdentifierField;
            }
            set
            {
                this.clientIdentifierField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public ClientStatus clientStatus
        {
            get
            {
                return this.clientStatusField;
            }
            set
            {
                this.clientStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public CustomerContact customerContact
        {
            get
            {
                return this.customerContactField;
            }
            set
            {
                this.customerContactField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientCharacteristic", IsNullable = true, Order = 5)]
        public ClientCharacteristic[] clientCharacteristic
        {
            get
            {
                return this.clientCharacteristicField;
            }
            set
            {
                this.clientCharacteristicField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 6)]
        public ClientOrganisation clientOrganisation
        {
            get
            {
                return this.clientOrganisationField;
            }
            set
            {
                this.clientOrganisationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientIdentity : TransactionDetails
    {

        private string valueField;

        private string identityAliasField;

        private ManagedIdentifierDomain managedIdentifierDomainField;

        private ClientCredential[] clientCredentialField;

        private ClientIdentityStatus clientIdentityStatusField;

        private ClientIdentityValidation[] clientIdentityValidationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string identityAlias
        {
            get
            {
                return this.identityAliasField;
            }
            set
            {
                this.identityAliasField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public ManagedIdentifierDomain managedIdentifierDomain
        {
            get
            {
                return this.managedIdentifierDomainField;
            }
            set
            {
                this.managedIdentifierDomainField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientCredential", IsNullable = true, Order = 3)]
        public ClientCredential[] clientCredential
        {
            get
            {
                return this.clientCredentialField;
            }
            set
            {
                this.clientCredentialField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public ClientIdentityStatus clientIdentityStatus
        {
            get
            {
                return this.clientIdentityStatusField;
            }
            set
            {
                this.clientIdentityStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientIdentityValidation", IsNullable = true, Order = 5)]
        public ClientIdentityValidation[] clientIdentityValidation
        {
            get
            {
                return this.clientIdentityValidationField;
            }
            set
            {
                this.clientIdentityValidationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Resources")]
    public partial class ManagedIdentifierDomain
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientCredential : TransactionDetails
    {

        private System.Nullable<System.DateTime> dateAssignedField;

        private bool dateAssignedFieldSpecified;

        private string credentialValueField;

        private System.Nullable<System.DateTime> dateExpiredField;

        private bool dateExpiredFieldSpecified;

        private string credentialTypeField;

        private ClientCredentialStatus clientCredentialStatusField;

        private System.Nullable<System.DateTime> dateDespatchedField;

        private bool dateDespatchedFieldSpecified;

        private System.Nullable<System.DateTime> dateEnrolledField;

        private bool dateEnrolledFieldSpecified;

        private ClientCredentialValidation clientCredentialValidationField;

        private AuthenticationLevel authenticationLevelField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date", IsNullable = true, Order = 0)]
        public System.Nullable<System.DateTime> dateAssigned
        {
            get
            {
                return this.dateAssignedField;
            }
            set
            {
                this.dateAssignedField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateAssignedSpecified
        {
            get
            {
                return this.dateAssignedFieldSpecified;
            }
            set
            {
                this.dateAssignedFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string credentialValue
        {
            get
            {
                return this.credentialValueField;
            }
            set
            {
                this.credentialValueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date", IsNullable = true, Order = 2)]
        public System.Nullable<System.DateTime> dateExpired
        {
            get
            {
                return this.dateExpiredField;
            }
            set
            {
                this.dateExpiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateExpiredSpecified
        {
            get
            {
                return this.dateExpiredFieldSpecified;
            }
            set
            {
                this.dateExpiredFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public string credentialType
        {
            get
            {
                return this.credentialTypeField;
            }
            set
            {
                this.credentialTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public ClientCredentialStatus clientCredentialStatus
        {
            get
            {
                return this.clientCredentialStatusField;
            }
            set
            {
                this.clientCredentialStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date", IsNullable = true, Order = 5)]
        public System.Nullable<System.DateTime> dateDespatched
        {
            get
            {
                return this.dateDespatchedField;
            }
            set
            {
                this.dateDespatchedField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateDespatchedSpecified
        {
            get
            {
                return this.dateDespatchedFieldSpecified;
            }
            set
            {
                this.dateDespatchedFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date", IsNullable = true, Order = 6)]
        public System.Nullable<System.DateTime> dateEnrolled
        {
            get
            {
                return this.dateEnrolledField;
            }
            set
            {
                this.dateEnrolledField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateEnrolledSpecified
        {
            get
            {
                return this.dateEnrolledFieldSpecified;
            }
            set
            {
                this.dateEnrolledFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 7)]
        public ClientCredentialValidation clientCredentialValidation
        {
            get
            {
                return this.clientCredentialValidationField;
            }
            set
            {
                this.clientCredentialValidationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 8)]
        public AuthenticationLevel authenticationLevel
        {
            get
            {
                return this.authenticationLevelField;
            }
            set
            {
                this.authenticationLevelField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientCredentialStatus
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientCredentialValidation : TransactionDetails
    {

        private string passwordReminderQuestionField;

        private string passwordReminderAnswerField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string passwordReminderQuestion
        {
            get
            {
                return this.passwordReminderQuestionField;
            }
            set
            {
                this.passwordReminderQuestionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string passwordReminderAnswer
        {
            get
            {
                return this.passwordReminderAnswerField;
            }
            set
            {
                this.passwordReminderAnswerField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class AuthenticationLevel
    {

        private string idField;

        private string descriptionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientIdentityStatus
    {

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientIdentityValidation : TransactionDetails
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientIdentifier
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientStatus
    {

        private string nameField;

        private string valueField;

        private System.Nullable<System.DateTime> dateTimeEffectiveField;

        private bool dateTimeEffectiveFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public System.Nullable<System.DateTime> dateTimeEffective
        {
            get
            {
                return this.dateTimeEffectiveField;
            }
            set
            {
                this.dateTimeEffectiveField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateTimeEffectiveSpecified
        {
            get
            {
                return this.dateTimeEffectiveFieldSpecified;
            }
            set
            {
                this.dateTimeEffectiveFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Parties/PartyRole" +
        "s/Customer")]
    public partial class CustomerContact : Identity
    {

        private string idField;

        private string notesField;

        private string jobTitleField;

        private ContactDetails contactDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string notes
        {
            get
            {
                return this.notesField;
            }
            set
            {
                this.notesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string jobTitle
        {
            get
            {
                return this.jobTitleField;
            }
            set
            {
                this.jobTitleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public ContactDetails contactDetails
        {
            get
            {
                return this.contactDetailsField;
            }
            set
            {
                this.contactDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Parties")]
    public partial class ContactDetails : TransactionDetails
    {

        private Person personField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public Person person
        {
            get
            {
                return this.personField;
            }
            set
            {
                this.personField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Parties")]
    public partial class Person
    {

        private string idField;

        private string genderField;

        private System.Nullable<System.DateTime> dateOfBirthField;

        private bool dateOfBirthFieldSpecified;

        private ContactDetails contactInfoField;

        private PersonName personNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string gender
        {
            get
            {
                return this.genderField;
            }
            set
            {
                this.genderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date", IsNullable = true, Order = 2)]
        public System.Nullable<System.DateTime> dateOfBirth
        {
            get
            {
                return this.dateOfBirthField;
            }
            set
            {
                this.dateOfBirthField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateOfBirthSpecified
        {
            get
            {
                return this.dateOfBirthFieldSpecified;
            }
            set
            {
                this.dateOfBirthFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public ContactDetails contactInfo
        {
            get
            {
                return this.contactInfoField;
            }
            set
            {
                this.contactInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public PersonName personName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Parties")]
    public partial class PersonName
    {

        private string titleField;

        private string forenameField;

        private string surnameField;

        private string nicknameField;

        private string firstMiddleNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string title
        {
            get
            {
                return this.titleField;
            }
            set
            {
                this.titleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string forename
        {
            get
            {
                return this.forenameField;
            }
            set
            {
                this.forenameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string surname
        {
            get
            {
                return this.surnameField;
            }
            set
            {
                this.surnameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public string nickname
        {
            get
            {
                return this.nicknameField;
            }
            set
            {
                this.nicknameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public string firstMiddleName
        {
            get
            {
                return this.firstMiddleNameField;
            }
            set
            {
                this.firstMiddleNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CustomerContact))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Parties")]
    public partial class Identity
    {

        private string typeField;

        private Client clientField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public Client client
        {
            get
            {
                return this.clientField;
            }
            set
            {
                this.clientField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientCharacteristic : TransactionDetails
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientOrganisation
    {

        private ClientOrganisationName clientOrganisationNameField;

        private ClientOrganisationContactDetails[] clientOrganisationContactDetailsField;

        private string idField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientOrganisationName clientOrganisationName
        {
            get
            {
                return this.clientOrganisationNameField;
            }
            set
            {
                this.clientOrganisationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientOrganisationContactDetails", IsNullable = true, Order = 1)]
        public ClientOrganisationContactDetails[] clientOrganisationContactDetails
        {
            get
            {
                return this.clientOrganisationContactDetailsField;
            }
            set
            {
                this.clientOrganisationContactDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientOrganisationName
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientOrganisationContactDetails
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceInstanceRoleOwnerShip : TransactionDetails
    {

        private string licenceTypeField;

        private string numberOwnedField;

        private string numberAssignedField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string licenceType
        {
            get
            {
                return this.licenceTypeField;
            }
            set
            {
                this.licenceTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string numberOwned
        {
            get
            {
                return this.numberOwnedField;
            }
            set
            {
                this.numberOwnedField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string numberAssigned
        {
            get
            {
                return this.numberAssignedField;
            }
            set
            {
                this.numberAssignedField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceRoleCharacteristic : TransactionDetails
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceRole : TransactionDetails
    {

        private string idField;

        private string nameField;

        private ClientServiceRoleStatus clientServiceRoleStatusField;

        private ClientServiceRoleCharacteristic[] clientServiceRoleCharacteristicField;

        private AuthenticationLevel trustLevelField;

        private ClientIdentity[] clientIdentityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public ClientServiceRoleStatus clientServiceRoleStatus
        {
            get
            {
                return this.clientServiceRoleStatusField;
            }
            set
            {
                this.clientServiceRoleStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceRoleCharacteristic", IsNullable = true, Order = 3)]
        public ClientServiceRoleCharacteristic[] clientServiceRoleCharacteristic
        {
            get
            {
                return this.clientServiceRoleCharacteristicField;
            }
            set
            {
                this.clientServiceRoleCharacteristicField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public AuthenticationLevel trustLevel
        {
            get
            {
                return this.trustLevelField;
            }
            set
            {
                this.trustLevelField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientIdentity", IsNullable = true, Order = 5)]
        public ClientIdentity[] clientIdentity
        {
            get
            {
                return this.clientIdentityField;
            }
            set
            {
                this.clientIdentityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceRoleStatus
    {

        private string nameField;

        private string valueField;

        private System.Nullable<System.DateTime> dateTimeEffectiveField;

        private bool dateTimeEffectiveFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public System.Nullable<System.DateTime> dateTimeEffective
        {
            get
            {
                return this.dateTimeEffectiveField;
            }
            set
            {
                this.dateTimeEffectiveField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateTimeEffectiveSpecified
        {
            get
            {
                return this.dateTimeEffectiveFieldSpecified;
            }
            set
            {
                this.dateTimeEffectiveFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class LinkClientProfilesRequest : TransactionDetails
    {

        private StandardHeaderBlock standardHeaderField;

        private ClientIdentity primaryClientIdentityField;

        private ClientIdentity linkClientIdentityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ClientIdentity primaryClientIdentity
        {
            get
            {
                return this.primaryClientIdentityField;
            }
            set
            {
                this.primaryClientIdentityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public ClientIdentity linkClientIdentity
        {
            get
            {
                return this.linkClientIdentityField;
            }
            set
            {
                this.linkClientIdentityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Users")]
    public partial class ClientServiceInstanceIdentifier
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetClientIdentifiersRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetClientServiceRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ManageClientServiceRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ManageServiceInstanceRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetOrganisationDetailsRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ManageClientIdentityRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetServiceSpecificationRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetClientProfileRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetServiceInstanceRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ManageClientProfileRes))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkClientProfilesResponse))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Standards")]
    public partial class BaseResult
    {

        private Message[] messagesField;

        private MessageTemplateText messageTemplateTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("messages", IsNullable = true, Order = 0)]
        public Message[] messages
        {
            get
            {
                return this.messagesField;
            }
            set
            {
                this.messagesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public MessageTemplateText messageTemplateText
        {
            get
            {
                return this.messageTemplateTextField;
            }
            set
            {
                this.messageTemplateTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Standards")]
    public partial class Message
    {

        private string messageTypeField;

        private string messageSeverityField;

        private string descriptionField;

        private string messageCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string messageType
        {
            get
            {
                return this.messageTypeField;
            }
            set
            {
                this.messageTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string messageSeverity
        {
            get
            {
                return this.messageSeverityField;
            }
            set
            {
                this.messageSeverityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public string messageCode
        {
            get
            {
                return this.messageCodeField;
            }
            set
            {
                this.messageCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Standards")]
    public partial class MessageTemplateText
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientIdentifi" +
        "ers")]
    public partial class GetClientIdentifiersRes : BaseResult
    {

        private ClientIdentity[] clientIdentityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientIdentity", IsNullable = true, Order = 0)]
        public ClientIdentity[] clientIdentity
        {
            get
            {
                return this.clientIdentityField;
            }
            set
            {
                this.clientIdentityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientService")]
    public partial class GetClientServiceRes : BaseResult
    {

        private ClientServiceInstance[] clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceInstance", IsNullable = true, Order = 0)]
        public ClientServiceInstance[] clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageClientServi" +
        "ce")]
    public partial class ManageClientServiceRes : BaseResult
    {

        private ClientServiceInstance clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstance clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageServiceInst" +
        "ance")]
    public partial class ManageServiceInstanceRes : BaseResult
    {

        private ClientServiceInstance clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstance clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetOrganisationDe" +
        "tails")]
    public partial class GetOrganisationDetailsRes : BaseResult
    {

        private ClientOrganisation clientOrganisationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientOrganisation clientOrganisation
        {
            get
            {
                return this.clientOrganisationField;
            }
            set
            {
                this.clientOrganisationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageClientIdent" +
        "ity")]
    public partial class ManageClientIdentityRes : BaseResult
    {

        private ClientIdentity clientIdentityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientIdentity clientIdentity
        {
            get
            {
                return this.clientIdentityField;
            }
            set
            {
                this.clientIdentityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetServiceSpecifi" +
        "cation")]
    public partial class GetServiceSpecificationRes : BaseResult
    {

        private ServiceSpecification1 serviceSpecificationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ServiceSpecification1 serviceSpecification
        {
            get
            {
                return this.serviceSpecificationField;
            }
            set
            {
                this.serviceSpecificationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(TypeName = "ServiceSpecification", Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Services")]
    public partial class ServiceSpecification1 : Specification
    {

        private string idField;

        private string nameField;

        private string statusField;

        private string descriptionField;

        private ServiceSpecCharacteristic[] serviceSpecCharacteristicField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public string description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("serviceSpecCharacteristic", IsNullable = true, Order = 4)]
        public ServiceSpecCharacteristic[] serviceSpecCharacteristic
        {
            get
            {
                return this.serviceSpecCharacteristicField;
            }
            set
            {
                this.serviceSpecCharacteristicField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Services")]
    public partial class ServiceSpecCharacteristic
    {

        private string nameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ServiceSpecification1))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/CoreClasses/Speci" +
        "fications")]
    public partial class Specification
    {

        private string typeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientProfile")]
    public partial class GetClientProfileRes : BaseResult
    {

        private ClientProfile clientProfileField;

        private Client[] linkedClientField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientProfile clientProfile
        {
            get
            {
                return this.clientProfileField;
            }
            set
            {
                this.clientProfileField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("linkedClient", IsNullable = true, Order = 1)]
        public Client[] linkedClient
        {
            get
            {
                return this.linkedClientField;
            }
            set
            {
                this.linkedClientField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientProfile")]
    public partial class ClientProfile
    {

        private Client clientField;

        private ClientServiceInstance[] clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public Client client
        {
            get
            {
                return this.clientField;
            }
            set
            {
                this.clientField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("clientServiceInstance", IsNullable = true, Order = 1)]
        public ClientServiceInstance[] clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageClientProfi" +
        "le")]
    public partial class ManageClientProfileRes : BaseResult
    {

        private ClientProfile clientProfileField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientProfile clientProfile
        {
            get
            {
                return this.clientProfileField;
            }
            set
            {
                this.clientProfileField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class LinkClientProfilesResponse : BaseResult
    {

        private StandardHeaderBlock standardHeaderField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetServiceInstanc" +
        "e")]
    public partial class GetServiceInstanceReq
    {

        private ClientServiceInstanceSearchCriteria clientServiceInstanceSearchCriteriaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstanceSearchCriteria clientServiceInstanceSearchCriteria
        {
            get
            {
                return this.clientServiceInstanceSearchCriteriaField;
            }
            set
            {
                this.clientServiceInstanceSearchCriteriaField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM")]
    public partial class ClientServiceInstanceSearchCriteria : ClientSearchCriteria
    {

        private string serviceInstanceKeyField;

        private string serviceCodeField;

        private string roleCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string serviceInstanceKey
        {
            get
            {
                return this.serviceInstanceKeyField;
            }
            set
            {
                this.serviceInstanceKeyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string serviceCode
        {
            get
            {
                return this.serviceCodeField;
            }
            set
            {
                this.serviceCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string roleCode
        {
            get
            {
                return this.roleCodeField;
            }
            set
            {
                this.roleCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ClientServiceInstanceSearchCriteria))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM")]
    public partial class ClientSearchCriteria
    {

        private string universalidField;

        private string identifierDomainCodeField;

        private string identifierValueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string universalid
        {
            get
            {
                return this.universalidField;
            }
            set
            {
                this.universalidField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string identifierDomainCode
        {
            get
            {
                return this.identifierDomainCodeField;
            }
            set
            {
                this.identifierDomainCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string identifierValue
        {
            get
            {
                return this.identifierValueField;
            }
            set
            {
                this.identifierValueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetServiceInstanceRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private GetServiceInstanceReq getServiceInstanceReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetServiceInstanceReq getServiceInstanceReq
        {
            get
            {
                return this.getServiceInstanceReqField;
            }
            set
            {
                this.getServiceInstanceReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageServiceInstanceResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageServiceInstanceRes manageServiceInstanceResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageServiceInstanceRes manageServiceInstanceRes
        {
            get
            {
                return this.manageServiceInstanceResField;
            }
            set
            {
                this.manageServiceInstanceResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageServiceInst" +
        "ance")]
    public partial class ManageServiceInstanceReq
    {

        private ClientServiceInstance clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstance clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageServiceInstanceRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageServiceInstanceReq manageServiceInstanceReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageServiceInstanceReq manageServiceInstanceReq
        {
            get
            {
                return this.manageServiceInstanceReqField;
            }
            set
            {
                this.manageServiceInstanceReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetServiceSpecificationResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private GetServiceSpecificationRes getServiceSpecificationResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetServiceSpecificationRes getServiceSpecificationRes
        {
            get
            {
                return this.getServiceSpecificationResField;
            }
            set
            {
                this.getServiceSpecificationResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetServiceSpecifi" +
        "cation")]
    public partial class GetServiceSpecificationReq
    {

        private ServiceSpecification1 serviceSpecsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ServiceSpecification1 serviceSpecs
        {
            get
            {
                return this.serviceSpecsField;
            }
            set
            {
                this.serviceSpecsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetServiceSpecificationRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private GetServiceSpecificationReq getServiceSpecificationReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetServiceSpecificationReq getServiceSpecificationReq
        {
            get
            {
                return this.getServiceSpecificationReqField;
            }
            set
            {
                this.getServiceSpecificationReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetClientServiceResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private GetClientServiceRes getClientServiceResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetClientServiceRes getClientServiceRes
        {
            get
            {
                return this.getClientServiceResField;
            }
            set
            {
                this.getClientServiceResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientService")]
    public partial class GetClientServiceReq
    {

        private ClientServiceInstanceSearchCriteria clientServiceInstanceSearchCriteriaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstanceSearchCriteria clientServiceInstanceSearchCriteria
        {
            get
            {
                return this.clientServiceInstanceSearchCriteriaField;
            }
            set
            {
                this.clientServiceInstanceSearchCriteriaField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetClientServiceRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private GetClientServiceReq getClientServiceReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetClientServiceReq getClientServiceReq
        {
            get
            {
                return this.getClientServiceReqField;
            }
            set
            {
                this.getClientServiceReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageClientServiceResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageClientServiceRes manageClientServiceResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageClientServiceRes manageClientServiceRes
        {
            get
            {
                return this.manageClientServiceResField;
            }
            set
            {
                this.manageClientServiceResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageClientServi" +
        "ce")]
    public partial class ManageClientServiceReq
    {

        private ClientServiceInstanceSearchCriteria clientServiceInstanceSearchCriteriaField;

        private ClientServiceInstance clientServiceInstanceField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientServiceInstanceSearchCriteria clientServiceInstanceSearchCriteria
        {
            get
            {
                return this.clientServiceInstanceSearchCriteriaField;
            }
            set
            {
                this.clientServiceInstanceSearchCriteriaField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ClientServiceInstance clientServiceInstance
        {
            get
            {
                return this.clientServiceInstanceField;
            }
            set
            {
                this.clientServiceInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageClientServiceRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageClientServiceReq manageClientServiceReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageClientServiceReq manageClientServiceReq
        {
            get
            {
                return this.manageClientServiceReqField;
            }
            set
            {
                this.manageClientServiceReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetOrganisationDetailsResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private GetOrganisationDetailsRes getOrganisationDetailsResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetOrganisationDetailsRes getOrganisationDetailsRes
        {
            get
            {
                return this.getOrganisationDetailsResField;
            }
            set
            {
                this.getOrganisationDetailsResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetOrganisationDe" +
        "tails")]
    public partial class GetOrganisationDetailsReq
    {

        private ClientOrganisation clientOrganisationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientOrganisation clientOrganisation
        {
            get
            {
                return this.clientOrganisationField;
            }
            set
            {
                this.clientOrganisationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetOrganisationDetailsRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private GetOrganisationDetailsReq getOrganisationDetailsReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetOrganisationDetailsReq getOrganisationDetailsReq
        {
            get
            {
                return this.getOrganisationDetailsReqField;
            }
            set
            {
                this.getOrganisationDetailsReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageClientIdentityResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageClientIdentityRes manageClientIdentityResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageClientIdentityRes manageClientIdentityRes
        {
            get
            {
                return this.manageClientIdentityResField;
            }
            set
            {
                this.manageClientIdentityResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageClientIdent" +
        "ity")]
    public partial class ManageClientIdentityReq
    {

        private ClientSearchCriteria clientSearchCriteriaField;

        private ClientIdentity clientIdentityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientSearchCriteria clientSearchCriteria
        {
            get
            {
                return this.clientSearchCriteriaField;
            }
            set
            {
                this.clientSearchCriteriaField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ClientIdentity clientIdentity
        {
            get
            {
                return this.clientIdentityField;
            }
            set
            {
                this.clientIdentityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageClientIdentityRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageClientIdentityReq manageClientIdentityReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageClientIdentityReq manageClientIdentityReq
        {
            get
            {
                return this.manageClientIdentityReqField;
            }
            set
            {
                this.manageClientIdentityReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetClientIdentifiersResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private GetClientIdentifiersRes getClientIdentifiersResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetClientIdentifiersRes getClientIdentifiersRes
        {
            get
            {
                return this.getClientIdentifiersResField;
            }
            set
            {
                this.getClientIdentifiersResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientIdentifi" +
        "ers")]
    public partial class GetClientIdentifiersReq
    {

        private ClientSearchCriteria clientSearchCriteriaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientSearchCriteria clientSearchCriteria
        {
            get
            {
                return this.clientSearchCriteriaField;
            }
            set
            {
                this.clientSearchCriteriaField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetClientIdentifiersRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private GetClientIdentifiersReq getClientIdentifierReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetClientIdentifiersReq getClientIdentifierReq
        {
            get
            {
                return this.getClientIdentifierReqField;
            }
            set
            {
                this.getClientIdentifierReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetClientProfileResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private GetClientProfileRes getClientProfileResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetClientProfileRes getClientProfileRes
        {
            get
            {
                return this.getClientProfileResField;
            }
            set
            {
                this.getClientProfileResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/Standards")]
    public partial class ResponseParameters
    {

        private string isClientIdentitiesRequiredField;

        private string isClientServiceRolesRequiredField;

        private string isClientServiceRoleCharacteristicRequiredField;

        private string isClientServiceInstanceRequiredField;

        private string isClientServiceInstanceCharacteristicsrequiredField;

        private string isClientCredentialsRequiredField;

        private string isLinkedProfilesRequiredField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public string isClientIdentitiesRequired
        {
            get
            {
                return this.isClientIdentitiesRequiredField;
            }
            set
            {
                this.isClientIdentitiesRequiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public string isClientServiceRolesRequired
        {
            get
            {
                return this.isClientServiceRolesRequiredField;
            }
            set
            {
                this.isClientServiceRolesRequiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 2)]
        public string isClientServiceRoleCharacteristicRequired
        {
            get
            {
                return this.isClientServiceRoleCharacteristicRequiredField;
            }
            set
            {
                this.isClientServiceRoleCharacteristicRequiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 3)]
        public string isClientServiceInstanceRequired
        {
            get
            {
                return this.isClientServiceInstanceRequiredField;
            }
            set
            {
                this.isClientServiceInstanceRequiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 4)]
        public string isClientServiceInstanceCharacteristicsrequired
        {
            get
            {
                return this.isClientServiceInstanceCharacteristicsrequiredField;
            }
            set
            {
                this.isClientServiceInstanceCharacteristicsrequiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 5)]
        public string isClientCredentialsRequired
        {
            get
            {
                return this.isClientCredentialsRequiredField;
            }
            set
            {
                this.isClientCredentialsRequiredField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 6)]
        public string isLinkedProfilesRequired
        {
            get
            {
                return this.isLinkedProfilesRequiredField;
            }
            set
            {
                this.isLinkedProfilesRequiredField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/GetClientProfile")]
    public partial class GetClientProfileReq
    {

        private ResponseParameters responseParameterField;

        private ClientSearchCriteria clientSearchCriteriaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ResponseParameters responseParameter
        {
            get
            {
                return this.responseParameterField;
            }
            set
            {
                this.responseParameterField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ClientSearchCriteria clientSearchCriteria
        {
            get
            {
                return this.clientSearchCriteriaField;
            }
            set
            {
                this.clientSearchCriteriaField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class GetClientProfileRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private GetClientProfileReq getClientProfileReqField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public GetClientProfileReq getClientProfileReq
        {
            get
            {
                return this.getClientProfileReqField;
            }
            set
            {
                this.getClientProfileReqField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18")]
    public partial class ManageClientProfileResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private ManageClientProfileRes manageClientProfileResField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 1)]
        public ManageClientProfileRes manageClientProfileRes
        {
            get
            {
                return this.manageClientProfileResField;
            }
            set
            {
                this.manageClientProfileResField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18/CCM/ManageClientProfi" +
        "le")]
    public partial class ManageClientProfileReq
    {

        private ClientProfile clientProfileField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true, Order = 0)]
        public ClientProfile clientProfile
        {
            get
            {
                return this.clientProfileField;
            }
            set
            {
                this.clientProfileField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class ServiceSecurity
    {

        private string idField;

        private string roleField;

        private string typeField;

        private string authenticationLevelField;

        private string authenticationTokenField;

        private string userEntitlementsField;

        private string tokenExpiryField;

        private string callingApplicationField;

        private string callingApplicationCredentialsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string role
        {
            get
            {
                return this.roleField;
            }
            set
            {
                this.roleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string authenticationLevel
        {
            get
            {
                return this.authenticationLevelField;
            }
            set
            {
                this.authenticationLevelField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public string authenticationToken
        {
            get
            {
                return this.authenticationTokenField;
            }
            set
            {
                this.authenticationTokenField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public string userEntitlements
        {
            get
            {
                return this.userEntitlementsField;
            }
            set
            {
                this.userEntitlementsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 6)]
        public string tokenExpiry
        {
            get
            {
                return this.tokenExpiryField;
            }
            set
            {
                this.tokenExpiryField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 7)]
        public string callingApplication
        {
            get
            {
                return this.callingApplicationField;
            }
            set
            {
                this.callingApplicationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 8)]
        public string callingApplicationCredentials
        {
            get
            {
                return this.callingApplicationCredentialsField;
            }
            set
            {
                this.callingApplicationCredentialsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class ServiceSpecification
    {

        private string payloadFormatField;

        private string versionField;

        private string revisionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string payloadFormat
        {
            get
            {
                return this.payloadFormatField;
            }
            set
            {
                this.payloadFormatField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string revision
        {
            get
            {
                return this.revisionField;
            }
            set
            {
                this.revisionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class MessageDelivery
    {

        private string messagePersistenceField;

        private string messageRetriesField;

        private string messageRetryIntervalField;

        private string messageQoSField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string messagePersistence
        {
            get
            {
                return this.messagePersistenceField;
            }
            set
            {
                this.messagePersistenceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string messageRetries
        {
            get
            {
                return this.messageRetriesField;
            }
            set
            {
                this.messageRetriesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string messageRetryInterval
        {
            get
            {
                return this.messageRetryIntervalField;
            }
            set
            {
                this.messageRetryIntervalField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string messageQoS
        {
            get
            {
                return this.messageQoSField;
            }
            set
            {
                this.messageQoSField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class MessageExpiry
    {

        private string expiryTimeField;

        private string expiryActionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string expiryTime
        {
            get
            {
                return this.expiryTimeField;
            }
            set
            {
                this.expiryTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string expiryAction
        {
            get
            {
                return this.expiryActionField;
            }
            set
            {
                this.expiryActionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class ServiceProperties
    {

        private MessageExpiry messageExpiryField;

        private MessageDelivery messageDeliveryField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public MessageExpiry messageExpiry
        {
            get
            {
                return this.messageExpiryField;
            }
            set
            {
                this.messageExpiryField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public MessageDelivery messageDelivery
        {
            get
            {
                return this.messageDeliveryField;
            }
            set
            {
                this.messageDeliveryField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class ContextItem
    {

        private string contextIdField;

        private string contextNameField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string contextId
        {
            get
            {
                return this.contextIdField;
            }
            set
            {
                this.contextIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string contextName
        {
            get
            {
                return this.contextNameField;
            }
            set
            {
                this.contextNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class AddressReference
    {

        private string addressField;

        private ContextItem[] contextItemListField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "anyURI", Order = 0)]
        public string address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 1)]
        [System.Xml.Serialization.XmlArrayItemAttribute("contextItem", IsNullable = false)]
        public ContextItem[] contextItemList
        {
            get
            {
                return this.contextItemListField;
            }
            set
            {
                this.contextItemListField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class ServiceAddressing
    {

        private string fromField;

        private AddressReference toField;

        private AddressReference replyToField;

        private string relatesToField;

        private AddressReference faultToField;

        private string messageIdField;

        private string serviceNameField;

        private string actionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "anyURI", Order = 0)]
        public string from
        {
            get
            {
                return this.fromField;
            }
            set
            {
                this.fromField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public AddressReference to
        {
            get
            {
                return this.toField;
            }
            set
            {
                this.toField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public AddressReference replyTo
        {
            get
            {
                return this.replyToField;
            }
            set
            {
                this.replyToField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string relatesTo
        {
            get
            {
                return this.relatesToField;
            }
            set
            {
                this.relatesToField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public AddressReference faultTo
        {
            get
            {
                return this.faultToField;
            }
            set
            {
                this.faultToField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public string messageId
        {
            get
            {
                return this.messageIdField;
            }
            set
            {
                this.messageIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "anyURI", Order = 6)]
        public string serviceName
        {
            get
            {
                return this.serviceNameField;
            }
            set
            {
                this.serviceNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "anyURI", IsNullable = true, Order = 7)]
        public string action
        {
            get
            {
                return this.actionField;
            }
            set
            {
                this.actionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/")]
    public partial class ServiceState
    {

        private string stateCodeField;

        private string errorCodeField;

        private string errorDescField;

        private string errorTextField;

        private string errorTraceField;

        private bool resendIndicatorField;

        private bool resendIndicatorFieldSpecified;

        private string retriesRemainingField;

        private string retryIntervalField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string stateCode
        {
            get
            {
                return this.stateCodeField;
            }
            set
            {
                this.stateCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string errorDesc
        {
            get
            {
                return this.errorDescField;
            }
            set
            {
                this.errorDescField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string errorText
        {
            get
            {
                return this.errorTextField;
            }
            set
            {
                this.errorTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public string errorTrace
        {
            get
            {
                return this.errorTraceField;
            }
            set
            {
                this.errorTraceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public bool resendIndicator
        {
            get
            {
                return this.resendIndicatorField;
            }
            set
            {
                this.resendIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool resendIndicatorSpecified
        {
            get
            {
                return this.resendIndicatorFieldSpecified;
            }
            set
            {
                this.resendIndicatorFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "integer", Order = 6)]
        public string retriesRemaining
        {
            get
            {
                return this.retriesRemainingField;
            }
            set
            {
                this.retriesRemainingField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "integer", Order = 7)]
        public string retryInterval
        {
            get
            {
                return this.retryIntervalField;
            }
            set
            {
                this.retryIntervalField = value;
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageClientProfileRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageClientProfileRequest manageClientProfileRequest;

        public manageClientProfileRequest1()
        {
        }

        public manageClientProfileRequest1(ManageClientProfileRequest manageClientProfileRequest)
        {
            this.manageClientProfileRequest = manageClientProfileRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageClientProfileResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageClientProfileResponse manageClientProfileResponse;

        public manageClientProfileResponse1()
        {
        }

        public manageClientProfileResponse1(ManageClientProfileResponse manageClientProfileResponse)
        {
            this.manageClientProfileResponse = manageClientProfileResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getClientProfileRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetClientProfileRequest getClientProfileRequest;

        public getClientProfileRequest1()
        {
        }

        public getClientProfileRequest1(GetClientProfileRequest getClientProfileRequest)
        {
            this.getClientProfileRequest = getClientProfileRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getClientProfileResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetClientProfileResponse getClientProfileResponse;

        public getClientProfileResponse1()
        {
        }

        public getClientProfileResponse1(GetClientProfileResponse getClientProfileResponse)
        {
            this.getClientProfileResponse = getClientProfileResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getClientIdentifiersRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetClientIdentifiersRequest getClientIdentifiersRequest;

        public getClientIdentifiersRequest1()
        {
        }

        public getClientIdentifiersRequest1(GetClientIdentifiersRequest getClientIdentifiersRequest)
        {
            this.getClientIdentifiersRequest = getClientIdentifiersRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getClientIdentifiersResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetClientIdentifiersResponse getClientIdentifiersResponse;

        public getClientIdentifiersResponse1()
        {
        }

        public getClientIdentifiersResponse1(GetClientIdentifiersResponse getClientIdentifiersResponse)
        {
            this.getClientIdentifiersResponse = getClientIdentifiersResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageClientIdentityRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageClientIdentityRequest manageClientIdentityRequest;

        public manageClientIdentityRequest1()
        {
        }

        public manageClientIdentityRequest1(ManageClientIdentityRequest manageClientIdentityRequest)
        {
            this.manageClientIdentityRequest = manageClientIdentityRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageClientIdentityResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageClientIdentityResponse manageClientIdentityResponse;

        public manageClientIdentityResponse1()
        {
        }

        public manageClientIdentityResponse1(ManageClientIdentityResponse manageClientIdentityResponse)
        {
            this.manageClientIdentityResponse = manageClientIdentityResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getOrganisationDetailsRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetOrganisationDetailsRequest getOrganisationDetailsRequest;

        public getOrganisationDetailsRequest1()
        {
        }

        public getOrganisationDetailsRequest1(GetOrganisationDetailsRequest getOrganisationDetailsRequest)
        {
            this.getOrganisationDetailsRequest = getOrganisationDetailsRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getOrganisationDetailsResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetOrganisationDetailsResponse getOrganisationDetailsResponse;

        public getOrganisationDetailsResponse1()
        {
        }

        public getOrganisationDetailsResponse1(GetOrganisationDetailsResponse getOrganisationDetailsResponse)
        {
            this.getOrganisationDetailsResponse = getOrganisationDetailsResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class linkClientProfilesRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public LinkClientProfilesRequest linkClientProfilesRequest;

        public linkClientProfilesRequest1()
        {
        }

        public linkClientProfilesRequest1(LinkClientProfilesRequest linkClientProfilesRequest)
        {
            this.linkClientProfilesRequest = linkClientProfilesRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class linkClientProfilesResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public LinkClientProfilesResponse linkClientProfilesResponse;

        public linkClientProfilesResponse1()
        {
        }

        public linkClientProfilesResponse1(LinkClientProfilesResponse linkClientProfilesResponse)
        {
            this.linkClientProfilesResponse = linkClientProfilesResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public interface ClientProfileSyncPortTypeChannel : ClientProfileSyncPortType, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public partial class ClientProfileSyncPortTypeClient : System.ServiceModel.ClientBase<ClientProfileSyncPortType>, ClientProfileSyncPortType
    {

        public ClientProfileSyncPortTypeClient()
        {
        }

        public ClientProfileSyncPortTypeClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
        }

        public ClientProfileSyncPortTypeClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public ClientProfileSyncPortTypeClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public ClientProfileSyncPortTypeClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        manageClientProfileResponse1 ClientProfileSyncPortType.manageClientProfile(manageClientProfileRequest1 request)
        {
            return base.Channel.manageClientProfile(request);
        }

        public ManageClientProfileResponse manageClientProfile(ManageClientProfileRequest manageClientProfileRequest)
        {
            manageClientProfileRequest1 inValue = new manageClientProfileRequest1();
            inValue.manageClientProfileRequest = manageClientProfileRequest;
            manageClientProfileResponse1 retVal = ((ClientProfileSyncPortType)(this)).manageClientProfile(inValue);
            return retVal.manageClientProfileResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        getClientProfileResponse1 ClientProfileSyncPortType.getClientProfile(getClientProfileRequest1 request)
        {
            return base.Channel.getClientProfile(request);
        }

        public GetClientProfileResponse getClientProfile(GetClientProfileRequest getClientProfileRequest)
        {
            getClientProfileRequest1 inValue = new getClientProfileRequest1();
            inValue.getClientProfileRequest = getClientProfileRequest;
            getClientProfileResponse1 retVal = ((ClientProfileSyncPortType)(this)).getClientProfile(inValue);
            return retVal.getClientProfileResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        getClientIdentifiersResponse1 ClientProfileSyncPortType.getClientIdentifiers(getClientIdentifiersRequest1 request)
        {
            return base.Channel.getClientIdentifiers(request);
        }

        public GetClientIdentifiersResponse getClientIdentifiers(GetClientIdentifiersRequest getClientIdentifiersRequest)
        {
            getClientIdentifiersRequest1 inValue = new getClientIdentifiersRequest1();
            inValue.getClientIdentifiersRequest = getClientIdentifiersRequest;
            getClientIdentifiersResponse1 retVal = ((ClientProfileSyncPortType)(this)).getClientIdentifiers(inValue);
            return retVal.getClientIdentifiersResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        manageClientIdentityResponse1 ClientProfileSyncPortType.manageClientIdentity(manageClientIdentityRequest1 request)
        {
            return base.Channel.manageClientIdentity(request);
        }

        public ManageClientIdentityResponse manageClientIdentity(ManageClientIdentityRequest manageClientIdentityRequest)
        {
            manageClientIdentityRequest1 inValue = new manageClientIdentityRequest1();
            inValue.manageClientIdentityRequest = manageClientIdentityRequest;
            manageClientIdentityResponse1 retVal = ((ClientProfileSyncPortType)(this)).manageClientIdentity(inValue);
            return retVal.manageClientIdentityResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        getOrganisationDetailsResponse1 ClientProfileSyncPortType.getOrganisationDetails(getOrganisationDetailsRequest1 request)
        {
            return base.Channel.getOrganisationDetails(request);
        }

        public GetOrganisationDetailsResponse getOrganisationDetails(GetOrganisationDetailsRequest getOrganisationDetailsRequest)
        {
            getOrganisationDetailsRequest1 inValue = new getOrganisationDetailsRequest1();
            inValue.getOrganisationDetailsRequest = getOrganisationDetailsRequest;
            getOrganisationDetailsResponse1 retVal = ((ClientProfileSyncPortType)(this)).getOrganisationDetails(inValue);
            return retVal.getOrganisationDetailsResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        linkClientProfilesResponse1 ClientProfileSyncPortType.linkClientProfiles(linkClientProfilesRequest1 request)
        {
            return base.Channel.linkClientProfiles(request);
        }

        public LinkClientProfilesResponse linkClientProfiles(LinkClientProfilesRequest linkClientProfilesRequest)
        {
            linkClientProfilesRequest1 inValue = new linkClientProfilesRequest1();
            inValue.linkClientProfilesRequest = linkClientProfilesRequest;
            linkClientProfilesResponse1 retVal = ((ClientProfileSyncPortType)(this)).linkClientProfiles(inValue);
            return retVal.linkClientProfilesResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(Namespace = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18", ConfigurationName = "BT.SaaS.DnP.ServiceProfileSyncPortType")]
    public interface ServiceProfileSyncPortType
    {

        // CODEGEN: Generating message contract since the operation manageClientService is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#manageClientService", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        manageClientServiceResponse1 manageClientService(manageClientServiceRequest1 request);

        // CODEGEN: Generating message contract since the operation getClientService is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#getClientService", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        getClientServiceResponse1 getClientService(getClientServiceRequest1 request);

        // CODEGEN: Generating message contract since the operation getServiceSpecification is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#getServiceSpecificat" +
            "ion", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        getServiceSpecificationResponse1 getServiceSpecification(getServiceSpecificationRequest1 request);

        // CODEGEN: Generating message contract since the operation manageServiceInstance is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#manageServiceInstanc" +
            "e", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        manageServiceInstanceResponse1 manageServiceInstance(manageServiceInstanceRequest1 request);

        // CODEGEN: Generating message contract since the operation getServiceInstance is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.nat.bt.com/wsdl/ManageProfile/2007/05/18#getServiceInstance", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Specification))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseResult))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(Identity))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TransactionDetails))]
        getServiceInstanceResponse1 getServiceInstance(getServiceInstanceRequest1 request);
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageClientServiceRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageClientServiceRequest manageClientServiceRequest;

        public manageClientServiceRequest1()
        {
        }

        public manageClientServiceRequest1(ManageClientServiceRequest manageClientServiceRequest)
        {
            this.manageClientServiceRequest = manageClientServiceRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageClientServiceResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageClientServiceResponse manageClientServiceResponse;

        public manageClientServiceResponse1()
        {
        }

        public manageClientServiceResponse1(ManageClientServiceResponse manageClientServiceResponse)
        {
            this.manageClientServiceResponse = manageClientServiceResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getClientServiceRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetClientServiceRequest getClientServiceRequest;

        public getClientServiceRequest1()
        {
        }

        public getClientServiceRequest1(GetClientServiceRequest getClientServiceRequest)
        {
            this.getClientServiceRequest = getClientServiceRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getClientServiceResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetClientServiceResponse getClientServiceResponse;

        public getClientServiceResponse1()
        {
        }

        public getClientServiceResponse1(GetClientServiceResponse getClientServiceResponse)
        {
            this.getClientServiceResponse = getClientServiceResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getServiceSpecificationRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetServiceSpecificationRequest getServiceSpecificationRequest;

        public getServiceSpecificationRequest1()
        {
        }

        public getServiceSpecificationRequest1(GetServiceSpecificationRequest getServiceSpecificationRequest)
        {
            this.getServiceSpecificationRequest = getServiceSpecificationRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getServiceSpecificationResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetServiceSpecificationResponse getServiceSpecificationResponse;

        public getServiceSpecificationResponse1()
        {
        }

        public getServiceSpecificationResponse1(GetServiceSpecificationResponse getServiceSpecificationResponse)
        {
            this.getServiceSpecificationResponse = getServiceSpecificationResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageServiceInstanceRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageServiceInstanceRequest manageServiceInstanceRequest;

        public manageServiceInstanceRequest1()
        {
        }

        public manageServiceInstanceRequest1(ManageServiceInstanceRequest manageServiceInstanceRequest)
        {
            this.manageServiceInstanceRequest = manageServiceInstanceRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class manageServiceInstanceResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public ManageServiceInstanceResponse manageServiceInstanceResponse;

        public manageServiceInstanceResponse1()
        {
        }

        public manageServiceInstanceResponse1(ManageServiceInstanceResponse manageServiceInstanceResponse)
        {
            this.manageServiceInstanceResponse = manageServiceInstanceResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getServiceInstanceRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetServiceInstanceRequest getServiceInstanceRequest;

        public getServiceInstanceRequest1()
        {
        }

        public getServiceInstanceRequest1(GetServiceInstanceRequest getServiceInstanceRequest)
        {
            this.getServiceInstanceRequest = getServiceInstanceRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class getServiceInstanceResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://capabilities.nat.bt.com/xsd/ManageProfile/2007/05/18", Order = 0)]
        public GetServiceInstanceResponse getServiceInstanceResponse;

        public getServiceInstanceResponse1()
        {
        }

        public getServiceInstanceResponse1(GetServiceInstanceResponse getServiceInstanceResponse)
        {
            this.getServiceInstanceResponse = getServiceInstanceResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public interface ServiceProfileSyncPortTypeChannel : ServiceProfileSyncPortType, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public partial class ServiceProfileSyncPortTypeClient : System.ServiceModel.ClientBase<ServiceProfileSyncPortType>, ServiceProfileSyncPortType
    {

        public ServiceProfileSyncPortTypeClient()
        {
        }

        public ServiceProfileSyncPortTypeClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
        }

        public ServiceProfileSyncPortTypeClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public ServiceProfileSyncPortTypeClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public ServiceProfileSyncPortTypeClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        manageClientServiceResponse1 ServiceProfileSyncPortType.manageClientService(manageClientServiceRequest1 request)
        {
            return base.Channel.manageClientService(request);
        }

        public ManageClientServiceResponse manageClientService(ManageClientServiceRequest manageClientServiceRequest)
        {
            manageClientServiceRequest1 inValue = new manageClientServiceRequest1();
            inValue.manageClientServiceRequest = manageClientServiceRequest;
            manageClientServiceResponse1 retVal = ((ServiceProfileSyncPortType)(this)).manageClientService(inValue);
            return retVal.manageClientServiceResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        getClientServiceResponse1 ServiceProfileSyncPortType.getClientService(getClientServiceRequest1 request)
        {
            return base.Channel.getClientService(request);
        }

        public GetClientServiceResponse getClientService(GetClientServiceRequest getClientServiceRequest)
        {
            getClientServiceRequest1 inValue = new getClientServiceRequest1();
            inValue.getClientServiceRequest = getClientServiceRequest;
            getClientServiceResponse1 retVal = ((ServiceProfileSyncPortType)(this)).getClientService(inValue);
            return retVal.getClientServiceResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        getServiceSpecificationResponse1 ServiceProfileSyncPortType.getServiceSpecification(getServiceSpecificationRequest1 request)
        {
            return base.Channel.getServiceSpecification(request);
        }

        public GetServiceSpecificationResponse getServiceSpecification(GetServiceSpecificationRequest getServiceSpecificationRequest)
        {
            getServiceSpecificationRequest1 inValue = new getServiceSpecificationRequest1();
            inValue.getServiceSpecificationRequest = getServiceSpecificationRequest;
            getServiceSpecificationResponse1 retVal = ((ServiceProfileSyncPortType)(this)).getServiceSpecification(inValue);
            return retVal.getServiceSpecificationResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        manageServiceInstanceResponse1 ServiceProfileSyncPortType.manageServiceInstance(manageServiceInstanceRequest1 request)
        {
            return base.Channel.manageServiceInstance(request);
        }

        public ManageServiceInstanceResponse manageServiceInstance(ManageServiceInstanceRequest manageServiceInstanceRequest)
        {
            manageServiceInstanceRequest1 inValue = new manageServiceInstanceRequest1();
            inValue.manageServiceInstanceRequest = manageServiceInstanceRequest;
            manageServiceInstanceResponse1 retVal = ((ServiceProfileSyncPortType)(this)).manageServiceInstance(inValue);
            return retVal.manageServiceInstanceResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        getServiceInstanceResponse1 ServiceProfileSyncPortType.getServiceInstance(getServiceInstanceRequest1 request)
        {
            return base.Channel.getServiceInstance(request);
        }

        public GetServiceInstanceResponse getServiceInstance(GetServiceInstanceRequest getServiceInstanceRequest)
        {
            getServiceInstanceRequest1 inValue = new getServiceInstanceRequest1();
            inValue.getServiceInstanceRequest = getServiceInstanceRequest;
            getServiceInstanceResponse1 retVal = ((ServiceProfileSyncPortType)(this)).getServiceInstance(inValue);
            return retVal.getServiceInstanceResponse;
        }
    }

    //------------------------------------------------------------------------------
    // <auto-generated>
    //     This code was generated by a tool.
    //     Runtime Version:2.0.50727.3053
    //
    //     Changes to this file may cause incorrect behavior and will be lost if
    //     the code is regenerated.
    // </auto-generated>
    //------------------------------------------------------------------------------



    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(Namespace = "http://capabilities.saas.bt.com/wsdl/Identity", ConfigurationName = "ManageIdentityProviderPortType")]
    public interface ManageIdentityProviderPortType
    {

        // CODEGEN: Generating message contract since the operation checkIdentity is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.saas.bt.com/wsdl/Identity#checkIdentity", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        checkIdentityResponse1 checkIdentity(checkIdentityRequest1 request);

        // CODEGEN: Generating message contract since the operation suggestIdentity is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.saas.bt.com/wsdl/Identity#suggestIdentity", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        suggestIdentityResponse1 suggestIdentity(suggestIdentityRequest1 request);

        // CODEGEN: Generating message contract since the operation generatePassword is neither RPC nor document wrapped.
        [System.ServiceModel.OperationContractAttribute(Action = "http://capabilities.saas.bt.com/wsdl/Identity#generatePassword", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        generatePasswordResponse1 generatePassword(generatePasswordRequest1 request);
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    public partial class CheckIdentityRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private Identity identityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public Identity identity
        {
            get
            {
                return this.identityField;
            }
            set
            {
                this.identityField = value;
            }
        }
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    public partial class GeneratePasswordResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private string passwordField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string password
        {
            get
            {
                return this.passwordField;
            }
            set
            {
                this.passwordField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    public partial class GeneratePasswordRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private string domainField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string domain
        {
            get
            {
                return this.domainField;
            }
            set
            {
                this.domainField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    public partial class SuggestIdentityResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private Identity[] identitiesField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 1)]
        [System.Xml.Serialization.XmlArrayItemAttribute("identity", IsNullable = false)]
        public Identity[] identities
        {
            get
            {
                return this.identitiesField;
            }
            set
            {
                this.identitiesField = value;
            }
        }
    }

    /// <remarks/>
    //[System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    //[System.SerializableAttribute()]
    //[System.Diagnostics.DebuggerStepThroughAttribute()]
    //[System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    //public partial class Identity
    //{

    //    private string identifierField;

    //    private string namespaceField;

    //    /// <remarks/>
    //    [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
    //    public string identifier
    //    {
    //        get
    //        {
    //            return this.identifierField;
    //        }
    //        set
    //        {
    //            this.identifierField = value;
    //        }
    //    }

    //    /// <remarks/>
    //    [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
    //    public string @namespace
    //    {
    //        get
    //        {
    //            return this.namespaceField;
    //        }
    //        set
    //        {
    //            this.namespaceField = value;
    //        }
    //    }
    //}

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    public partial class SuggestIdentityRequest
    {

        private StandardHeaderBlock standardHeaderField;

        private string namespaceField;

        private string numberOfSuggestionsField;

        private string[] inputStringsField;

        private string[] domainsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string @namespace
        {
            get
            {
                return this.namespaceField;
            }
            set
            {
                this.namespaceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "integer", Order = 2)]
        public string numberOfSuggestions
        {
            get
            {
                return this.numberOfSuggestionsField;
            }
            set
            {
                this.numberOfSuggestionsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 3)]
        [System.Xml.Serialization.XmlArrayItemAttribute("inputString", IsNullable = false)]
        public string[] inputStrings
        {
            get
            {
                return this.inputStringsField;
            }
            set
            {
                this.inputStringsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 4)]
        [System.Xml.Serialization.XmlArrayItemAttribute("domain", IsNullable = false)]
        public string[] domains
        {
            get
            {
                return this.domainsField;
            }
            set
            {
                this.domainsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.648")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://saas.bt.com/v5")]
    public partial class CheckIdentityResponse
    {

        private StandardHeaderBlock standardHeaderField;

        private bool resultField;

        private bool resultFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://wsi.nat.bt.com/2005/06/StandardHeader/", Order = 0)]
        public StandardHeaderBlock standardHeader
        {
            get
            {
                return this.standardHeaderField;
            }
            set
            {
                this.standardHeaderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public bool result
        {
            get
            {
                return this.resultField;
            }
            set
            {
                this.resultField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool resultSpecified
        {
            get
            {
                return this.resultFieldSpecified;
            }
            set
            {
                this.resultFieldSpecified = value;
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class checkIdentityRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://saas.bt.com/v5", Order = 0)]
        public CheckIdentityRequest checkIdentityRequest;

        public checkIdentityRequest1()
        {
        }

        public checkIdentityRequest1(CheckIdentityRequest checkIdentityRequest)
        {
            this.checkIdentityRequest = checkIdentityRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class checkIdentityResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://saas.bt.com/v5", Order = 0)]
        public CheckIdentityResponse checkIdentityResponse;

        public checkIdentityResponse1()
        {
        }

        public checkIdentityResponse1(CheckIdentityResponse checkIdentityResponse)
        {
            this.checkIdentityResponse = checkIdentityResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class suggestIdentityRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://saas.bt.com/v5", Order = 0)]
        public SuggestIdentityRequest suggestIdentityRequest;

        public suggestIdentityRequest1()
        {
        }

        public suggestIdentityRequest1(SuggestIdentityRequest suggestIdentityRequest)
        {
            this.suggestIdentityRequest = suggestIdentityRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class suggestIdentityResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://saas.bt.com/v5", Order = 0)]
        public SuggestIdentityResponse suggestIdentityResponse;

        public suggestIdentityResponse1()
        {
        }

        public suggestIdentityResponse1(SuggestIdentityResponse suggestIdentityResponse)
        {
            this.suggestIdentityResponse = suggestIdentityResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class generatePasswordRequest1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://saas.bt.com/v5", Order = 0)]
        public GeneratePasswordRequest generatePasswordRequest;

        public generatePasswordRequest1()
        {
        }

        public generatePasswordRequest1(GeneratePasswordRequest generatePasswordRequest)
        {
            this.generatePasswordRequest = generatePasswordRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class generatePasswordResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://saas.bt.com/v5", Order = 0)]
        public GeneratePasswordResponse generatePasswordResponse;

        public generatePasswordResponse1()
        {
        }

        public generatePasswordResponse1(GeneratePasswordResponse generatePasswordResponse)
        {
            this.generatePasswordResponse = generatePasswordResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public interface ManageIdentityProviderPortTypeChannel : ManageIdentityProviderPortType, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public partial class ManageIdentityProviderPortTypeClient : System.ServiceModel.ClientBase<ManageIdentityProviderPortType>, ManageIdentityProviderPortType
    {

        public ManageIdentityProviderPortTypeClient()
        {
        }

        public ManageIdentityProviderPortTypeClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
        }

        public ManageIdentityProviderPortTypeClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public ManageIdentityProviderPortTypeClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public ManageIdentityProviderPortTypeClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        checkIdentityResponse1 ManageIdentityProviderPortType.checkIdentity(checkIdentityRequest1 request)
        {
            return base.Channel.checkIdentity(request);
        }

        public CheckIdentityResponse checkIdentity(CheckIdentityRequest checkIdentityRequest)
        {
            checkIdentityRequest1 inValue = new checkIdentityRequest1();
            inValue.checkIdentityRequest = checkIdentityRequest;
            checkIdentityResponse1 retVal = ((ManageIdentityProviderPortType)(this)).checkIdentity(inValue);
            return retVal.checkIdentityResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        suggestIdentityResponse1 ManageIdentityProviderPortType.suggestIdentity(suggestIdentityRequest1 request)
        {
            return base.Channel.suggestIdentity(request);
        }

        public SuggestIdentityResponse suggestIdentity(SuggestIdentityRequest suggestIdentityRequest)
        {
            suggestIdentityRequest1 inValue = new suggestIdentityRequest1();
            inValue.suggestIdentityRequest = suggestIdentityRequest;
            suggestIdentityResponse1 retVal = ((ManageIdentityProviderPortType)(this)).suggestIdentity(inValue);
            return retVal.suggestIdentityResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        generatePasswordResponse1 ManageIdentityProviderPortType.generatePassword(generatePasswordRequest1 request)
        {
            return base.Channel.generatePassword(request);
        }

        public GeneratePasswordResponse generatePassword(GeneratePasswordRequest generatePasswordRequest)
        {
            generatePasswordRequest1 inValue = new generatePasswordRequest1();
            inValue.generatePasswordRequest = generatePasswordRequest;
            generatePasswordResponse1 retVal = ((ManageIdentityProviderPortType)(this)).generatePassword(inValue);
            return retVal.generatePasswordResponse;
        }
    }
}