﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Xml;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;
using System.Runtime.Serialization;

namespace BT.ISVAdapter.RCOMServiceProvider
{
    public class Helper
    {
        public static string SerializeToXml(object serializeThis, XmlSerializerNamespaces serializerNamespaces)
        {
            StringBuilder serialBuilder = new StringBuilder();
            using (StringWriter serialWriter = new StringWriter(serialBuilder, CultureInfo.InvariantCulture))
            {
                XmlSerializer xmlMessageSerializer = new XmlSerializer(serializeThis.GetType());
                if (null == serializerNamespaces)
                    xmlMessageSerializer.Serialize(serialWriter, serializeThis);
                else
                    xmlMessageSerializer.Serialize(serialWriter, serializeThis, serializerNamespaces);
            }
            return serialBuilder.ToString();
        }
    }


    #region SSOHeader

    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema", IsNullable = false)]
    public class SSOHeader : System.Web.Services.Protocols.SoapHeader
    {
        /// <remarks/>
        public string GUID;

        /// <remarks/>
        public string OrgId;
    }

    #endregion

    #region OrgDetails

    [Serializable]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class OrgDetails
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public responseHeader ResponseHeader;
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string OrganizationId;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PersonDetails RegistrantDetails;

    }
    #endregion

    public class genReturnCode
    {
        public const string Success = "0";
        public const string UnspecifiedError = "5000001";
        public const string DuplicateDomain = "5000002";
        public const string BlacklistedDomain = "5000003";
        public const string InvalidDomainExtension = "5000004";
    }

    #region TxStatus

    /// <summary>
    /// Enum for Transaction Status
    /// </summary>
    public enum TxStatus
    {
        Success,
        Failed,
        TransferOut,
        Expired
    }

    #endregion

    #region RegisterErrorCodes

    public enum RegisterErrorCodes
    {

        /// <summary>
        /// Enumeration for Success
        /// </summary>
        Success = 500050,

        /// <summary>
        ///Enumeration for Failure 
        /// </summary>
        Failure = 500051,
        /// <summary>
        /// Enumeration for Organization Not Present
        /// </summary>
        OrganizationNotPresent = 500052,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        TxIDisNotSupplied = 500053,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        TLDIsNotSupplied = 500054,
        /// <summary>
        /// Enumeration for Invalid Domain Name
        /// </summary>
        DomainNameNotSupplied = 500055,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        DomainStatusNotSupplied = 500056,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        TxStatusNotSupplied = 500057,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        TLDDoesNotExit = 500058,
        /// <summary>
        /// Enumeration for Free Entitlement Not present
        /// </summary>
        FreeEntitlementNotPresent = 500059,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        StatusDoesNotExit = 500060,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        DomainNameDoesNotExit = 500061,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        TxStatusDoesNotExit = 500062,
        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        ProductIDTLDCombitnationDoesNotExit = 500063,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        UnKnownSystemError = 500064,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        TransactionAlreadyCompleted = 500065,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        DomainNameAlreadyPresnt = 500066,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        GuidNotPresent = 500067,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        GuidExpired = 500068,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        InvalidDomainName = 500069,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        DomainNameNotInCorrectFormat = 500080,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        ProductInstanceIdDoesNotExist = 500081,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        ResponseFromVasFailed = 500082,

        /// <summary>
        /// Enumeration for Failure to Update DataBase
        /// </summary>
        DomainStatusNotUpdated = 500083,

        Expired = 500084
    }

    #endregion

    #region ResponseHeader

    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class responseHeader
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string ResultCode;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string ErrorMessage;
    }
    #endregion

    #region PersonalDetails

    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class PersonDetails
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public Person Person;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public Address Address;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public Contact Contact;
    }

    #endregion

    #region Person

    /// <remarks/>
    [Serializable]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class Person
    {
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Title;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string FirstName;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string LastName;

    }
    #endregion

    #region Contact
    /// <remarks/>
    [Serializable]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class Contact
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Email;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Telephone;
    }

    #endregion

    #region Address
    /// <remarks/>
    [Serializable]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class Address
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Address1;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Address2;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Town;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string County;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string PostCode;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Country;
    }
    #endregion

    #region Entitlement
    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class Entitlement
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public TLD TLD;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public int Count;

    }

    #endregion

    #region OrgInfo
    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class OrgInfo
    {

        public responseHeader ResponseHeader;
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string OrgId;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        [System.Xml.Serialization.XmlArrayItemAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = false)]
        public Entitlement[] Entitlements;


    }

    #endregion

    #region UpdateDomainStatusResponse
    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public class updateDomainStatusResponse
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string DomainName;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public responseHeader ResponseHeader;
    }

    #endregion

    #region TLD
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    public enum TLD
    {

        /// <remarks/>
        CC = 1,

        /// <remarks/>
        COM = 2,
    }
    #endregion

    #region SSOStatus
    public enum SSOStatus
    {
        GUID = 0,
        Missing = 1,
        GUIDMissing = 500070,
        OrgIdMissing = 500068,
        GUIDandOrgIdMissing = 500075,
        GUIDExpired = 500071,
        Passed,
        Failed = 500067
    }
    #endregion

    #region TokenObject
    [Serializable]
    public class TokenObject
    {
        private static DataContractSerializer c_serializer =
           new DataContractSerializer(typeof(TokenObject));

        public string organizationId;       
        public string primaryUserId;        
        public Person person;
        public Contact contact;
        public Address address;

        public override string ToString()
        {
            string orderString = null;

            using (StreamReader sr = new StreamReader(new MemoryStream()))
            {
                c_serializer.WriteObject(sr.BaseStream, this);
                sr.BaseStream.Seek(0L, SeekOrigin.Begin);
                orderString = sr.ReadToEnd();
            }
            return orderString;
        }

        public static TokenObject FromString(string orderData)
        {
            TokenObject data;
            StringReader reader = new StringReader(orderData);
            using (XmlReader xr = XmlReader.Create(reader))
            {
                data = (TokenObject)c_serializer.ReadObject(xr);
            }

            return data;
        }
    }
    #endregion

    #region SDPDomainCheckResponse
    [XmlRootAttribute("SDPDomainCheckResponse", IsNullable = false, Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
    [Serializable]
    public class SDPDomainCheckResponse
    {
        #region Data Members

        private ResponseHeader header;
        private string isBlacklisted;
        private string isExisting;

        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public SDPDomainCheckResponse()
        {
            header = new ResponseHeader();
            isBlacklisted = string.Empty;
            isExisting = string.Empty;
        }

        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the ResponseHeader
        /// </summary>
        [XmlElement("responseHeader", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public ResponseHeader Header
        {
            get
            {
                return header;
            }
            set
            {
                header = value;
            }
        }

        /// <summary>
        /// Gets or sets the IsBlacklisted
        /// </summary>
        [XmlElement("isBlacklisted", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string IsBlacklisted
        {
            get
            {
                return isBlacklisted;
            }

            set
            {
                isBlacklisted = value;
            }
        }

        /// <summary>
        /// Gets or sets the IsExisting
        /// </summary>
        [XmlElement("isExisting", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string IsExisting
        {
            get
            {
                return isExisting;
            }

            set
            {
                isExisting = value;
            }
        }
        #endregion
    }

    [Serializable]
    [XmlRootAttribute("Header")]
    public class ResponseHeader
    {
        #region Data Members

        private string pck;
        private string callerId;
        private string genReturnCode;
        private string genReturnText;

        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public ResponseHeader()
        {
            pck = string.Empty;
            callerId = string.Empty;
            genReturnCode = string.Empty;
            genReturnText = string.Empty;
        }

        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the Pck
        /// </summary>
        [XmlElement("pck", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string Pck
        {
            get
            {
                return pck;
            }
            set
            {
                pck = value;
            }
        }

        /// <summary>
        /// Gets or sets the CallerId
        /// </summary>
        [XmlElement("callerId", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string CallerId
        {
            get
            {
                return callerId;
            }

            set
            {
                callerId = value;
            }
        }

        /// <summary>
        /// Gets or sets the GenReturnCode
        /// </summary>
        [XmlElement("genReturnCode", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string GenReturnCode
        {
            get
            {
                return genReturnCode;
            }

            set
            {
                genReturnCode = value;
            }
        }

        /// <summary>
        /// Gets or sets the GenReturnText
        /// </summary>
        [XmlElement("genReturnText", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string GenReturnText
        {
            get
            {
                return genReturnText;
            }

            set
            {
                genReturnText = value;
            }
        }

        #endregion
    }
    #endregion

    #region SDPDomainCheck
    [XmlRootAttribute("SDPDomainCheckRequest", IsNullable = false, Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
    [Serializable]
    public class SDPDomainCheck
    {
        #region Data Members

        private RequestHeader header;
        private string domainName;

        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public SDPDomainCheck()
        {
            header = new RequestHeader();
            domainName = string.Empty;
        }

        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the RequestHeader
        /// </summary>
        [XmlElement("requestHeader", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public RequestHeader Header
        {
            get
            {
                return header;
            }
            set
            {
                header = value;
            }
        }

        /// <summary>
        /// Gets or sets the DomainName
        /// </summary>
        [XmlElement("domainName", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string DomainName
        {
            get
            {
                return domainName;
            }

            set
            {
                domainName = value;
            }
        }

        #endregion 
    }

    [Serializable]
    [XmlRootAttribute("Header")]
    public class RequestHeader
    {
        #region Data Members

        private string pck;
        private string callerId;
        private string callerPassword;

        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public RequestHeader()
        {
            pck = string.Empty;
            callerId = string.Empty;
            callerPassword = string.Empty;
        }

        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the Pck
        /// </summary>
        [XmlElement("pck", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string Pck
        {
            get
            {
                return pck;
            }
            set
            {
                pck = value;
            }
        }

        /// <summary>
        /// Gets or sets the CallerId
        /// </summary>
        [XmlElement("callerId", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string CallerId
        {
            get
            {
                return callerId;
            }

            set
            {
                callerId = value;
            }
        }

        /// <summary>
        /// Gets or sets the CallerPassword
        /// </summary>
        [XmlElement("callerPassword", Namespace = "http://iat.intra.btexact.com/sysdesign/R7.1/ISPSchema")]
        public string CallerPassword
        {
            get
            {
                return callerPassword;
            }

            set
            {
                callerPassword = value;
            }
        }

        #endregion    
    }
    #endregion

    #region DPUser
    /// <summary>
    /// This class is used for LDAP calls to D&P service
    /// - Contians LDAP exposed properties from D&P for User.
    /// </summary>
    public class DPUser
    {
        public string CustomerKey
        {
            get;
            set;
        }

        public string RoleType
        {
            get;
            set;
        }
        public string UserName
        {
            get;
            set;
        }
    }
    #endregion

    #region DPUserList
    /// <summary>
    /// This class is used for LDAP calls to D&P service
    /// - Contains the list of DPUsers
    /// </summary>
    public class DPUserList
    {
        public DPUserList()
        {
            DPUsers = new List<DPUser>();
        }
        public List<DPUser> DPUsers
        {
            get;
            set;
        }
    }
    #endregion

    #region DP_LDAP_Properties
    public class DP_LDAP_Properties
    {
        public const string CRM_CUSTOMER_KEY = "CRM_CUSTOMER_KEY";
        public const string CRM_CONTACT_KEY = "CRM_CONTACT_KEY";
        public const string ROLE_TYPE = "ROLE_TYPE";
        public const string USER_NAME = "cn";
        public const string IDENTIFIERVALUE = "IDENTIFIERVALUE";
    }
    #endregion      

    public enum DomainStatus
    {
        Active = 1,

        Expired = 2,

        Free = 3,

        Paid = 4,

        Suspended = 5,

        TransferOut = 6
    }
}
