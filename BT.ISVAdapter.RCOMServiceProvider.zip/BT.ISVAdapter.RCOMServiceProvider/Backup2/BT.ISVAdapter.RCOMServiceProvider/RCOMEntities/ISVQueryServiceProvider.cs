﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BT.Core.ISVAdapter.ISVService.Entities;

namespace BT.ISVAdapter.RCOMServiceProvider
{
    [ServiceContract(Namespace = @"http://saas.bt.com/ISV/v1", Name = "ISVQueryServiceProvider")]
    public interface ISVQueryServiceProvider
    {
        [OperationContract]
        BT.ISVAdapter.RCOMServiceProvider.QueryOrderResponse Query(QueryOrder order);
    }
}
