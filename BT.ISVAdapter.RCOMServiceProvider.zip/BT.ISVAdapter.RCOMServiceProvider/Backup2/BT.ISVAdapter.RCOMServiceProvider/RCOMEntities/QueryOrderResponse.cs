﻿using System.Runtime.Serialization;
using BT.Core.ISVAdapter.ISVService.Entities;
using System;


namespace BT.ISVAdapter.RCOMServiceProvider
{
    [DataContract(Namespace = @"http://saas.bt.com/v5", Name = "queryOrderResponse")]
    public class QueryOrderResponse
    {
        public QueryOrderResponse()
        {
            this.IsvResponse = new ISVResponse();
        }

        [DataMember(Order = 0, Name = "header", IsRequired = true)]
        public ServiceActionOrderItemHeader Header { get; set; }

        [DataMember(Order = 1, Name = "isvResponse")]
        public ISVResponse IsvResponse { get; set; }

        [DataMember(Order = 2, Name = "healthCheck")]
        public bool checkStatus { get; set; }

        [DataMember(Order = 3, Name = "organizationId")]
        public string OrganizationId { get; set; }

        [DataMember(Order = 4, Name = "GUID")]
        public Guid GUID { get; set; }

        [DataMember(Order = 5, Name = "IsMXRecordPresent")]
        public bool IsMXRecordPresent { get; set; }

        [DataMember(Order = 6, Name = "ExternalDomainOrderKey")]
        public string ExternalDomainOrderKey { get; set; }

        [DataMember(Order = 7, Name = "BlackListedDomain")]
        public string BlackListedDomain { get; set; }

    }
}
