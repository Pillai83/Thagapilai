﻿
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Serialization;

namespace BT.ISVAdapter.RCOMServiceProvider
{
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(Namespace = "https://tempuri.org/", ConfigurationName = "DMCWebServiceSoap")]
    public interface DMCWebServiceSoap : IDisposable
    {

        [System.ServiceModel.OperationContractAttribute(Action = "https://tempuri.org/transferDomain", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        transferDomainResponse transferDomain(transferDomainRequest req);

        [System.ServiceModel.OperationContractAttribute(Action = "https://tempuri.org/purchaseDomain", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        purchaseDomainResp purchaseDomain(purchaseDomainReq req);

        [System.ServiceModel.OperationContractAttribute(Action = "https://tempuri.org/changeFreeStatus", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        changeFreeStatusResp changeFreeStatus(changeFreeStatusReq req);

        [System.ServiceModel.OperationContractAttribute(Action = "https://tempuri.org/setFreeStatus", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        changeFreeStatusResp setFreeStatus(changeFreeStatusReq req);

        [System.ServiceModel.OperationContractAttribute(Action = "https://tempuri.org/updateZoneConfig", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        updateZoneConfigResp updateZoneConfig(updateZoneConfigReq req);

        [System.ServiceModel.OperationContractAttribute(Action = "https://tempuri.org/checkStatus", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        bool checkStatus();
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class transferDomainRequest
    {

        private AccountInfo accountInfoField;

        private domainInfo domainField;

        private bool freeField;

        private string confirmEmailField;

        private string authCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public AccountInfo accountInfo
        {
            get
            {
                return this.accountInfoField;
            }
            set
            {
                this.accountInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public domainInfo domain
        {
            get
            {
                return this.domainField;
            }
            set
            {
                this.domainField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public bool free
        {
            get
            {
                return this.freeField;
            }
            set
            {
                this.freeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string confirmEmail
        {
            get
            {
                return this.confirmEmailField;
            }
            set
            {
                this.confirmEmailField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public string authCode
        {
            get
            {
                return this.authCodeField;
            }
            set
            {
                this.authCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class AccountInfo
    {

        private string bTUsernameField;

        private string bTPasswordField;

        private string accountNumberField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string BTUsername
        {
            get
            {
                return this.bTUsernameField;
            }
            set
            {
                this.bTUsernameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string BTPassword
        {
            get
            {
                return this.bTPasswordField;
            }
            set
            {
                this.bTPasswordField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string accountNumber
        {
            get
            {
                return this.accountNumberField;
            }
            set
            {
                this.accountNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class updateZoneConfigResp
    {

        private domainInfo dInfoField;

        private int errCountField;

        private int errCodeField;

        private string errDescriptionField;

        private zoneUpdateStatus statusField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public domainInfo dInfo
        {
            get
            {
                return this.dInfoField;
            }
            set
            {
                this.dInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public int errCount
        {
            get
            {
                return this.errCountField;
            }
            set
            {
                this.errCountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public int errCode
        {
            get
            {
                return this.errCodeField;
            }
            set
            {
                this.errCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string errDescription
        {
            get
            {
                return this.errDescriptionField;
            }
            set
            {
                this.errDescriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public zoneUpdateStatus status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class domainInfo
    {

        private string sldField;

        private string tldField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string sld
        {
            get
            {
                return this.sldField;
            }
            set
            {
                this.sldField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string tld
        {
            get
            {
                return this.tldField;
            }
            set
            {
                this.tldField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public enum zoneUpdateStatus
    {

        /// <remarks/>
        SUCCESS,

        /// <remarks/>
        FAILURE,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class updateZoneConfigReq
    {

        private AccountInfo aInfoField;

        private domainInfo dInfoField;

        private RecordTypes recordTypeField;

        private string recordKeyField;

        private string recordValueField;

        private int recordPriorityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public AccountInfo aInfo
        {
            get
            {
                return this.aInfoField;
            }
            set
            {
                this.aInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public domainInfo dInfo
        {
            get
            {
                return this.dInfoField;
            }
            set
            {
                this.dInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public RecordTypes recordType
        {
            get
            {
                return this.recordTypeField;
            }
            set
            {
                this.recordTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string recordKey
        {
            get
            {
                return this.recordKeyField;
            }
            set
            {
                this.recordKeyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public string recordValue
        {
            get
            {
                return this.recordValueField;
            }
            set
            {
                this.recordValueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public int recordPriority
        {
            get
            {
                return this.recordPriorityField;
            }
            set
            {
                this.recordPriorityField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public enum RecordTypes
    {

        /// <remarks/>
        A,

        /// <remarks/>
        CNAME,

        /// <remarks/>
        MX,

        /// <remarks/>
        URL,

        /// <remarks/>
        FRAME,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class changeFreeStatusResp
    {

        private domainResp[] domainRespField;

        private overallStatus overallResponseField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 0)]
        public domainResp[] DomainResp
        {
            get
            {
                return this.domainRespField;
            }
            set
            {
                this.domainRespField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public overallStatus OverallResponse
        {
            get
            {
                return this.overallResponseField;
            }
            set
            {
                this.overallResponseField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class domainResp
    {

        private string sLDField;

        private string tLDField;

        private int errCountField;

        private int errCodeField;

        private string errDescriptionField;

        private domainStatus statusField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string SLD
        {
            get
            {
                return this.sLDField;
            }
            set
            {
                this.sLDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string TLD
        {
            get
            {
                return this.tLDField;
            }
            set
            {
                this.tLDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public int errCount
        {
            get
            {
                return this.errCountField;
            }
            set
            {
                this.errCountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public int errCode
        {
            get
            {
                return this.errCodeField;
            }
            set
            {
                this.errCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public string errDescription
        {
            get
            {
                return this.errDescriptionField;
            }
            set
            {
                this.errDescriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public domainStatus status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public enum domainStatus
    {

        /// <remarks/>
        SUCCESS,

        /// <remarks/>
        FAILURE,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public enum overallStatus
    {

        /// <remarks/>
        SUCCESS,

        /// <remarks/>
        FAILURE,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class changeFreeStatusReq
    {

        private AccountInfo aInfoField;

        private string[] sLDField;

        private string[] tLDField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public AccountInfo aInfo
        {
            get
            {
                return this.aInfoField;
            }
            set
            {
                this.aInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 1)]
        public string[] SLD
        {
            get
            {
                return this.sLDField;
            }
            set
            {
                this.sLDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 2)]
        public string[] TLD
        {
            get
            {
                return this.tLDField;
            }
            set
            {
                this.tLDField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class purchaseDomainResp
    {

        private domainResp domainRespField;

        private string orderIDField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public domainResp domainResp
        {
            get
            {
                return this.domainRespField;
            }
            set
            {
                this.domainRespField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string orderID
        {
            get
            {
                return this.orderIDField;
            }
            set
            {
                this.orderIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class contact
    {

        private string firstnameField;

        private string lastnameField;

        private string orgnameField;

        private string addr1Field;

        private string addr2Field;

        private string townField;

        private string countyField;

        private string postcodeField;

        private string countryField;

        private string emailField;

        private string phoneField;

        private string faxField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public string firstname
        {
            get
            {
                return this.firstnameField;
            }
            set
            {
                this.firstnameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string lastname
        {
            get
            {
                return this.lastnameField;
            }
            set
            {
                this.lastnameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string orgname
        {
            get
            {
                return this.orgnameField;
            }
            set
            {
                this.orgnameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public string addr1
        {
            get
            {
                return this.addr1Field;
            }
            set
            {
                this.addr1Field = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public string addr2
        {
            get
            {
                return this.addr2Field;
            }
            set
            {
                this.addr2Field = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public string town
        {
            get
            {
                return this.townField;
            }
            set
            {
                this.townField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 6)]
        public string county
        {
            get
            {
                return this.countyField;
            }
            set
            {
                this.countyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 7)]
        public string postcode
        {
            get
            {
                return this.postcodeField;
            }
            set
            {
                this.postcodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 8)]
        public string country
        {
            get
            {
                return this.countryField;
            }
            set
            {
                this.countryField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 9)]
        public string email
        {
            get
            {
                return this.emailField;
            }
            set
            {
                this.emailField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 10)]
        public string phone
        {
            get
            {
                return this.phoneField;
            }
            set
            {
                this.phoneField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 11)]
        public string fax
        {
            get
            {
                return this.faxField;
            }
            set
            {
                this.faxField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class purchaseDomainReq
    {

        private int termField;

        private bool freeField;

        private string confirmEmailField;

        private contact registrantField;

        private contact adminField;

        private AccountInfo accountInfoField;

        private domainInfo domainField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public int term
        {
            get
            {
                return this.termField;
            }
            set
            {
                this.termField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public bool free
        {
            get
            {
                return this.freeField;
            }
            set
            {
                this.freeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public string confirmEmail
        {
            get
            {
                return this.confirmEmailField;
            }
            set
            {
                this.confirmEmailField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public contact Registrant
        {
            get
            {
                return this.registrantField;
            }
            set
            {
                this.registrantField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public contact Admin
        {
            get
            {
                return this.adminField;
            }
            set
            {
                this.adminField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 5)]
        public AccountInfo accountInfo
        {
            get
            {
                return this.accountInfoField;
            }
            set
            {
                this.accountInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 6)]
        public domainInfo domain
        {
            get
            {
                return this.domainField;
            }
            set
            {
                this.domainField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("svcutil", "3.0.4506.2152")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "https://tempuri.org/")]
    public partial class transferDomainResponse
    {

        private domainResp domainRespField;

        private string trackingIDField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public domainResp domainResp
        {
            get
            {
                return this.domainRespField;
            }
            set
            {
                this.domainRespField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public string trackingID
        {
            get
            {
                return this.trackingIDField;
            }
            set
            {
                this.trackingIDField = value;
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public interface DMCWebServiceSoapChannel : DMCWebServiceSoap, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public partial class DMCWebServiceSoapClient : System.ServiceModel.ClientBase<DMCWebServiceSoap>, DMCWebServiceSoap
    {

        public DMCWebServiceSoapClient()
        {
        }

        public DMCWebServiceSoapClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
        }

        public DMCWebServiceSoapClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public DMCWebServiceSoapClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public DMCWebServiceSoapClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        public transferDomainResponse transferDomain(transferDomainRequest req)
        {
            return base.Channel.transferDomain(req);
        }

        public purchaseDomainResp purchaseDomain(purchaseDomainReq req)
        {
            return base.Channel.purchaseDomain(req);
        }

        public changeFreeStatusResp changeFreeStatus(changeFreeStatusReq req)
        {
            return base.Channel.changeFreeStatus(req);
        }

        public changeFreeStatusResp setFreeStatus(changeFreeStatusReq req)
        {
            return base.Channel.setFreeStatus(req);
        }

        public updateZoneConfigResp updateZoneConfig(updateZoneConfigReq req)
        {
            return base.Channel.updateZoneConfig(req);
        }

        public bool checkStatus()
        {
            return base.Channel.checkStatus();
        }
    }
}