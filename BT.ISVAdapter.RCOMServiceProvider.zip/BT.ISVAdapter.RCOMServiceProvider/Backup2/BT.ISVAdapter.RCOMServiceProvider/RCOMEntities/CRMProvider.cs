﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.ServiceModel;
using System.ServiceModel.Channels;
using BT.SaaS.CRM.Common;

namespace BT.ISVAdapter.RCOMServiceProvider.RCOMEntities
{
    public class CRMProvider
    {
        private Binding binding = null;
        private EndpointAddress epAddress = null;

        public CRMProvider()
        {
            string endPoint = ConfigurationManager.AppSettings["CRMUrl"];
            binding = GetHTTPBinding();
            epAddress = new EndpointAddress(endPoint);
        }

        private BasicHttpBinding GetHTTPBinding()
        {
            BasicHttpBinding binding = new BasicHttpBinding();
            binding.Name = "crmHttpBinding";
            binding.MaxReceivedMessageSize = Convert.ToInt32(ConfigurationSettings.AppSettings["CRMMaxReceivedMessageSize"].ToString()); //9553600
            String[] timeOut = ConfigurationSettings.AppSettings["CRMSendTimeout"].ToString().Split(',');

            binding.SendTimeout =
                new TimeSpan(Convert.ToInt32(timeOut[0].Trim()), Convert.ToInt32(timeOut[1].Trim()), Convert.ToInt32(timeOut[2].Trim()));
            return binding;
        }

        private getCustomerResponse1 GetCustomer(string customerId)
        {
            getCustomerResponse1 response;
            getCustomer custRequest = new getCustomer(new GetCustomerRequest() { customerKey = customerId, standardHeader = new StandardHeaderBlock() });
            
            using (ChannelFactory<IManageCRMProviderPortType> factory = new ChannelFactory<IManageCRMProviderPortType>(binding, epAddress))
            {
                IManageCRMProviderPortType svc = factory.CreateChannel();
                response = svc.getCustomer(custRequest);
            }
            return response;
        }

        public bool CheckIsUKBCustomer(string customerId)
        {
            getCustomerResponse1 response = null;

            // c2b call to get customer status
            try
            {
                response = GetCustomer(customerId);
            }
            catch (Exception) // in case of any exceptions (framework), then consider it as BCP one
            {
                return false;
            }

            // once got response, do basic checks
            if (response != null && response.getCustomerResponse != null && response.getCustomerResponse.customer != null
                && !string.IsNullOrEmpty(response.getCustomerResponse.customer.customerStatus))
            {
                // If data is correct, then check for Prefix. If prefix found, then UKB else BCP one.
                string custStatus = response.getCustomerResponse.customer.customerStatus.ToUpper();
                if (custStatus.StartsWith("UM-") || custStatus.StartsWith("MC-"))
                    return true;
                else
                    return false;
            }
            else
            {
                // If there are no exceptions, but data is not found on c2b, then consider it as UKB one
                return true;
            }
        }
    }    
}
