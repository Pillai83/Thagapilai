﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Oracle.DataAccess.Client;
using System.Data;

public class C2BHelper
{
    public static string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["OracleProvider"].ConnectionString;

    public static string CheckIsExternalDomainInC2B(string Orgid, string Domainname)
    {
        string hosted = string.Empty;
        string ext_hosted = string.Empty;
        string domintype = string.Empty;
        OracleConnection connection = null;
        try
        {
            using (connection = new OracleConnection(connectionString))
            {
                OracleCommand command = connection.CreateCommand();
                command.CommandText = string.Format("select ext_hosted,hosted from domain where orgid = '{0}' and name='{1}' order by name", Orgid, Domainname);

                connection.Open();
                using (
                    OracleDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        hosted = reader["hosted"] != null ? (!string.IsNullOrEmpty(reader["hosted"].ToString()) ? reader["hosted"].ToString() : string.Empty) : string.Empty;
                        ext_hosted = reader["ext_hosted"] != null ? (!string.IsNullOrEmpty(reader["ext_hosted"].ToString()) ? reader["ext_hosted"].ToString() : string.Empty) : string.Empty;
                    }
                    reader.Close();
                }
                connection.Close();
            }
            if (!string.IsNullOrEmpty(hosted))
            {
                if (hosted.ToUpper() == "F" && string.IsNullOrEmpty(ext_hosted))
                {
                    return domintype = "External";
                }
                else
                {
                    return domintype="Internal";
                }
            }
        }
        catch (Exception)
        {
            if (connection != null && connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }
        return domintype="Notfound";
    }
}

