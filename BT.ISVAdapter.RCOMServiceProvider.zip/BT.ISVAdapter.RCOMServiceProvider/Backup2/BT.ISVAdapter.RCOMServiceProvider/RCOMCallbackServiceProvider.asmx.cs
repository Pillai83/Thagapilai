﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using BT.SaaS.Core.Shared.Entities;
using BT.Core.ISVAdapter.ISVService;
using System.ServiceModel;
using BT.SaaS.Core.Shared.ErrorManagement;
using System.Threading;
using BT.SaaS.TokenManager;
using BT.ISVAdapter.RCOMServiceProvider.RCOMEntities;


namespace BT.ISVAdapter.RCOMServiceProvider
{
    [SaaSGlobalErrorHandler]
    [System.Web.Services.WebServiceBindingAttribute(Name = "SDPPartnerBinding", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    [WebService(Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
    [Serializable]
    public class RCOMCallbackServiceProvider : System.Web.Services.WebService
    {
        public int transferInState = 1;
        public int pendingState = 0;
        public int intermediateState = 3;
        public int transactionFailedState = 4;
        public int completedState = 2;
        public SSOHeader SSO;

        #region NotifyDomainOrderStart
        [SoapHeader("SSO")]
        [System.Web.Services.WebMethodAttribute()]

        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://sdp-partner-services-api/v1.1.0.0/notifyDomainOrderStart", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("responseHeader", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
        public responseHeader notifyDomainOrderStart([System.Xml.Serialization.XmlElementAttribute("notifyDomainOrderStart", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
            string orgId, string txId, string tld, bool isFree)
        {
            SSOStatus ssoValidationResult;
            responseHeader resHeader = new responseHeader();
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Got a NotifyDomainOrderStart for " + " orgId: " + orgId + " tld: " + tld + " txId: " + txId + " isFree: " + isFree);
            try
            {
                // check whether it is BCP org or UKB org. If it is UKB org, do UKB cal else BCP logic will be BAU.
                if (CheckIsUKBOrg(orgId))
                {
                    // populate UKB request attributes
                    var ukbRequest = new notifyDomainOrderStartRequest();
                    ukbRequest.SSOHeader = new BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.SSOHeader();
                    ukbRequest.SSOHeader.GUID = SSO.GUID;
                    ukbRequest.SSOHeader.OrgId = SSO.OrgId;
                    ukbRequest.isFree = isFree;
                    ukbRequest.tld = tld;
                    ukbRequest.txId = txId;
                    ukbRequest.notifyDomainOrderStart = orgId;

                    // do UKB call (i.e., calling UKB endpoint)
                    using (ChannelFactory<RCOMCallbackServiceProviderSoap> factory = new ChannelFactory<RCOMCallbackServiceProviderSoap>(@"UKBRCOMCallbackServiceProviderSoap"))
                    {
                        RCOMCallbackServiceProviderSoap svc = factory.CreateChannel();
                        var ukbResp = svc.notifyDomainOrderStart(ukbRequest);

                        // if we got responseHeader from UKB, then redirect the same to RCOM, else send default failure code to RCOM.
                        if (ukbResp != null && ukbResp.responseHeader != null)
                        {
                            resHeader.ErrorMessage = ukbResp.responseHeader.ErrorMessage;
                            resHeader.ResultCode = ukbResp.responseHeader.ResultCode;
                        }
                        else
                        {
                            // UKB call failed, so send failure response to RCOM
                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                            resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                        }
                    }
                }
                else // do normal BCP call as BAU
                {
                    RequestProcessor reqProcess = new RequestProcessor();
                    ssoValidationResult = reqProcess.IsHeaderValid(SSO, orgId);
                    if (ssoValidationResult == SSOStatus.Passed || ssoValidationResult == SSOStatus.Missing)
                    {
                        bool defaultResponse = reqProcess.CheckOrganizationId(orgId, tld);
                        if (defaultResponse || !isFree)
                        {
                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                            resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                               ("VAS Adapters - RCOM: count = 0 Sending default positive response back for NotifyDomainOrderStart for " + " orgId: " + orgId + " tld: " + tld + " txId: " + txId + " isFree: " + isFree);
                        }
                        else
                        {
                            int result = reqProcess.UpdateTxIdinDnP(orgId, txId, tld);
                            if (result == 0)
                            {
                                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                   ("VAS Adapters - RCOM: Sending positive response back for NotifyDomainOrderStart for " + " orgId: " + orgId + " tld: " + tld + " txId: " + txId + " isFree: " + isFree);
                            }
                            else
                            {
                                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                                resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                   ("VAS Adapters - RCOM: Sending failure response back for NotifyDomainOrderStart for " + " orgId: " + orgId + " tld: " + tld + " txId: " + txId + " isFree: " + isFree);
                            }
                        }
                    }
                    else
                    {
                        resHeader = reqProcess.GetSSOFailedResponse(ssoValidationResult);
                    }
                }
            }
            catch (Exception ex)
            {
                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                               ("VAS Adapters - RCOM: count = 0 Sending failure response back for NotifyDomainOrderStart for " + " orgId: " + orgId + " tld: " + tld + " txId: " + txId + " isFree: " + isFree + ex.Message);
            }

            return resHeader;
        }

        #endregion

        
        #region NotifyDomainOrderComplete

        [SoapHeader("SSO")]
        [System.Web.Services.WebMethodAttribute()]
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://sdp-partner-services-api/v1.1.0.0/notifyDomainOrderComplete", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("responseHeader", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
        public responseHeader notifyDomainOrderComplete([System.Xml.Serialization.XmlElementAttribute("notifyDomainOrderComplete", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")] 
            string organizationId, string txId, string txStatus, string domainName, bool isFree)
        {
            TxStatus eTxStatus = TxStatus.Failed;
            SSOStatus ssoValidationResult;
            responseHeader resHeader = new responseHeader();
            RequestProcessor reqProcessor = new RequestProcessor();          
            int stateId;
            OrderResponse response = null;
            DateTime dateTime;
            string correlationData, data = null;
            try
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Got a NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);

                // check whether it is BCP org or UKB org. If it is UKB org, do UKB cal else BCP logic will be BAU.
                if (CheckIsUKBOrg(organizationId))
                {
                    // populate UKB request attributes
                    var ukbRequest = new notifyDomainOrderCompleteRequest();
                    ukbRequest.SSOHeader = new BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.SSOHeader();
                    ukbRequest.SSOHeader.GUID = SSO.GUID;
                    ukbRequest.SSOHeader.OrgId = SSO.OrgId;
                    ukbRequest.isFree = isFree;
                    ukbRequest.domainName = domainName;
                    ukbRequest.txId = txId;
                    ukbRequest.notifyDomainOrderComplete = organizationId;
                    ukbRequest.txStatus = txStatus;

                    // do UKB call (i.e., calling UKB endpoint)
                    using (ChannelFactory<RCOMCallbackServiceProviderSoap> factory = new ChannelFactory<RCOMCallbackServiceProviderSoap>(@"UKBRCOMCallbackServiceProviderSoap"))
                    {
                        RCOMCallbackServiceProviderSoap svc = factory.CreateChannel();
                        var ukbResp = svc.notifyDomainOrderComplete(ukbRequest);

                        // if we got responseHeader from UKB, then redirect the same to RCOM, else send default failure code to RCOM.
                        if (ukbResp != null && ukbResp.responseHeader != null)
                        {
                            resHeader.ErrorMessage = ukbResp.responseHeader.ErrorMessage;
                            resHeader.ResultCode = ukbResp.responseHeader.ResultCode;
                        }
                        else
                        {
                            // UKB call failed, so send failure response to RCOM
                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                            resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                        }
                    }
                }
                else // do normal BCP call as BAU
                {
                    try
                    {
                        if (string.IsNullOrEmpty(txStatus))
                        {
                            resHeader = new responseHeader();
                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.TxIDisNotSupplied)).ToString();
                            resHeader.ErrorMessage = RegisterErrorCodes.TxIDisNotSupplied.ToString();
                        }
                        else
                        {
                            eTxStatus = (TxStatus)Enum.Parse(typeof(TxStatus), txStatus, true);
                        }
                    }
                    catch (Exception ex)
                    {
                        resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.TxStatusDoesNotExit)).ToString();
                        resHeader.ErrorMessage = RegisterErrorCodes.TxStatusDoesNotExit.ToString();
                    }
                    ssoValidationResult = reqProcessor.IsHeaderValid(SSO, organizationId);


                    if (ssoValidationResult == SSOStatus.Passed || ssoValidationResult == SSOStatus.Missing)
                    {
                        bool isPresent = reqProcessor.GetDataFromDomains(domainName, out stateId, out dateTime, out correlationData);
                        if (eTxStatus == TxStatus.Success)
                        {
                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                               ("VAS Adapters - RCOM: SSO Header validated for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);

                            data = "SSO Header: " + Helper.SerializeToXml(SSO, null) + " Call back xml values: " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree;
                            //bool isPresent = reqProcessor.GetDataFromDomains(domainName, out stateId, out dateTime, out correlationData);
                            if (!isPresent || (isPresent && stateId == pendingState))
                            {
                                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                               ("VAS Adapters - RCOM: Domain is not present...NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);
                                if (!isPresent)
                                {
                                    reqProcessor.InsertDomainRequest(domainName, pendingState, data, txId, organizationId);
                                }

                                bool isExternalDomainPresent = reqProcessor.GetDataFromExternalDomains(domainName);
                                if (isExternalDomainPresent)
                                {

                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                              ("VAS Adapters - RCOM: ExternalDomain is present...NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);

                                    Guid serviceInstanceIdForTxnId = Guid.Empty;
                                    Guid serviceInstanceIdForTxnDomain = Guid.Empty;
                                    IdentityCredential credential = new IdentityCredential();

                                    RequestProcessor processor = new RequestProcessor();
                                    string primaryUser = processor.GetPrimaryUserFromDnP(organizationId);
                                    serviceInstanceIdForTxnDomain = reqProcessor.GetServiceInstanceIdFromTxnIdAndDomain(domainName, primaryUser, false, txId);

                                    if (isFree)
                                    {
                                        serviceInstanceIdForTxnId = reqProcessor.GetServiceInstanceIdFromTxnIdAndDomain(domainName, primaryUser, true, txId);
                                        int resultTxnId = reqProcessor.UpdateTxIdAndDomainInDnP(serviceInstanceIdForTxnId, domainName, organizationId, primaryUser, true);

                                        int resultDomainId = -1;

                                        //TODO: need to inactivate the External domain service instance.

                                        resultDomainId = reqProcessor.ActivateDeactivateServiceInstance(serviceInstanceIdForTxnDomain.ToString());

                                        if (resultTxnId == 0 && resultDomainId == 0)
                                        {
                                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                            resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                               ("VAS Adapters - RCOM: Sending positive response back for NotifyDomainOrderComplete for " + " orgId: " + organizationId + " txId: " + txId + " isFree: " + isFree);
                                        }
                                        else
                                        {
                                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                                            resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                               ("VAS Adapters - RCOM: Sending failure response back for NotifyDomainOrderComplete for " + " orgId: " + organizationId + " txId: " + txId + " isFree: " + isFree);
                                        }

                                    }
                                    else
                                    {
                                        //to do
                                        // Need to update product code in MDM from pre-Domain to paid Domain.
                                        int resultNotFree = reqProcessor.UpdateTxIdinDnPNotFree(organizationId, domainName, serviceInstanceIdForTxnDomain, primaryUser);
                                        if (resultNotFree == 0)
                                        {
                                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                            resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                               ("VAS Adapters - RCOM: Sending positive response back for NotifyDomainOrderComplete for " + " orgId: " + organizationId + " txId: " + txId + " isFree: " + isFree);
                                        }
                                        else
                                        {
                                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                                            resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                               ("VAS Adapters - RCOM: Sending failure response back for NotifyDomainOrderComplete for " + " orgId: " + organizationId + " txId: " + txId + " isFree: " + isFree);
                                        }


                                    }

                                }
                                else
                                {
                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: ExternalDomain is not present...NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);

                                    response = reqProcessor.PostToPE(organizationId, isPresent, isFree, domainName, txId);
                                }

                                if (response.result.errorCode == "000000")
                                {
                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                        ("VAS Adapters - RCOM: Got a positive response from PE..woohooo!!!");
                                    reqProcessor.InsertDomainRequest(domainName, completedState, data, txId, organizationId);
                                    resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                    resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                            ("VAS Adapters - RCOM:Sending positive response for NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);
                                }
                                else
                                {
                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                    ("VAS Adapters - RCOM: CRAP!! Got a failure response from PE!!" + response.result.errorDescription);

                                    throw new Exception("VAS Adapters - PE call failed for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree + " error: " + response.result.errorDescription);
                                }
                            }
                            else if (isPresent && stateId == transferInState)
                            {
                                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                               ("VAS Adapters - RCOM: Doman is pressent and in pending state....NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);
                                reqProcessor.GetAndPostToPE(organizationId, domainName, correlationData);
                                if (response.result.errorCode == "000000")
                                {
                                    reqProcessor.UpdateStateId(domainName, completedState, correlationData + data);
                                    resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                    resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                            ("VAS Adapters - RCOM:Sending positive response for NotifyDomainOrderComplete for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree);
                                }
                                else
                                {
                                    reqProcessor.UpdateStateId(domainName, transferInState, data);
                                    BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                    ("VAS Adapters - RCOM: CRAP!! Got a failure response from PE!!" + response.result.errorDescription);

                                    throw new Exception("VAS Adapters- RCOM - PE call failed for " + " orgId: " + organizationId + " domainName: " + domainName + " transactionStatus: " + txStatus + " txId: " + txId + " isFree: " + isFree + " error: " + response.result.errorDescription);
                                }
                            }
                            else if (isPresent && (stateId == completedState || stateId == intermediateState))
                            {
                                resHeader = new responseHeader();
                                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                            }
                            else
                            {
                                resHeader = new responseHeader();
                                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                                resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                            }
                        }
                        else
                        {
                            //reqProcessor.InsertDomainRequest(domainName, transactionFailedState, data, txId, organizationId);
                            resHeader = new responseHeader();
                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                            resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                        }
                    }
                    else
                    {
                        resHeader = reqProcessor.GetSSOFailedResponse(ssoValidationResult);
                    }
                }
            }
            catch (Exception ex)
            {
                resHeader = new responseHeader();
                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                resHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
            }
            return resHeader;
        }

        #endregion

        #region GetOrgDetails
        /// <summary>
        /// This method is Called to get the Primary users details.
        /// </summary>
        /// <param name="getOrganisationDetails"></param>
        /// <returns></returns>
        [SoapHeader("SSO")]
        [System.Web.Services.WebMethodAttribute()]
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://sdp-partner-services-api/v1.1.0.0/getOrgDetails", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("OrgDetails", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
        public OrgDetails getOrgDetails([System.Xml.Serialization.XmlElementAttribute("getOrgDetails", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")] string organizationId)
        {
            responseHeader resHeader = new responseHeader();
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                    ("VAS Adapters - RCOM:Got a GetOrgDetails for " + " orgId: " + organizationId);
            OrgDetails orgDetails = new OrgDetails();
            try
            {
                // check whether it is BCP org or UKB org. If it is UKB org, do UKB cal else BCP logic will be BAU.
                if (CheckIsUKBOrg(organizationId))
                {
                    // populate UKB request attributes
                    getOrgDetailsResponse ukbResp = null;
                    var ukbRequest = new getOrgDetailsRequest();
                    ukbRequest.SSOHeader = new BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.SSOHeader();
                    ukbRequest.SSOHeader.GUID = SSO.GUID;
                    ukbRequest.SSOHeader.OrgId = SSO.OrgId;
                    ukbRequest.getOrgDetails = organizationId;

                    // do UKB call (i.e., calling UKB endpoint)
                    using (ChannelFactory<RCOMCallbackServiceProviderSoap> factory = new ChannelFactory<RCOMCallbackServiceProviderSoap>(@"UKBRCOMCallbackServiceProviderSoap"))
                    {
                        RCOMCallbackServiceProviderSoap svc = factory.CreateChannel();
                        ukbResp = svc.getOrgDetails(ukbRequest);
                    }
                    // if we got responseHeader from UKB, then redirect the same to RCOM, else send default failure code to RCOM.
                    if (ukbResp != null && ukbResp.OrgDetails != null)
                    {
                        orgDetails.OrganizationId = ukbResp.OrgDetails.OrganizationId;
                        if (ukbResp.OrgDetails.RegistrantDetails != null)
                        {
                            var registrantDetails = ukbResp.OrgDetails.RegistrantDetails;
                            orgDetails.RegistrantDetails = new PersonDetails();

                            // fill Address object
                            orgDetails.RegistrantDetails.Address = new Address();
                            orgDetails.RegistrantDetails.Address.Address1 = registrantDetails.Address.Address1;
                            orgDetails.RegistrantDetails.Address.Address2 = registrantDetails.Address.Address2;
                            orgDetails.RegistrantDetails.Address.Country = registrantDetails.Address.Country;
                            orgDetails.RegistrantDetails.Address.County = registrantDetails.Address.County;
                            orgDetails.RegistrantDetails.Address.PostCode = registrantDetails.Address.PostCode;
                            orgDetails.RegistrantDetails.Address.Town = registrantDetails.Address.Town;

                            // fill Contact object
                            orgDetails.RegistrantDetails.Contact = new Contact();
                            orgDetails.RegistrantDetails.Contact.Email = registrantDetails.Contact.Email;
                            orgDetails.RegistrantDetails.Contact.Telephone = registrantDetails.Contact.Telephone;

                            // fill Person object
                            orgDetails.RegistrantDetails.Person = new Person();
                            orgDetails.RegistrantDetails.Person.FirstName = registrantDetails.Person.FirstName;
                            orgDetails.RegistrantDetails.Person.LastName = registrantDetails.Person.LastName;
                            orgDetails.RegistrantDetails.Person.Title = registrantDetails.Person.Title;
                        }
                        orgDetails.ResponseHeader = new responseHeader();
                        orgDetails.ResponseHeader.ErrorMessage = ukbResp.OrgDetails.ResponseHeader.ErrorMessage;
                        orgDetails.ResponseHeader.ResultCode = ukbResp.OrgDetails.ResponseHeader.ResultCode;
                    }
                    else
                    {
                        // UKB call failed, so send failure response to RCOM
                        orgDetails.ResponseHeader = new responseHeader();
                        orgDetails.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                        orgDetails.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                    }
                }
                else // do BCP call as it is BAU
                {
                    RequestProcessor processor = new RequestProcessor();
                    processor.IsHeaderValid(SSO, organizationId);
                    TokenResponse cacheObject = processor.GetTokenData(organizationId, SSO.GUID);
                    if (cacheObject != null)
                    {
                        if (cacheObject.tokenResults[0].tokenId.ToString().Equals(SSO.GUID))
                        {
                            if (!cacheObject.tokenResults[0].IsExpired)
                            {
                                TokenObject obj = TokenObject.FromString(cacheObject.tokenResults[0].data);
                                orgDetails = processor.MapOrganizationDetails(obj, orgDetails);
                                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.Success)).ToString();
                                resHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                processor.ExpireToken(organizationId, SSO.GUID);
                            }
                            else
                            {
                                orgDetails.OrganizationId = organizationId;
                                resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.GuidExpired)).ToString();
                                resHeader.ErrorMessage = RegisterErrorCodes.GuidExpired.ToString();
                            }
                        }
                        else
                        {
                            orgDetails.OrganizationId = organizationId;
                            resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.GuidNotPresent)).ToString();
                            resHeader.ErrorMessage = RegisterErrorCodes.GuidNotPresent.ToString();
                        }
                        orgDetails.ResponseHeader = resHeader;
                        BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                           ("VAS Adapters - RCOM:returning org details for GetOrgDetails for " + " orgId: " + organizationId);
                    }

                    else
                    {
                        orgDetails.OrganizationId = organizationId;
                        resHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.GuidNotPresent)).ToString();
                        resHeader.ErrorMessage = RegisterErrorCodes.GuidNotPresent.ToString();
                    }
                }
                return orgDetails;
            }
            catch (Exception ex)
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                  ("VAS Adapters - RCOM:CRAP!!! got an error for GetOrgDetails for " + " orgId: " + organizationId + ex.Message);

                orgDetails.ResponseHeader = new responseHeader();
                orgDetails.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                orgDetails.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                return orgDetails;
            }
        }
        #endregion

        #region GetDomainLicenseInfo
        [SoapHeader("SSO")]
        [System.Web.Services.WebMethodAttribute()]
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://sdp-partner-services-api/v1.1.0.0/getDomainLicenseInfo", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("OrgInfo", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
        public OrgInfo getDomainLicenseInfo([System.Xml.Serialization.XmlElementAttribute("getDomainLicenseInfo", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")] string organizationId)
        {
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                    ("VAS Adapters - RCOM:Got a getDomainLicenseInfo for " + " orgId: " + organizationId);
            SSOStatus ssoValidationResult;
            OrgInfo orgLicenseInfo;
            RequestProcessor reqProcessor = new RequestProcessor();
            try
            {
                // check whether it is BCP org or UKB org. If it is UKB org, do UKB cal else BCP logic will be BAU.
                if (CheckIsUKBOrg(organizationId))
                {
                    // populate UKB request attributes
                    getDomainLicenseInfoResponse ukbResp = null;
                    var ukbRequest = new getDomainLicenseInfoRequest();
                    ukbRequest.SSOHeader = new BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.SSOHeader();
                    ukbRequest.SSOHeader.GUID = SSO.GUID;
                    ukbRequest.SSOHeader.OrgId = SSO.OrgId;
                    ukbRequest.getDomainLicenseInfo = organizationId;

                    // do UKB call (i.e., calling UKB endpoint)
                    using (ChannelFactory<RCOMCallbackServiceProviderSoap> factory = new ChannelFactory<RCOMCallbackServiceProviderSoap>(@"UKBRCOMCallbackServiceProviderSoap"))
                    {
                        RCOMCallbackServiceProviderSoap svc = factory.CreateChannel();
                        ukbResp = svc.getDomainLicenseInfo(ukbRequest);
                    }
                    // if we got responseHeader from UKB, then redirect the same to RCOM, else send default failure code to RCOM.
                    if (ukbResp != null && ukbResp.OrgInfo != null)
                    {
                        orgLicenseInfo = new OrgInfo();
                        orgLicenseInfo.OrgId = ukbResp.OrgInfo.OrgId;

                        // populate Entitlements object
                        if (ukbResp.OrgInfo.Entitlements != null && ukbResp.OrgInfo.Entitlements.Length > 0)
                        {
                            orgLicenseInfo.Entitlements = new Entitlement[ukbResp.OrgInfo.Entitlements.Length];
                            for (int s = 0; s < ukbResp.OrgInfo.Entitlements.Length; s++)
                            {
                                orgLicenseInfo.Entitlements[s] = new Entitlement();
                                orgLicenseInfo.Entitlements[s].Count = ukbResp.OrgInfo.Entitlements[s].Count;
                                if (ukbResp.OrgInfo.Entitlements[s].TLD == BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.TLD.CC)
                                    orgLicenseInfo.Entitlements[s].TLD = TLD.CC;
                                else if (ukbResp.OrgInfo.Entitlements[s].TLD == BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.TLD.COM)
                                    orgLicenseInfo.Entitlements[s].TLD = TLD.COM;
                            }
                        }

                        orgLicenseInfo.ResponseHeader = new responseHeader();
                        orgLicenseInfo.ResponseHeader.ResultCode = ukbResp.OrgInfo.ResponseHeader.ResultCode;
                        orgLicenseInfo.ResponseHeader.ErrorMessage = ukbResp.OrgInfo.ResponseHeader.ErrorMessage;
                    }
                    else
                    {
                        // UKB call failed, so send failure response to RCOM
                        orgLicenseInfo = new OrgInfo();
                        orgLicenseInfo.ResponseHeader = new responseHeader();
                        orgLicenseInfo.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                        orgLicenseInfo.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                    }
                }
                else // do BCP call as it is as BAU
                {
                    ssoValidationResult = reqProcessor.IsHeaderValid(SSO, organizationId);

                    if (ssoValidationResult == SSOStatus.Passed || ssoValidationResult == SSOStatus.Missing)
                    {
                        orgLicenseInfo = reqProcessor.GetOrgLicenseInfo(organizationId);
                        BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                        ("VAS Adapters - RCOM:Sending response for getDomainLicenseInfo for " + " orgId: " + organizationId);
                    }
                    else
                    {
                        orgLicenseInfo = new OrgInfo();
                        orgLicenseInfo.ResponseHeader = reqProcessor.GetSSOFailedResponse(ssoValidationResult);
                    }
                }
            }
            catch (Exception generalException)
            {
                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                   ("VAS Adapters - RCOM:Sending error response for getDomainLicenseInfo for " + " orgId: " + organizationId + generalException.Message);
                orgLicenseInfo = new OrgInfo();
                orgLicenseInfo.ResponseHeader = new responseHeader();
                orgLicenseInfo.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                orgLicenseInfo.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
            }
            return orgLicenseInfo;
        }

        #endregion

        #region UpdateDomainStatus
        [SoapHeader("SSO")]
        [System.Web.Services.WebMethodAttribute()]
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://sdp-partner-services-api/v1.1.0.0/updateDomainStatus", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("updateDomainStatusResponse", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
        public updateDomainStatusResponse updateDomainStatus([System.Xml.Serialization.XmlElementAttribute("updateDomainStatus", Namespace = "http://iat.intra.btexact.com/sysdesign/R10.0/SDPPartnerSchema")]
            string organizationId, string domainName, string domainStatus)
        {
            SSOStatus ssoValidationResult = new SSOStatus();
            updateDomainStatusResponse updateDomainResponse = new updateDomainStatusResponse();
            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                       ("VAS Adapters - RCOM: Got a UpdateDomainStatus for " + " domainName: " + domainName + " domainStatus: " + domainStatus);
            try
            {
                // check whether it is BCP org or UKB org. If it is UKB org, do UKB cal else BCP logic will be BAU.
                if (CheckIsUKBOrg(organizationId))
                {
                    // populate UKB request attributes
                    var ukbRequest = new updateDomainStatusRequest();
                    ukbRequest.SSOHeader = new BT.ISVAdapter.RCOMServiceProvider.RCOMEntities.SSOHeader();
                    ukbRequest.SSOHeader.GUID = SSO.GUID;
                    ukbRequest.SSOHeader.OrgId = SSO.OrgId;
                    ukbRequest.domainName = domainName;
                    ukbRequest.domainStatus = domainStatus;
                    ukbRequest.updateDomainStatus = organizationId;

                    // do UKB call (i.e., calling UKB endpoint)
                    using (ChannelFactory<RCOMCallbackServiceProviderSoap> factory = new ChannelFactory<RCOMCallbackServiceProviderSoap>(@"UKBRCOMCallbackServiceProviderSoap"))
                    {
                        RCOMCallbackServiceProviderSoap svc = factory.CreateChannel();
                        var ukbResp = svc.updateDomainStatus(ukbRequest);

                        // if we got responseHeader from UKB, then redirect the same to RCOM, else send default failure code to RCOM.
                        if (ukbResp != null && ukbResp.updateDomainStatusResponse != null)
                        {
                            updateDomainResponse = new updateDomainStatusResponse();
                            updateDomainResponse.DomainName = ukbResp.updateDomainStatusResponse.DomainName;
                            updateDomainResponse.ResponseHeader = new responseHeader();
                            updateDomainResponse.ResponseHeader.ErrorMessage = ukbResp.updateDomainStatusResponse.ResponseHeader.ErrorMessage;
                            updateDomainResponse.ResponseHeader.ResultCode = ukbResp.updateDomainStatusResponse.ResponseHeader.ResultCode;
                        }
                        else
                        {
                            // UKB call failed, so send failure response to RCOM
                            updateDomainResponse.ResponseHeader = new responseHeader();
                            updateDomainResponse.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                            updateDomainResponse.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
                        }
                    }
                }
                else // do BCP call as it is BAU
                {
                    RequestProcessor reqProcess = new RequestProcessor();
                    ssoValidationResult = reqProcess.IsHeaderValid(SSO, organizationId);
                    if (ssoValidationResult == SSOStatus.Passed || ssoValidationResult == SSOStatus.Missing)
                    {
                        DomainStatus eDomainStatus = (DomainStatus)Enum.Parse(typeof(DomainStatus), domainStatus, true);
                        if (eDomainStatus.Equals(DomainStatus.Expired)
                            || eDomainStatus.Equals(DomainStatus.TransferOut))
                        {
                            BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace("Posting to PE");
                            OrderResponse response = reqProcess.DeleteDomaintoPE(organizationId, domainName);
                            if (response.result.errorCode == "000000")
                            {
                                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                    ("VAS Adapters - RCOM:UpdateDomainStatus Got a positive response from PE..woohooo!!!");
                                updateDomainResponse.ResponseHeader = new responseHeader();
                                updateDomainResponse.ResponseHeader.ErrorMessage = RegisterErrorCodes.Success.ToString();
                                updateDomainResponse.ResponseHeader.ResultCode = Convert.ToInt32(RegisterErrorCodes.Success).ToString();
                            }
                            else
                            {
                                BT.SaaS.Core.Shared.ErrorManagement.SaaSExceptionManager.OutputTrace
                                   ("VAS Adapters - RCOM:UpdateDomainStatus Got a -ve response from PE..!!!" + response.result.errorDescription);
                                updateDomainResponse.ResponseHeader = new responseHeader();
                                updateDomainResponse.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                                updateDomainResponse.ResponseHeader.ResultCode = Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError).ToString();
                            }
                        }
                        else
                        {
                            updateDomainResponse.ResponseHeader = new responseHeader();
                            updateDomainResponse.ResponseHeader.ErrorMessage = RegisterErrorCodes.StatusDoesNotExit.ToString();
                            updateDomainResponse.ResponseHeader.ResultCode = Convert.ToInt32(RegisterErrorCodes.StatusDoesNotExit).ToString();
                        }
                    }
                    else
                    {
                        updateDomainResponse.ResponseHeader = reqProcess.GetSSOFailedResponse(ssoValidationResult);
                        updateDomainResponse.DomainName = domainName;
                    }
                }
            }
            catch (Exception ex)
            {
                updateDomainResponse.ResponseHeader = new responseHeader();
                updateDomainResponse.ResponseHeader.ErrorMessage = RegisterErrorCodes.UnKnownSystemError.ToString();
                updateDomainResponse.ResponseHeader.ResultCode = (Convert.ToInt32(RegisterErrorCodes.UnKnownSystemError)).ToString();
            }
            return updateDomainResponse;
        }
        #endregion

        // Method to get customer status from c2b, to validate whether it is BCP or UKB customer
        private bool CheckIsUKBOrg(string orgId)
        {
            if (System.Configuration.ConfigurationManager.AppSettings["IsUKBCallRequired"] != null
                && System.Configuration.ConfigurationManager.AppSettings["IsUKBCallRequired"].ToLower() == "yes")
            {
                CRMProvider crmResp = new CRMProvider();
                return crmResp.CheckIsUKBCustomer(orgId);
            }
            else
            {
                return false;
            }
        }
    }
}
