﻿CREATE TABLE BlacklistedDomainNames(BlacklistedDomainNameId int IDENTITY(1,1) NOT NULL,
	BlacklistedDomainName nvarchar (40) NOT NULL,	
 CONSTRAINT PK_BlacklistedDomain PRIMARY KEY(BlacklistedDomainNameId))
