﻿CREATE TABLE DomainNames(DomainNameId int IDENTITY(1,1) NOT NULL,
	DomainName nvarchar (40) NOT NULL,	
 CONSTRAINT PK_Domain PRIMARY KEY(DomainNameId))
